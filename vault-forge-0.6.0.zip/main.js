var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/utils/files.ts
async function ensureFolder(app, folderPath) {
  const normalised = (0, import_obsidian.normalizePath)(folderPath);
  if (!normalised || normalised === ".")
    return;
  const existing = app.vault.getAbstractFileByPath(normalised);
  if (existing instanceof import_obsidian.TFolder)
    return;
  const parts = normalised.split("/");
  let current = "";
  for (const part of parts) {
    current = current ? `${current}/${part}` : part;
    const node = app.vault.getAbstractFileByPath(current);
    if (!node) {
      try {
        await app.vault.createFolder(current);
      } catch (e) {
      }
    }
  }
}
function getMarkdownFiles(app, rootFolder) {
  const files = app.vault.getMarkdownFiles();
  if (!rootFolder)
    return files.filter((f) => !isHiddenPath(f.path));
  const prefix = (0, import_obsidian.normalizePath)(rootFolder).toLowerCase() + "/";
  return files.filter(
    (f) => f.path.toLowerCase().startsWith(prefix) && !isHiddenPath(f.path)
  );
}
function getFile(app, path) {
  const file = app.vault.getAbstractFileByPath((0, import_obsidian.normalizePath)(path));
  return file instanceof import_obsidian.TFile ? file : null;
}
function resolveTargets(app, target, targetPattern) {
  const results = [];
  if (target) {
    const file = getFile(app, target);
    if (file) {
      results.push(file);
    } else {
      console.warn(`[Forge] target not found: ${target}`);
    }
  }
  if (targetPattern) {
    const allFiles = getMarkdownFiles(app);
    for (const file of allFiles) {
      if (matchesGlob(file.path, targetPattern)) {
        results.push(file);
      }
    }
  }
  const seen = /* @__PURE__ */ new Set();
  return results.filter((f) => {
    if (seen.has(f.path))
      return false;
    seen.add(f.path);
    return true;
  });
}
function isExempt(path, exemptPaths) {
  if (!exemptPaths.length)
    return false;
  const normalised = (0, import_obsidian.normalizePath)(path).toLowerCase();
  return exemptPaths.some((p) => {
    const prefix = (0, import_obsidian.normalizePath)(p).toLowerCase();
    return normalised.startsWith(prefix + "/") || normalised === prefix;
  });
}
function matchesGlob(path, pattern) {
  const normPath = (0, import_obsidian.normalizePath)(path).toLowerCase();
  const normPattern = (0, import_obsidian.normalizePath)(pattern).toLowerCase();
  const regexStr = globToRegex(normPattern);
  try {
    return new RegExp(regexStr).test(normPath);
  } catch (e) {
    return false;
  }
}
function globToRegex(pattern) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  const regexBody = escaped.replace(/\*\*\//g, "(.+/)?").replace(/\*\*/g, ".*").replace(/\*/g, "[^/]*");
  return `^${regexBody}$`;
}
function isHiddenPath(path) {
  return path.split("/").some((segment) => segment.startsWith("."));
}
function localTimestamp() {
  const d = /* @__PURE__ */ new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function todayString() {
  const d = /* @__PURE__ */ new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function safeTimestamp() {
  const d = /* @__PURE__ */ new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}
function buildExemptList(schemaExemptPaths, forgeFolder) {
  return [...schemaExemptPaths, forgeFolder];
}
var import_obsidian;
var init_files = __esm({
  "src/utils/files.ts"() {
    import_obsidian = require("obsidian");
  }
});

// src/utils/frontmatter.ts
var frontmatter_exports = {};
__export(frontmatter_exports, {
  backupNote: () => backupNote,
  getFmString: () => getFmString,
  isFieldPresent: () => isFieldPresent,
  parseNote: () => parseNote,
  readNote: () => readNote,
  sortFrontmatterFields: () => sortFrontmatterFields,
  writeNote: () => writeNote
});
async function readNote(app, file) {
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[Forge] Could not read file: ${file.path}`, e);
    return null;
  }
  return parseNote(raw, file);
}
function parseNote(raw, file) {
  var _a;
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!match) {
    return {
      frontmatter: {},
      body: raw,
      hasFrontmatter: false,
      file
    };
  }
  const fmText = match[1];
  const body = (_a = match[2]) != null ? _a : "";
  let frontmatter = {};
  try {
    const parsed = (0, import_obsidian2.parseYaml)(fmText);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      frontmatter = parsed;
    }
  } catch (e) {
    console.warn(`[Forge] Could not parse YAML in: ${file.path}`, e);
  }
  return {
    frontmatter,
    body,
    hasFrontmatter: true,
    file
  };
}
async function writeNote(app, note, fieldOrder) {
  const sorted = sortFrontmatterFields(note.frontmatter, fieldOrder);
  const yaml = (0, import_obsidian2.stringifyYaml)(sorted).trimEnd();
  const newContent = `---
${yaml}
---
${note.body}`;
  await app.vault.modify(note.file, newContent);
}
async function backupNote(app, file, backupFolder) {
  await ensureFolder(app, backupFolder);
  const timestamp = safeTimestamp().replace(/[_]/g, "_").replace(/:/g, "-");
  const safeName = file.path.replace(/\//g, "_");
  const backupPath = (0, import_obsidian2.normalizePath)(
    `${backupFolder}/${safeName}.${timestamp}.bak`
  );
  try {
    const content = await app.vault.read(file);
    await app.vault.create(backupPath, content);
    return backupPath;
  } catch (e) {
    console.warn(`[Forge] Could not create backup for ${file.path}:`, e);
    return null;
  }
}
function sortFrontmatterFields(frontmatter, fieldOrder) {
  const order = fieldOrder != null ? fieldOrder : PREFERRED_FIELD_ORDER;
  const result = {};
  for (const field of order) {
    if (Object.prototype.hasOwnProperty.call(frontmatter, field)) {
      result[field] = frontmatter[field];
    }
  }
  const remaining = Object.keys(frontmatter).filter((k) => !order.includes(k)).sort();
  for (const key of remaining) {
    result[key] = frontmatter[key];
  }
  return result;
}
function isFieldPresent(frontmatter, fieldName) {
  if (!Object.prototype.hasOwnProperty.call(frontmatter, fieldName)) {
    return false;
  }
  const value = frontmatter[fieldName];
  if (value === null || value === void 0)
    return false;
  if (typeof value === "string")
    return value.trim().length > 0;
  if (Array.isArray(value))
    return value.length > 0;
  return true;
}
function getFmString(frontmatter, fieldName) {
  const value = frontmatter[fieldName];
  if (value === null || value === void 0)
    return "";
  if (Array.isArray(value)) {
    return value.filter((v) => v !== null && v !== void 0).map((v) => String(v)).join("; ");
  }
  return String(value);
}
var import_obsidian2, PREFERRED_FIELD_ORDER;
var init_frontmatter = __esm({
  "src/utils/frontmatter.ts"() {
    import_obsidian2 = require("obsidian");
    init_files();
    PREFERRED_FIELD_ORDER = [
      "type",
      "kind",
      "domain",
      "status",
      "shapes",
      "tags",
      "created",
      "updated",
      "review_by",
      "ai_private",
      "ai_open_questions",
      "source",
      "supersedes",
      "superseded_by",
      "version",
      "review_cycle"
    ];
  }
});

// src/vault-paths.ts
function getVaultPaths(settings) {
  const s = settings;
  const schemaMd = `${s.schemaNoteFolder}/${s.schemaNoteFile}`;
  const forge = s.forgeFolder;
  return {
    // Schema
    schemaMd,
    // VaultForge system
    forge,
    patches: s.patchesFolder,
    patchApplied: `${s.patchesFolder}/Applied`,
    patchBackups: s.patchBackupFolder || `${s.patchesFolder}/Backups`,
    patchReports: `${s.patchesFolder}/Reports`,
    indexDefinitions: `${forge}/Indexes`,
    // Exports
    exports: s.exportsFolder,
    lintReportJson: `${s.exportsFolder}/lint-report.json`,
    lintHistoryJson: `${s.exportsFolder}/lint-history.json`,
    vaultMeta: `${s.exportsFolder}/vault-meta.json`,
    // Human-readable lint report notes
    lintRuns: s.lintRunsFolder,
    // Vault structure
    shapes: s.shapesFolder,
    templates: s.shapeTemplatesFolder || `${s.systemFolder}/Templates`,
    inbox: s.inboxFolder,
    dashboards: `${s.systemFolder}/Dashboards`,
    // Patch
    patchFile: s.patchDefaultFile
  };
}
var init_vault_paths = __esm({
  "src/vault-paths.ts"() {
  }
});

// src/commands/refine-shapes.ts
var refine_shapes_exports = {};
__export(refine_shapes_exports, {
  refineShapes: () => refineShapes,
  runRefineShapes: () => runRefineShapes
});
async function runRefineShapes(plugin) {
  const { app, settings } = plugin;
  if (!settings.shapesEnabled) {
    new import_obsidian7.Notice("Forge: Shapes is not enabled. Enable it in Settings \u2192 Shapes.", 5e3);
    return;
  }
  if (!settings.shapeRefinementEnabled) {
    new import_obsidian7.Notice("Forge: Template refinement is not enabled. Enable it in Settings \u2192 Shapes.", 5e3);
    return;
  }
  new import_obsidian7.Notice("Forge: Running shape template refinement\u2026", 3e3);
  const result = await refineShapes(plugin);
  const summary = `Done. Created: ${result.created} | Updated: ${result.updated} | Skipped: ${result.skipped}${result.errors > 0 ? ` | Errors: ${result.errors}` : ""}`;
  new import_obsidian7.Notice(`Forge: ${summary}`, 6e3);
  const errors = result.results.filter((r) => r.status === "error");
  if (errors.length > 0) {
    console.error("[Forge] Shape refinement errors:", errors);
  }
}
async function refineShapes(plugin) {
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const results = [];
  let created = 0;
  let updated = 0;
  let skipped2 = 0;
  let errors = 0;
  await ensureFolder(app, paths.templates);
  const shapesFolder = app.vault.getAbstractFileByPath(paths.shapes);
  if (!(shapesFolder instanceof import_obsidian7.TFolder)) {
    return { results, created, updated, skipped: skipped2, errors, ranAt: localTimestamp() };
  }
  const shapeFiles = shapesFolder.children.filter(
    (f) => f instanceof import_obsidian7.TFile && f.extension === "md"
  );
  for (const shapeFile of shapeFiles) {
    const result = await processShape(plugin, shapeFile, paths.templates);
    results.push(result);
    if (result.status === "created")
      created++;
    else if (result.status === "updated")
      updated++;
    else if (result.status === "skipped")
      skipped2++;
    else
      errors++;
  }
  return { results, created, updated, skipped: skipped2, errors, ranAt: localTimestamp() };
}
async function processShape(plugin, shapeFile, templatesFolder) {
  const { app, settings } = plugin;
  const shapeName = shapeFile.basename;
  const templateFileName = shapeToTemplateName(shapeName);
  const templatePath = `${templatesFolder}/${templateFileName}`;
  const note = await readNote(app, shapeFile);
  if (!note) {
    return error(shapeName, templateFileName, "Could not read shape note");
  }
  const noteType = note.frontmatter["type"];
  if (noteType && String(noteType).toLowerCase() !== "shape") {
    return skipped(shapeName, templateFileName, `type is '${noteType}', not 'shape'`);
  }
  const structure = getSectionBody(note.body, "Structure");
  if (!structure) {
    return skipped(shapeName, templateFileName, "No # Structure section found");
  }
  const body = promoteHeadings(structure).trim();
  const today = todayString();
  const existingTemplate = app.vault.getAbstractFileByPath(templatePath);
  const existingCreated = existingTemplate instanceof import_obsidian7.TFile ? await getExistingCreated(app, existingTemplate) : null;
  const fm = buildTemplateFrontmatter(settings, shapeName, today, existingCreated);
  const yaml = (0, import_obsidian8.stringifyYaml)(fm).trimEnd();
  const newContent = `---
${yaml}
---

${body}
`;
  if (existingTemplate instanceof import_obsidian7.TFile) {
    const existingContent = await app.vault.read(existingTemplate);
    if (existingContent === newContent) {
      return skipped(shapeName, templateFileName, "No changes");
    }
    await app.vault.modify(existingTemplate, newContent);
    return { shape: shapeName, template: templateFileName, status: "updated", detail: "Template updated" };
  } else {
    await app.vault.create(templatePath, newContent);
    return { shape: shapeName, template: templateFileName, status: "created", detail: "Template created" };
  }
}
function buildTemplateFrontmatter(settings, shapeName, today, existingCreated) {
  const { shapeTypeTargetField, shapeTemplateFields, frontmatterFieldOrder } = settings;
  const base = {};
  for (const [fieldName, config] of Object.entries(shapeTemplateFields)) {
    if (config.include) {
      base[fieldName] = config.value;
    }
  }
  base[shapeTypeTargetField] = shapeName;
  base["created"] = existingCreated != null ? existingCreated : today;
  base["updated"] = today;
  const order = frontmatterFieldOrder.length > 0 ? frontmatterFieldOrder : Object.keys(base);
  const sorted = {};
  for (const field of order) {
    if (Object.prototype.hasOwnProperty.call(base, field)) {
      sorted[field] = base[field];
    }
  }
  for (const key of Object.keys(base)) {
    if (!Object.prototype.hasOwnProperty.call(sorted, key)) {
      sorted[key] = base[key];
    }
  }
  return sorted;
}
function getSectionBody(body, heading) {
  const escaped = heading.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const lines = body.split("\n");
  const startPattern = new RegExp(`^#\\s+${escaped}\\s*$`);
  let startIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (startPattern.test(lines[i])) {
      startIdx = i + 1;
      break;
    }
  }
  if (startIdx === -1)
    return null;
  let endIdx = lines.length;
  for (let i = startIdx; i < lines.length; i++) {
    if (/^#\s+/.test(lines[i])) {
      endIdx = i;
      break;
    }
  }
  return lines.slice(startIdx, endIdx).join("\n").trim();
}
function promoteHeadings(content) {
  return content.split("\n").map((line) => {
    const m = line.match(/^(#{2,6})\s+(.*)$/);
    if (!m)
      return line;
    return "#".repeat(m[1].length - 1) + " " + m[2];
  }).join("\n");
}
function shapeToTemplateName(shapeName) {
  const title = shapeName.split(/[-_ ]+/).filter(Boolean).map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
  return `Template, ${title}.md`;
}
async function getExistingCreated(app, file) {
  const note = await readNote(app, file);
  if (!note)
    return null;
  const val = note.frontmatter["created"];
  if (val && typeof val === "string")
    return val;
  return null;
}
function skipped(shape, template, detail) {
  return { shape, template, status: "skipped", detail };
}
function error(shape, template, detail) {
  return { shape, template, status: "error", detail };
}
var import_obsidian7, import_obsidian8;
var init_refine_shapes = __esm({
  "src/commands/refine-shapes.ts"() {
    import_obsidian7 = require("obsidian");
    init_vault_paths();
    init_frontmatter();
    init_files();
    import_obsidian8 = require("obsidian");
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => ForgePlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian21 = require("obsidian");

// src/settings.ts
var DEFAULT_SETTINGS = {
  // System paths
  systemFolder: "System",
  forgeFolder: "System/Forge",
  // Lint
  schemaNoteFolder: "System/Registry",
  schemaNoteFile: "schema.md",
  lintRunsFolder: "System/Exports/LintReports",
  lintStrictMode: false,
  lintRunRetentionCount: 20,
  lintFileLinks: false,
  lintInlineMetadata: true,
  // Stale review
  staleReviewEnabled: false,
  staleReviewCycleField: "review_cycle",
  staleReviewUpdatedField: "updated",
  staleReviewFilterField: "status",
  staleReviewStatuses: [],
  // Patch
  patchesFolder: "System/Forge/Patches",
  inboxFolder: "System/Inbox",
  patchDefaultFile: "System/Forge/Patches/vault-patch.md",
  patchBackupEnabled: true,
  patchBackupFolder: "System/Forge/Patches/Backups",
  patchGenerateManifest: true,
  patchAutoLintAfterApply: true,
  patchAutoMaintenanceAfterApply: false,
  // Maintenance
  backupRetentionDays: 14,
  inboxRetentionDays: 30,
  lintHistoryRetentionDays: 14,
  lintHistoryMaxEntries: 20,
  patchReportRetentionCount: 20,
  // Export
  exportEnabled: false,
  exportsFolder: "System/Exports",
  exportRelationshipHeading: "Related",
  exportFilterField: "",
  exportFilterValues: [],
  exportPrivateEnabled: false,
  exportPrivateField: "",
  exportDomainField: "",
  exportTypeField: "",
  exportStatusField: "",
  exportDashboardName: "",
  exportExcludeFolders: [],
  // Shapes
  shapesEnabled: false,
  shapesFolder: "System/Shapes",
  shapeRefinementEnabled: false,
  shapeTemplatesFolder: "System/Templates",
  shapeTypeTargetField: "type",
  shapeTemplateFields: {},
  // Frontmatter field order
  frontmatterFieldOrder: []
};

// src/settings-tab.ts
var import_obsidian9 = require("obsidian");

// src/commands/export-overview.ts
var import_obsidian3 = require("obsidian");
init_files();
init_frontmatter();
async function runExportOverview(plugin) {
  var _a;
  const { app, settings } = plugin;
  if (!settings.exportEnabled) {
    new import_obsidian3.Notice("Forge: Export is not enabled \u2014 enable it in Settings \u2192 Export.", 5e3);
    return;
  }
  new import_obsidian3.Notice("Forge: Building vault overview\u2026", 3e3);
  await ensureFolder(app, settings.exportsFolder);
  const inventory = await buildInventory(plugin);
  const meta = buildMeta(plugin, inventory);
  await writeFile(
    app,
    (0, import_obsidian3.normalizePath)(`${settings.exportsFolder}/vault-inventory.json`),
    JSON.stringify(inventory, null, 2)
  );
  await writeFile(
    app,
    (0, import_obsidian3.normalizePath)(`${settings.exportsFolder}/vault-meta.json`),
    JSON.stringify(meta, null, 2)
  );
  await writeFile(
    app,
    (0, import_obsidian3.normalizePath)(`${settings.exportsFolder}/vault-export.md`),
    buildExportNote(inventory, meta, settings, todayString())
  );
  const dashName = ((_a = settings.exportDashboardName) == null ? void 0 : _a.trim()) || "vault-dashboard";
  const dashPath = (0, import_obsidian3.normalizePath)(`${settings.exportsFolder}/${dashName}.md`);
  const dashExists = app.vault.getAbstractFileByPath(dashPath) instanceof import_obsidian3.TFile;
  if (!dashExists) {
    await app.vault.create(dashPath, buildDashboardNote(settings, todayString()));
  }
  new import_obsidian3.Notice(`Forge: Overview complete \u2014 ${inventory.count} notes indexed.`, 5e3);
}
async function buildInventory(plugin) {
  var _a, _b, _c, _d;
  const { app, settings } = plugin;
  const schema = plugin.schemaCache.peek();
  const exemptPaths = (_a = schema == null ? void 0 : schema.exempt_paths) != null ? _a : [];
  const schemaVer = (_c = (_b = schema == null ? void 0 : schema.meta) == null ? void 0 : _b.version) != null ? _c : "unknown";
  const privateField = settings.exportPrivateEnabled ? settings.exportPrivateField : "";
  const domainField = settings.exportDomainField;
  const typeField = settings.exportTypeField || "type";
  const statusField = settings.exportStatusField || "status";
  const allFiles = app.vault.getMarkdownFiles().filter((f) => {
    if (f.path.split("/").some((seg) => seg.startsWith(".")))
      return false;
    if (exemptPaths.length > 0 && isExempt(f.path, exemptPaths))
      return false;
    return true;
  });
  const items = [];
  for (const file of allFiles) {
    const note = await readNote(app, file);
    const fm = (_d = note == null ? void 0 : note.frontmatter) != null ? _d : {};
    let domain = domainField ? getFmString(fm, domainField) : "";
    if (!domain) {
      const parts = file.path.split("/");
      domain = parts.length > 1 ? parts[0] : "(root)";
    }
    items.push({
      path: file.path,
      filename: file.basename,
      tags: getFmString(fm, "tags"),
      type: getFmString(fm, typeField),
      domain,
      status: getFmString(fm, statusField),
      isPrivate: privateField ? Boolean(fm[privateField]) : false
    });
  }
  items.sort((a, b) => a.path.localeCompare(b.path));
  return {
    generated_at: localTimestamp(),
    schema_version: schemaVer,
    count: items.length,
    items
  };
}
function buildMeta(plugin, inventory) {
  var _a, _b, _c, _d, _e, _f;
  const { settings } = plugin;
  const schemaVer = (_c = (_b = (_a = plugin.schemaCache.peek()) == null ? void 0 : _a.meta) == null ? void 0 : _b.version) != null ? _c : "unknown";
  const domainLabel = settings.exportDomainField || "domain";
  const typeLabel = settings.exportTypeField || "type";
  const statusLabel = settings.exportStatusField || "status";
  const byDomain = {};
  const byType = {};
  const byStatus = {};
  for (const item of inventory.items) {
    if (settings.exportPrivateEnabled && item.isPrivate)
      continue;
    byDomain[item.domain] = ((_d = byDomain[item.domain]) != null ? _d : 0) + 1;
    if (item.type)
      byType[item.type] = ((_e = byType[item.type]) != null ? _e : 0) + 1;
    if (item.status)
      byStatus[item.status] = ((_f = byStatus[item.status]) != null ? _f : 0) + 1;
  }
  return {
    generated_at: localTimestamp(),
    schema_version: schemaVer,
    [`note_counts_by_${domainLabel}`]: byDomain,
    [`note_counts_by_${typeLabel}`]: byType,
    [`note_counts_by_${statusLabel}`]: byStatus
  };
}
function buildExportNote(inventory, meta, settings, today) {
  const privateEnabled = settings.exportPrivateEnabled && settings.exportPrivateField;
  const domainLabel = settings.exportDomainField || "domain";
  const typeLabel = settings.exportTypeField || "type";
  const statusLabel = settings.exportStatusField || "status";
  const allItems = inventory.items;
  const privateItems = privateEnabled ? allItems.filter((i) => i.isPrivate) : [];
  const totalNotes = allItems.length;
  const totalPrivate = privateItems.length;
  const countBy = (items, key) => {
    var _a;
    const counts = {};
    for (const item of items) {
      const val = String(item[key] || "");
      if (!val)
        continue;
      counts[val] = ((_a = counts[val]) != null ? _a : 0) + 1;
    }
    return counts;
  };
  const tableRows = (counts, col) => [
    `| ${col} | Count |`,
    `|--------|-------|`,
    ...Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([k, v]) => `| ${k} | ${v} |`)
  ];
  const lines = [
    "---",
    "type: reference",
    "status: complete",
    "tags:",
    "  - meta/vault-export",
    `created: ${today}`,
    `updated: ${today}`,
    ...settings.exportPrivateField ? [`${settings.exportPrivateField}: false`] : [],
    "review_cycle: never",
    "---",
    "",
    `schema_version:: "${inventory.schema_version}"`,
    `generated:: ${inventory.generated_at}`,
    `total_notes:: ${totalNotes}`,
    `total_private_notes:: ${totalPrivate}`,
    "",
    `> Generated ${inventory.generated_at}`,
    "",
    `## All Notes by ${domainLabel}`,
    "",
    ...tableRows(countBy(allItems, "domain"), domainLabel),
    "",
    `## All Notes by ${typeLabel}`,
    "",
    ...tableRows(countBy(allItems, "type"), typeLabel),
    "",
    `## All Notes by ${statusLabel}`,
    "",
    ...tableRows(countBy(allItems, "status"), statusLabel),
    ""
  ];
  if (privateEnabled && privateItems.length > 0) {
    lines.push(
      "---",
      "",
      `## Private Notes by ${domainLabel}`,
      "",
      ...tableRows(countBy(privateItems, "domain"), domainLabel),
      "",
      `## Private Notes by ${typeLabel}`,
      "",
      ...tableRows(countBy(privateItems, "type"), typeLabel),
      "",
      `## Private Notes by ${statusLabel}`,
      "",
      ...tableRows(countBy(privateItems, "status"), statusLabel),
      ""
    );
  }
  lines.push(
    "---",
    "",
    "Machine-readable data: `vault-inventory.json`, `vault-meta.json`",
    ""
  );
  return lines.join("\n");
}
function buildDashboardNote(settings, today) {
  const folder = settings.exportsFolder;
  const typeLabel = settings.exportTypeField || "type";
  const privateEnabled = settings.exportPrivateEnabled && settings.exportPrivateField;
  const lines = [
    "---",
    "type: reference",
    "status: active",
    "tags:",
    "  - meta/dashboard",
    `created: ${today}`,
    `updated: ${today}`,
    "review_cycle: never",
    "---",
    "",
    "> This dashboard is generated once and never overwritten \u2014 edit freely.",
    "",
    "## Vault Overview",
    "",
    "```dataview",
    `TABLE total_notes, total_private_notes, generated, schema_version`,
    `FROM "${folder}"`,
    `WHERE contains(tags, "meta/vault-export") AND file.name = "vault-export"`,
    "```",
    "",
    `## Ontology Indexes`,
    "",
    "```dataview",
    `TABLE total_notes, total_private_notes, relationship_heading, generated`,
    `FROM "${folder}"`,
    `WHERE contains(tags, "meta/vault-export") AND node_type`,
    `SORT ${typeLabel} ASC`,
    "```",
    ""
  ];
  if (privateEnabled) {
    lines.push(
      "## Private Note Breakdown",
      "",
      "```dataview",
      `TABLE total_private_notes, total_notes, generated`,
      `FROM "${folder}"`,
      `WHERE contains(tags, "meta/vault-export")`,
      `SORT total_private_notes DESC`,
      "```",
      ""
    );
  }
  return lines.join("\n");
}
async function loadInventory(app, exportsFolder) {
  const path = (0, import_obsidian3.normalizePath)(`${exportsFolder}/vault-inventory.json`);
  const file = app.vault.getAbstractFileByPath(path);
  if (!(file instanceof import_obsidian3.TFile))
    return null;
  try {
    return JSON.parse(await app.vault.read(file));
  } catch (e) {
    console.warn("[Forge] Could not load inventory:", e);
    return null;
  }
}
async function writeFile(app, path, content) {
  const existing = app.vault.getAbstractFileByPath(path);
  if (existing instanceof import_obsidian3.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(path, content);
  }
}

// src/commands/export-ontology.ts
var import_obsidian4 = require("obsidian");
init_files();
init_frontmatter();
async function runExportOntology(plugin) {
  var _a, _b, _c, _d, _e;
  const { app, settings } = plugin;
  if (!settings.exportEnabled) {
    new import_obsidian4.Notice("Forge: Export is not enabled \u2014 enable it in Settings \u2192 Export.", 5e3);
    return null;
  }
  if (!settings.exportFilterField || settings.exportFilterValues.length === 0) {
    new import_obsidian4.Notice("Forge: No filter configured \u2014 set a field and values in Settings \u2192 Export.", 7e3);
    return null;
  }
  const schemaVersion = (_c = (_b = (_a = plugin.schemaCache.peek()) == null ? void 0 : _a.meta) == null ? void 0 : _b.version) != null ? _c : "unknown";
  const relHeading = ((_d = settings.exportRelationshipHeading) == null ? void 0 : _d.trim()) || "Related";
  let inventory = await loadInventory(app, settings.exportsFolder);
  if (!inventory) {
    new import_obsidian4.Notice("Forge: No inventory found \u2014 running Export Inventory first\u2026", 4e3);
    await runExportOverview(plugin);
    inventory = await loadInventory(app, settings.exportsFolder);
    if (!inventory) {
      new import_obsidian4.Notice("Forge: Inventory export failed \u2014 ontology export aborted.", 6e3);
      return null;
    }
  }
  const excludeFolders = (_e = settings.exportExcludeFolders) != null ? _e : [];
  const filteredItems = excludeFolders.length > 0 ? inventory.items.filter((r) => {
    const norm = r.path.replace(/\\/g, "/");
    return !excludeFolders.some((folder) => {
      const f = folder.replace(/\\/g, "/").replace(/\/$/, "");
      return norm === f || norm.startsWith(f + "/");
    });
  }) : inventory.items;
  const { exportFilterField, exportFilterValues } = settings;
  const recordsByValue = /* @__PURE__ */ new Map();
  for (const record of filteredItems) {
    const raw = getRecordField(record, exportFilterField);
    if (!raw)
      continue;
    for (const val of raw.split(";").map((v) => v.trim()).filter(Boolean)) {
      if (!exportFilterValues.includes(val))
        continue;
      if (!recordsByValue.has(val))
        recordsByValue.set(val, []);
      recordsByValue.get(val).push(record);
    }
  }
  if (recordsByValue.size === 0) {
    new import_obsidian4.Notice(`Forge: No notes matched '${exportFilterField}' in [${exportFilterValues.join(", ")}].`, 7e3);
    return null;
  }
  new import_obsidian4.Notice(`Forge: Building ontology indexes for ${recordsByValue.size} type(s)\u2026`, 4e3);
  const indexes = [];
  const today = todayString();
  for (const [filterValue, records] of recordsByValue) {
    const items = await buildNodes(app, records, relHeading);
    items.sort((a, b) => a.name.localeCompare(b.name));
    const privateField = settings.exportPrivateEnabled ? settings.exportPrivateField : "";
    const privateCount = privateField ? records.filter((r) => {
      return Boolean(r.isPrivate);
    }).length : 0;
    const index = {
      generated_at_utc: localTimestamp(),
      schema_version: schemaVersion,
      index_type: `${filterValue}-index`,
      node_type: filterValue,
      relationship_heading: relHeading,
      filter_field: exportFilterField,
      filter_value: filterValue,
      total_notes: items.length,
      total_private_notes: privateCount,
      items
    };
    indexes.push(index);
    await ensureFolder(app, settings.exportsFolder);
    const base = (0, import_obsidian4.normalizePath)(`${settings.exportsFolder}/${filterValue}-index`);
    await writeFile2(app, `${base}.json`, JSON.stringify(index, null, 2));
    const domainLabel = settings.exportDomainField || "domain";
    const statusLabel = settings.exportStatusField || "status";
    await writeFile2(app, `${base}.md`, buildOntologyNote(index, today, domainLabel, statusLabel));
  }
  const total = indexes.reduce((sum, idx) => sum + idx.total_notes, 0);
  new import_obsidian4.Notice(`Forge: Ontology export complete \u2014 ${total} nodes across [${[...recordsByValue.keys()].join(", ")}].`, 6e3);
  return indexes;
}
async function buildNodes(app, records, relHeading) {
  const nodes = [];
  for (const record of records) {
    const abstractFile = app.vault.getAbstractFileByPath((0, import_obsidian4.normalizePath)(record.path));
    if (!(abstractFile instanceof import_obsidian4.TFile))
      continue;
    const note = await readNote(app, abstractFile);
    if (!note)
      continue;
    nodes.push({
      name: getFmString(note.frontmatter, "title") || note.file.basename,
      type: record.type,
      path: record.path,
      domain: record.domain,
      status: record.status,
      tags: record.tags,
      relationships: extractRelationships(note.body, relHeading),
      outbound_links: extractAllWikilinks(note.body),
      modified_utc: new Date(note.file.stat.mtime).toISOString()
    });
  }
  return nodes;
}
function extractRelationships(body, parentHeading) {
  const relationships = {};
  const parentMatch = new RegExp(`^(#{1,6})\\s+${escapeRegex(parentHeading)}\\s*$`, "m").exec(body);
  if (!parentMatch)
    return relationships;
  const parentLevel = parentMatch[1].length;
  const lines = body.slice(parentMatch.index + parentMatch[0].length).split(/\r?\n/);
  let currentKey = null;
  for (const line of lines) {
    const h = line.match(/^(#{1,6})\s+(.+?)\s*$/);
    if (h) {
      if (h[1].length <= parentLevel)
        break;
      currentKey = h[2].trim();
      if (!relationships[currentKey])
        relationships[currentKey] = [];
    } else if (currentKey) {
      relationships[currentKey].push(...wikilinkTargets(line));
    }
  }
  return relationships;
}
function extractAllWikilinks(body) {
  const seen = /* @__PURE__ */ new Set();
  const re = /\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g;
  let m;
  while ((m = re.exec(body)) !== null)
    seen.add(m[1].trim());
  return [...seen].sort();
}
function wikilinkTargets(line) {
  const re = /\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g;
  const out = [];
  let m;
  while ((m = re.exec(line)) !== null)
    out.push(m[1].trim());
  return out;
}
function buildOntologyNote(index, today, domainLabel, statusLabel) {
  const allKeys = /* @__PURE__ */ new Set();
  for (const node of index.items)
    Object.keys(node.relationships).forEach((k) => allKeys.add(k));
  return [
    "---",
    "type: reference",
    "status: complete",
    "tags:",
    "  - meta/vault-export",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    `schema_version:: "${index.schema_version}"`,
    `generated:: ${index.generated_at_utc}`,
    `node_type:: ${index.node_type}`,
    `total_notes:: ${index.total_notes}`,
    `total_private_notes:: ${index.total_private_notes}`,
    `relationship_heading:: ${index.relationship_heading}`,
    "",
    `> Generated ${index.generated_at_utc} \u2014 ${index.total_notes} nodes.`,
    `> Relationship heading: \`# ${index.relationship_heading}\``,
    `> Machine-readable data: \`${index.node_type}-index.json\``,
    "",
    "# Relationship Keys Observed",
    "",
    allKeys.size > 0 ? [...allKeys].sort().map((k) => `- ${k}`).join("\n") : "_No relationship sections found._",
    "",
    "# Nodes",
    "",
    `| Name | ${statusLabel} | ${domainLabel} | Relationships |`,
    "|------|--------|--------|---------------|",
    ...index.items.map((n) => {
      const links = Object.values(n.relationships).reduce((s, a) => s + a.length, 0);
      return `| [[${n.path}\\|${n.name}]] | ${n.status || "\u2014"} | ${n.domain} | ${links} |`;
    }),
    ""
  ].join("\n");
}
function getRecordField(record, field) {
  switch (field) {
    case "type":
      return record.type;
    case "status":
      return record.status;
    case "domain":
      return record.domain;
    case "tags":
      return record.tags;
    default:
      return "";
  }
}
async function writeFile2(app, path, content) {
  const existing = app.vault.getAbstractFileByPath(path);
  if (existing instanceof import_obsidian4.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(path, content);
  }
}
function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// src/docs.ts
var import_obsidian5 = require("obsidian");
init_vault_paths();
init_files();

// forge-docs:forge:docs
var forge_docs_default = {
  "0.START-HERE": `Forge is a schema-driven governance plugin for Obsidian.

It helps keep long-lived vaults structurally healthy through schema validation, linting, patch operations, tag normalization, frontmatter normalization, repair workflows, and maintenance routines.

# Who this is for

Forge is for people who treat their Obsidian vault as a long-term knowledge system rather than a loose collection of notes.

It is useful when you want:

- consistent frontmatter
- predictable tags
- schema validation
- safe bulk edits
- patch history
- repeatable maintenance
- operational visibility into vault structure

# What Forge is not

Forge is not an AI assistant, template engine, or note-taking methodology.

It does not decide what your vault means.

It enforces the structure you define.

# How Forge works

Forge uses:

- schema notes to define expected structure
- linting to detect inconsistencies
- patches to apply explicit vault changes
- normalization routines to keep metadata consistent
- repair workflows to safely resolve problems

Most workflows follow this pattern:

1. Define structure
2. Validate the vault
3. Review problems
4. Generate or apply fixes
5. Re-run validation

# First setup checklist

1. Confirm your Forge folder in Settings \u2192 General.
2. Create or choose a schema note and set it in Settings \u2192 Lint.
3. Run **Forge: Validate Schema**.
4. Run **Forge: Run Vault Lint**.
5. Create a patch note at your configured patch path.
6. Run **Forge: Apply Vault Patch**.
7. (Optional) Enable Export in Settings \u2192 Export and run **Export Vault Overview**.

# Current configured locations

| Purpose | Path |
|---|---|
| Forge folder | \`{{forge}}\` |
| Docs | \`{{docsFolder}}\` |
| Examples | \`{{examplesFolder}}\` |
| Schema note | \`{{schemaFile}}\` |
| Patch note | \`{{patchFile}}\` |
| Patches folder | \`{{patchesFolder}}\` |
| Exports folder | \`{{exportsFolder}}\` |

# Recommended reading order

1. [[1.Installation|Installation]]
2. [[2.Vault-Structure|Vault-Structure]]
3. [[3.Schema|Schema]]
4. [[4.Linting|Linting]]
5. [[5.Patches|Patches]]
6. [[6.Commands|Commands]]
7. [[7.Settings|Settings]]
8. [[8.Troubleshooting|Troubleshooting]]
9. [[9.Export|Export]]`,
  "1.Installation": `# Installation

## Manual Installation

1. Copy the release assets into your Obsidian plugin folder:

\`\`\`text
.obsidian/plugins/forge/
\u251C\u2500\u2500 main.js
\u251C\u2500\u2500 manifest.json
\u2514\u2500\u2500 versions.json
\`\`\`

2. Refresh **Community plugins**
3. Then enable **Forge**

## Community Plugins

**Not yet available**

# Updating

## Manual Update

Recommended update process:

1. Disable Forge in Obsidian.
2. Replace \`main.js\`, \`manifest.json\`, and \`versions.json\`.
3. Re-enable Forge.

Disabling the plugin before replacing files helps avoid stale loaded code during updates.

## Community Plugins

**Not yet available**

# iOS notes

On iOS, the \`.obsidian\` folder may be hidden by the Files app.

The most reliable approach is to install or update the plugin on desktop and allow Obsidian Sync or iCloud to transfer the plugin files.

Apps such as \`Taio\` may also help expose hidden folders.

# Verify installation

Open the command palette and search for:

\`\`\`text
Forge
\`\`\`

You should see commands such as:

- Forge: Run Vault Lint
- Forge: Apply Vault Patch
- Forge: Validate Schema
- Forge: Install Documentation

# Documentation location

This documentation was installed into:

\`\`\`text
{{docsFolder}}
\`\`\`

Examples were installed into:

\`\`\`text
{{examplesFolder}}
\`\`\`

Continue with [[2.Vault-Structure|Vault-Structure]].`,
  "2.Vault-Structure": `Forge works best when operational files live in a predictable location.

It does not require the folder to be named \`System/Forge\`. It uses the Forge folder configured in settings.

# Current configured structure

\`\`\`text
{{forge}}/
\u251C\u2500\u2500 Docs/
\u251C\u2500\u2500 Examples/
\u251C\u2500\u2500 Indexes/
\u2514\u2500\u2500 Patches/
    \u251C\u2500\u2500 vault-patch.md
    \u251C\u2500\u2500 Applied/
    \u251C\u2500\u2500 Backups/
    \u2514\u2500\u2500 Reports/
\`\`\`

# Folder meanings

| Folder | Purpose |
|---|---|
| \`{{docsFolder}}\` | Vault-native documentation |
| \`{{examplesFolder}}\` | Starter schema and patch examples |
| \`{{patchesFolder}}\` | Active patch note and patch history |
| \`{{patchesFolder}}/Applied\` | Archived applied patch notes |
| \`{{patchesFolder}}/Backups\` | File backups created before patch changes |
| \`{{patchesFolder}}/Reports\` | Patch reports and restore manifests |
| \`{{exportsFolder}}\` | Lint reports and export outputs |

# Why this structure exists

Forge treats vault operations as first-class vault content.

Patch notes, reports, examples, and docs remain inside the vault so they are:

- searchable
- linkable
- syncable
- reviewable
- versionable

This keeps operational history visible instead of hidden inside plugin state.

# Recommended practices

Forge works best when:

- patch files remain inside the configured patches folder
- reports and backups are retained
- schema notes live in stable locations
- operational folders are excluded from normal writing workflows

The exact folder layout is flexible, but consistency matters.

Continue with [[3.Schema|Schema]].`,
  "3.Schema": `Forge validates notes against a schema note.

Current configured schema path:

\`\`\`text
{{schemaFile}}
\`\`\`

# What a schema does

A schema defines the expected structure of your vault.

It can describe:

- required frontmatter fields
- allowed field values
- tag rules
- validation severity
- normalization behavior
- patch workflow expectations

Forge uses the schema during linting, repair workflows, normalization, and patch operations.

# Schema format

A schema is a markdown note containing normal frontmatter and a fenced YAML block.

The YAML block defines validation and operational rules.

# Required fields

Required fields define the frontmatter expected on normal notes.

Example:

\`\`\`yaml
required_fields:
  - name: type
    type: enum
    values: [reference, procedure, project]
    severity: error

  - name: status
    type: enum
    values: [draft, active, complete, archived]
    severity: error
\`\`\`

# Supported field types

Common field types include:

- \`enum\`
- \`list\`
- \`date\`
- \`boolean\`

# Severity

Severity controls how validation issues are reported.

| Severity | Meaning |
|---|---|
| \`error\` | Must be fixed |
| \`warning\` | Should be reviewed |
| \`info\` | Informational |

# Recommended approach

Start with a small schema.

Avoid attempting to model the entire vault immediately.

A good first schema usually defines:

- note type
- status
- core tags
- required metadata

Schemas can evolve over time as vault structure becomes more stable.

# Linting

Forge uses schema rules during linting and repair workflows.

See:

\`\`\`text
[[4.Linting|Linting]]
\`\`\`

# Example schema

See:

\`\`\`text
{{examplesFolder}}/schema.md
\`\`\`

Continue with [[4.Linting|Linting]].`,
  "4.Linting": `Linting validates vault notes against the configured schema.

Run it from the command palette:

\`\`\`text
Forge: Run Vault Lint
\`\`\`

# What lint checks

Forge can validate:

- required frontmatter fields
- field types
- enum values
- date formats
- required tags
- tag namespace rules
- inline metadata (key:: value patterns)
- exempt paths
- stale notes (when Stale Note Review is enabled)

Linting helps detect structural drift before inconsistencies spread through the vault.

# Reports

Lint reports are written under:

\`\`\`text
{{lintRunsFolder}}
\`\`\`

Common outputs include:

- \`lint-report.json\`
- \`lint-history.json\`
- lint run notes

These reports provide operational visibility into vault health over time.

# Strict mode

Strict mode treats warnings as errors.

Use strict mode when your schema is mature.

Leave it disabled while designing or evolving a new schema.

# Inline metadata

When enabled, lint checks \`key:: value\` patterns in the note body against the schema's \`inline_fields\` list.

Rules applied:

- **inline_is_schema_field** \u2014 inline key matches a frontmatter field (should be moved to frontmatter)
- **inline_fuzzy_schema** \u2014 inline key looks like a typo of a schema field
- **inline_fuzzy_inline** \u2014 inline key looks like a typo of a known inline field
- **inline_undocumented** \u2014 inline key is not listed in \`inline_fields\` in schema.md

Disable **Lint inline metadata** in Settings \u2192 Lint if you do not use inline metadata or want to skip these checks entirely.

# Stale Note Review

When enabled, lint flags notes whose review cycle has elapsed.

Configure in Settings \u2192 Lint \u2192 Stale Note Review:

- **Review cycle field** \u2014 the frontmatter field containing the review cadence. Must be an enum field in your schema with values: \`daily\`, \`weekly\`, \`monthly\`, \`quarterly\`, \`yearly\`, \`never\`
- **Last updated field** \u2014 the frontmatter field containing the last-updated date (e.g. \`updated\`)
- **In-scope field** \u2014 schema field used to determine which notes are evaluated (e.g. \`status\`)
- **In-scope values** \u2014 values of that field to include; leave empty to evaluate all notes

Lint reads the cycle value from each note, maps it to a number of days (\`daily\` = 1, \`weekly\` = 7, \`monthly\` = 30, \`quarterly\` = 90, \`yearly\` = 365), and flags notes where the last-updated date exceeds that threshold. Notes with \`never\` are always skipped.

Notes missing the cycle field or last updated field are skipped silently.

# Repair workflow

Forge keeps repair workflows explicit and reviewable.

Typical workflow:

1. Run **Forge: Run Vault Lint**.
2. Review lint results.
3. Run **Forge: Vault Repair**.
4. Review the generated patch.
5. Apply the patch.
6. Run lint again.

This avoids silent vault modifications and keeps repair operations auditable.

# Recommended approach

Run lint regularly while evolving vault structure.

Smaller, incremental fixes are easier to review and safer to apply than large corrective patch runs.

Continue with [[5.Patches|Patches]].
`,
  "5.Patches": `Patches are explicit vault operations stored as markdown notes.

Current configured patch note:

\`\`\`text
{{patchFile}}
\`\`\`

# What patches do

Patches allow Forge to apply structured, reviewable vault changes.

Typical uses include:

- fixing metadata
- normalizing tags
- reorganizing notes
- repairing lint violations
- applying repeatable maintenance operations

Forge keeps patch operations explicit instead of silently modifying vault content.

# Patch note format

A patch note is a normal vault note containing a fenced YAML block.

Example:

\`\`\`md
---
type: procedure
status: draft
tags:
  - tool/forge
created: {{today}}
updated: {{today}}
ai_private: false
review_cycle: never
---
\`\`\`

# Vault Patch

\`\`\`yaml
meta:
  description: Activate Home note

operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

Forge reads only the fenced YAML block for patch operations. The rest of the note is for human context and review.

# Patch lifecycle

Typical workflow:

1. Edit the active patch note.
2. Run **Forge: Apply Vault Patch**.
3. Review the dry-run confirmation.
4. Confirm apply.
5. Forge writes backups, reports, and archive copies.
6. Re-run linting if needed.

Forge separates patch generation from patch execution so changes remain reviewable and auditable.

# Patch folders

| Folder | Purpose |
|---|---|
| \`{{patchesFolder}}\` | Active patch note |
| \`{{patchesFolder}}/Applied\` | Archived applied patch notes |
| \`{{patchesFolder}}/Backups\` | Backups created before changes |
| \`{{patchesFolder}}/Reports\` | Reports and restore manifests |

# Targeting files

Most operations require either \`target\` or \`target_pattern\`.

| Field | Purpose |
|---|---|
| \`target\` | A single markdown file path |
| \`target_pattern\` | A glob-style pattern matching one or more markdown files |

Examples:

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

\`\`\`yaml
operations:
  - op: normalize_tags
    target_pattern: "Projects/**/*.md"
\`\`\`

# Operation index

| Operation | Purpose |
|---|---|
| \`set_field\` | Set or update a frontmatter field |
| \`remove_field\` | Remove a frontmatter field |
| \`add_tag\` | Add a tag to frontmatter |
| \`remove_tag\` | Remove a tag from frontmatter |
| \`replace_tag\` | Replace one tag with another |
| \`normalize_tags\` | Sort and deduplicate tags |
| \`compute_field\` | Compute a frontmatter value from file metadata or activity |
| \`sort_frontmatter\` | Reorder frontmatter fields into the canonical order |
| \`move_note\` | Move a note from one folder tree to another |

# Supported operations

## \`set_field\`

Sets a frontmatter field to a literal value.

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
\`\`\`

Use \`only_if_missing\` to avoid overwriting an existing value.

\`\`\`yaml
operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active
    only_if_missing: true
\`\`\`

### \`when\` condition

\`when\` skips the operation unless the specified field currently equals the specified value. Useful for conditional migrations without separate patch passes.

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "**/*.md"
    field: review_cycle
    value: monthly
    when:
      field: review_cycle
      equals: "1"
\`\`\`

### Derived values

\`set_field\` can also derive a value from the file path.

Supported \`value_from\` values:

| Value | Result |
|---|---|
| \`filename\` | File name with extension |
| \`basename\` | File name without \`.md\` |
| \`folder\` | Immediate parent folder |
| \`parent_folder\` | Folder above the immediate parent |
| \`path\` | A specific path segment |

Example:

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: project
    value_from: folder
\`\`\`

For \`value_from: path\`, provide \`path_segment_index\`.

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: area
    value_from: path
    path_segment_index: 0
\`\`\`

Derived values may also use:

| Field | Purpose |
|---|---|
| \`trim_prefix\` | Remove text from the beginning of the derived value |
| \`trim_suffix\` | Remove text from the end of the derived value |
| \`lowercase\` | Convert the derived value to lowercase |
| \`uppercase\` | Convert the derived value to uppercase |

Example:

\`\`\`yaml
operations:
  - op: set_field
    target_pattern: "Projects/**/*.md"
    field: project
    value_from: basename
    trim_prefix: "Project - "
    lowercase: true
\`\`\`

## \`remove_field\`

Removes a frontmatter field.

\`\`\`yaml
operations:
  - op: remove_field
    target: "Home.md"
    field: old_field
\`\`\`

## \`add_tag\`

Adds a tag if it is not already present.

\`\`\`yaml
operations:
  - op: add_tag
    target: "Home.md"
    tag: topic/home
\`\`\`

## \`remove_tag\`

Removes a tag if present.

\`\`\`yaml
operations:
  - op: remove_tag
    target: "Home.md"
    tag: topic/old
\`\`\`

## \`replace_tag\`

Replaces one tag with another.

\`\`\`yaml
operations:
  - op: replace_tag
    target_pattern: "Projects/**/*.md"
    old_tag: topic/old
    new_tag: topic/new
\`\`\`

## \`normalize_tags\`

Sorts and deduplicates frontmatter tags.

\`\`\`yaml
operations:
  - op: normalize_tags
    target_pattern: "Projects/**/*.md"
\`\`\`

## \`compute_field\`

Computes a frontmatter field from file metadata or recent activity.

Supported strategies:

| Strategy | Purpose |
|---|---|
| \`file_created_time\` | Uses the file creation time |
| \`file_modified_time\` | Uses the file modified time |
| \`recent_activity\` | Sets a value when the file was modified within a recent window |

### File created time

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Notes/**/*.md"
    field: created
    strategy: file_created_time
    format: yyyy-MM-dd
    when_missing: true
\`\`\`

### File modified time

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Notes/**/*.md"
    field: updated
    strategy: file_modified_time
    format: yyyy-MM-dd
\`\`\`

### Recent activity

\`\`\`yaml
operations:
  - op: compute_field
    target_pattern: "Projects/**/*.md"
    field: status
    strategy: recent_activity
    days: 30
    value_if_true: active
    skip_if:
      - archived
      - complete
\`\`\`

## \`sort_frontmatter\`

Reorders frontmatter fields into Forge's canonical order.

\`\`\`yaml
operations:
  - op: sort_frontmatter
    target_pattern: "Notes/**/*.md"
\`\`\`

## \`move_note\`

Moves a note from one folder tree to another while preserving the relative path under \`source_root\`.

\`\`\`yaml
operations:
  - op: move_note
    target: "Inbox/Example.md"
    source_root: "Inbox"
    destination_folder: "Notes"
\`\`\`

### Optional frontmatter merge

If \`frontmatter:\` is provided, the specified fields are merged into the note's existing frontmatter after moving. Fields in \`frontmatter:\` overwrite existing values. Fields not listed are left unchanged.

\`\`\`yaml
operations:
  - op: move_note
    target: "System/Inbox/Example.md"
    source_root: "System/Inbox"
    destination_folder: "Work/Projects"
    frontmatter:
      type: project
      status: active
\`\`\`

### Strip frontmatter

If \`strip_frontmatter: true\` is set, all frontmatter is removed during the move. The note body is preserved.

\`\`\`yaml
operations:
  - op: move_note
    target: "System/Inbox/Example.md"
    source_root: "System/Inbox"
    destination_folder: "Work/Projects"
    strip_frontmatter: true
\`\`\`

\`strip_frontmatter\` and \`frontmatter\` cannot be used together.

# Recommended approach

Start with small patches.

Review dry-run results before applying changes.

Review generated backups and reports before running large structural operations across the vault.

Smaller patch runs are easier to validate and safer to restore if needed.

# Safety

Keep backups enabled unless you have a specific reason to disable them.

Use **Forge: Restore Patch Run** to restore files from a backup manifest created during a prior patch run.

Continue with [[6.Commands|Commands]].`,
  "6.Commands": `# Apply Vault Patch

Loads the configured patch note, performs a dry run, requests confirmation, then applies the patch operations.

Configured patch note:

\`\`\`text
{{patchFile}}
\`\`\`

Forge writes backups, reports, and restore manifests during patch runs.

---

# Run Vault Lint

Validates vault notes against the configured schema.

Lint results are written under:

\`\`\`text
{{lintRunsFolder}}
\`\`\`

Linting helps detect structural drift, invalid metadata, missing fields, and tag inconsistencies.

---

# Validate Schema

Parses and validates the configured schema note.

This verifies schema syntax, field definitions, validation rules, and operational configuration before linting or patch operations use the schema.

---

# Normalize Tags

Sorts and deduplicates frontmatter tag lists.

Useful for:

- standardizing tag ordering
- removing duplicate tags
- improving Dataview consistency
- reducing metadata drift

---

# Normalize Frontmatter

Reorders frontmatter fields into Forge's canonical order.

This helps maintain consistent metadata structure across the vault.

---

# Vault Maintenance

Runs maintenance routines for Forge operational files.

Maintenance may include:

- backup retention cleanup
- patch report cleanup
- lint history cleanup
- operational folder cleanup

---

# Vault Repair

Builds a repair patch from lint results.

The generated patch can then be reviewed, modified, and applied explicitly.

Typical workflow:

1. Run lint
2. Generate repair patch
3. Review the patch
4. Apply the patch
5. Run lint again

---

# Restore Patch Run

Uses a restore manifest to restore files from backups created during a prior patch run.

This command is intended for recovery from unwanted or incorrect patch operations.

---

# Export Vault Overview

Builds a structural snapshot of the vault in one pass.

Output files:

\`\`\`text
{{exportsFolder}}/vault-inventory.json
{{exportsFolder}}/vault-meta.json
{{exportsFolder}}/vault-export.md
\`\`\`

\`vault-inventory.json\` is a flat index of all non-exempt notes. Schema is optional \u2014 the inventory runs on any vault.

\`vault-meta.json\` contains aggregate counts by domain, type, and status. Notes flagged as private (if configured) are excluded from these counts.

\`vault-export.md\` is the human-readable summary note with inline Dataview fields and summary tables.

A Dataview dashboard note is also created on the first run and never overwritten. Its filename is configurable in Settings \u2192 Export.

Configure domain, type, status field mappings and private note behavior in Settings \u2192 Export \u2192 Overview Options.

---

# Export Ontology Index

Builds per-type relationship graphs for selected note types.

Output files per type:

\`\`\`text
{{exportsFolder}}/<type>-index.json
{{exportsFolder}}/<type>-index.md
\`\`\`

The export walks notes matching the configured field and value filter, then extracts relationships from the configured relationship heading. Subheadings under that heading become relationship keys \u2014 no structure is hardcoded.

If no inventory exists on disk, Export Vault Overview runs automatically first.

Notes in excluded folders (configured in Settings \u2192 Export \u2192 Exclude Folders) are skipped.

Configure the filter field, filter values, relationship heading, and excluded folders in Settings \u2192 Export.

---

# Rename Dataview Folder

Updates Dataview folder references after a folder rename.

This helps preserve Dataview queries and folder-based workflows after structural vault changes.

---

# Install Documentation

Installs Forge documentation and examples into the configured Forge folder.

Installed content includes:

- operational documentation
- schema examples
- patch examples
- onboarding notes
`,
  "7.Settings": `Forge settings are stored in the Obsidian plugin data store.

Change settings through the Obsidian settings UI. Settings are organized into tabs.

---

# General

System paths that all Forge features share.

| Setting | Description |
|---|---|
| System folder | Root folder for all vault system files |
| Forge folder | Folder for Forge configuration and patch archives |

**Install Documentation** writes vault-native docs into your Forge folder. Skips notes that already exist.

---

# Lint

Controls lint behavior and the schema note location.

| Setting | Description |
|---|---|
| Schema note | Path to \`schema.md\` relative to vault root |
| Lint reports folder | Where lint run notes are written (default \`System/Exports/LintReports\`) |
| Strict mode | Treat warnings as errors |
| Lint run retention | Number of lint run notes to keep |
| Lint file links | Wrap file paths in \`[[wikilinks]]\` in lint notes |

## Stale Note Review

Flags notes whose review cycle has elapsed based on frontmatter values.

| Setting | Description |
|---|---|
| Enable | Gates the stale review feature |
| Review cycle field | Frontmatter field containing the review cadence (e.g. \`review_cycle\`) |
| Last updated field | Frontmatter field containing the last-updated date (e.g. \`updated\`) |
| In-scope field | Schema field used to determine which notes are in scope (e.g. \`status\`) |
| In-scope values | Values of that field to include; leave empty to skip stale review |

Field and value options are populated from your schema. Reload schema if the lists are empty.

---

# Patch

Controls patch operations, backups, and automation behavior.

| Setting | Description |
|---|---|
| Patches folder | Where applied patch files are archived |
| Inbox folder | Staging folder for draft notes awaiting processing |
| Default patch file | Patch note loaded by Apply Vault Patch |
| Backup before patch | Create a backup of each modified file before applying |
| Backup folder | Where patch backups are stored (verify restore script location before changing) |
| Generate restore manifest | Write a manifest alongside each patch run for one-step restore |
| Run lint after patch | Automatically run lint after a patch is applied |
| Run maintenance after patch | Automatically run maintenance after a patch is applied |

Recommended defaults: backups enabled, restore manifest enabled, auto-lint enabled, auto-maintenance disabled.

Forge favors explicit review over aggressive automation.

---

# Maintenance

Controls how long generated operational files are retained.

| Setting | Description |
|---|---|
| Backup retention (days) | Delete patch backup files older than this many days |
| Inbox retention (days) | Flag inbox files older than this many days as stale |
| Lint history retention (days) | Trim lint history entries older than this many days |
| Lint history max entries | Hard cap on lint history entries |
| Patch report retention | Number of patch report notes to keep |

---

# Export

Controls vault export behavior. Must be enabled before any export commands are available.

| Setting | Description |
|---|---|
| Enable export | Gates all export functionality |
| Exports folder | Where inventory, meta, and index files are written |

## Run Exports

Two export commands are available from the Export tab:

| Button | Output |
|---|---|
| Export Vault Overview | \`vault-inventory.json\` + \`vault-meta.json\` + \`vault-export.md\` |
| Export Ontology Index | \`<type>-index.json\` + \`<type>-index.md\` per selected type |

Export Vault Overview also creates a Dataview dashboard note on the first run (never overwritten).

## Overview Options

Controls how the vault overview export organizes and counts notes.

| Setting | Description |
|---|---|
| Domain field | Frontmatter field representing a note's domain; blank uses parent folder |
| Type field | Frontmatter field representing a note's type; blank uses \`type\` |
| Status field | Frontmatter field representing a note's lifecycle status; blank uses \`status\` |
| Dashboard note name | Filename for the generated Dataview dashboard; blank uses \`vault-dashboard\` |
| Private notes | When enabled, notes with the chosen field set to a truthy value are counted separately and excluded from \`vault-meta.json\` |
| Private note field | The frontmatter field that signals a note as private (any truthy value qualifies) |

## Ontology Filter

Controls which notes are included in the ontology export.

| Setting | Description |
|---|---|
| Reload from schema | Refreshes field and value lists from the current schema |
| Filter field | Schema field to filter on (e.g. \`type\`) |
| Filter values | Values of that field to include (multi-select, populated from schema) |

## Relationship Extraction

| Setting | Description |
|---|---|
| Relationship heading | Top-level heading under which relationships are organized (without \`#\`, e.g. \`Related\`) |

Subheadings under the relationship heading become relationship keys in the export. Wikilinks under each subheading become relationship values. The structure is fully dynamic \u2014 no heading names are hardcoded.

## Exclude Folders

| Setting | Description |
|---|---|
| Excluded folders | Folders to skip during ontology export; applies at any depth |

Notes inside excluded folders are not indexed. Add a top-level folder to exclude everything under it.

---

# Shapes

Reserved for Vault Shape Engine \u2014 coming in a future release.

| Setting | Description |
|---|---|
| Enable | Gates the Shapes feature (no-op until the feature lands) |
| Shapes folder | Folder containing shape notes for lint validation |

---

# Recommended approach

Keep operational paths stable once workflows are established.

Changing schema, patch, or export locations frequently can make historical operations harder to review and troubleshoot.

Continue with [[8.Troubleshooting|Troubleshooting]].
`,
  "8.Troubleshooting": `# Patch file not found

Check Forge settings and confirm the default patch file points to an existing note.

Configured patch path:

\`\`\`text
{{patchFile}}
\`\`\`

If the note does not exist, running **Forge: Apply Vault Patch** can create a starter patch note.

# Patch note has no YAML block

Patch notes must contain a fenced YAML block with an \`operations\` list.

Example:

\`\`\`\`md
# Patch

\`\`\`yaml
operations: []
\`\`\`
\`\`\`\`

Forge reads only the fenced YAML block when applying a patch.

# Patch operation failed

Review the generated patch report.

Patch reports are written to:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

Common causes include:

- the target file does not exist
- the target pattern matched no files
- a required operation field is missing
- a destination file already exists
- the patch YAML is not valid

# Schema not loading

Check that:

- the schema note exists
- the schema setting points to the correct note
- the schema note has valid frontmatter
- the schema note has a fenced YAML block
- the YAML block is valid

Configured schema path:

\`\`\`text
{{schemaFile}}
\`\`\`

Run **Forge: Validate Schema** to diagnose schema issues.

# Lint report not generated

Check that the exports folder exists or can be created:

\`\`\`text
{{exportsFolder}}
\`\`\`

Also confirm that the configured schema loads successfully. Linting depends on a valid schema.

# Reports not generated

Check that the reports folder exists or can be created:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

Patch reports are generated during patch dry runs and applied patch runs.

# Backups not generated

Check that backups are enabled in Forge settings.

Backups are written to:

\`\`\`text
{{patchesFolder}}/Backups
\`\`\`

Backups are only written when a patch operation changes a file.

# Restore manifest not generated

Check that both settings are enabled:

- backup before patch
- generate restore manifest

Restore manifests are written to:

\`\`\`text
{{patchesFolder}}/Reports
\`\`\`

A restore manifest is only created when a patch run modifies files and backups are available.

# Plugin update did not take effect

Disable Forge before replacing plugin files, then re-enable it.

Files to replace:

\`\`\`text
main.js
manifest.json
versions.json
\`\`\`

If Obsidian still appears to use old code, restart Obsidian after replacing the files.

# Documentation did not update

**Forge: Install Documentation** skips notes that already exist.

To reinstall a documentation note, delete or rename the existing note, then run **Forge: Install Documentation** again.

Documentation folder:

\`\`\`text
{{docsFolder}}
\`\`\`

Examples folder:

\`\`\`text
{{examplesFolder}}
\`\`\`

# Recommended recovery order

When something fails, use this order:

1. Run **Forge: Validate Schema**.
2. Run **Forge: Run Vault Lint**.
3. Review the latest lint run note.
4. Review the latest patch report if a patch failed.
5. Confirm settings paths still point to the expected notes and folders.

Continue with [[0.START-HERE|START-HERE]].
`,
  "9.Export": `Forge can export structured data about your vault for use in AI sessions, dashboards, and external tooling.

All exports must be enabled in Settings \u2192 Export before commands are available.

---

# How exports work

Forge exports are inventory-first. The vault inventory is the index that all other exports build on.

Dependency chain:

\`\`\`
schema  \u2192  vault-inventory  \u2192  ontology index
(optional)    (required)        (per type)
\`\`\`

Each export produces machine-readable JSON alongside a human-readable Obsidian markdown note.

---

# Export Vault Overview

Single command \u2014 three outputs plus an optional dashboard.

**Output:**

\`\`\`text
{{exportsFolder}}/vault-inventory.json
{{exportsFolder}}/vault-meta.json
{{exportsFolder}}/vault-export.md
{{exportsFolder}}/<dashboard-name>.md  (created once, never overwritten)
\`\`\`

\`vault-inventory.json\` is a flat index of every non-exempt note. Schema is optional \u2014 the inventory runs on any vault. Exempt paths are honoured when schema is loaded.

\`vault-meta.json\` contains aggregate counts by domain, type, and status using your configured field names. Notes flagged as private (if configured) are excluded from these counts.

\`vault-export.md\` is the human-readable summary with inline Dataview fields (\`total_notes::\`, \`total_private_notes::\`, \`generated::\`, \`schema_version::\`) and count tables.

The dashboard note is created on the first run only and never overwritten, so you can edit it freely. Its filename is configurable in Settings \u2192 Export \u2192 Overview Options.

## Configuring field names

By default, Forge reads \`type\`, \`status\`, and parent folder as domain. These can be remapped to any frontmatter field in Settings \u2192 Export \u2192 Overview Options.

The configured field names become the column headings in \`vault-export.md\` and the JSON keys in \`vault-meta.json\`. For example, if you set type field to \`kind\`, the meta JSON will contain \`note_counts_by_kind\`.

## Private notes

When enabled, notes where the configured private field is truthy are:

- counted separately in \`vault-export.md\` (private notes by domain, type, status)
- excluded from \`vault-meta.json\` counts
- always tracked via \`total_private_notes::\` (0 when disabled)

The private field is user-defined \u2014 any frontmatter boolean or truthy value qualifies.

---

# Export Ontology Index

Builds per-type relationship graphs for selected note types.

**Output per type:**

\`\`\`text
{{exportsFolder}}/<type>-index.json
{{exportsFolder}}/<type>-index.md
\`\`\`

If no inventory exists on disk, Export Vault Overview runs automatically first.

## Ontology filter

Configure which notes are included in Settings \u2192 Export \u2192 Ontology Filter:

1. Click **Reload from Schema** to populate the field list.
2. Choose a **filter field** \u2014 any required or optional field from your schema (e.g. \`type\`).
3. Select **filter values** \u2014 the enum values to include (e.g. \`capability\`, \`method\`, \`reference\`).

One index file is produced per selected value.

## Relationship extraction

Configure the **relationship heading** \u2014 the top-level heading under which your notes organize their links (e.g. \`Related\`).

The export finds that heading in each note and collects all subheadings beneath it as relationship keys. Wikilinks under each subheading become relationship values.

**Example note structure:**

\`\`\`markdown
# Related

## Enables
- [[CI/CD Pipeline]]
- [[Runbook Design]]

## Enabled By
- [[Ansible]]
- [[Terraform]]
\`\`\`

With relationship heading set to \`Related\`, the export produces:

\`\`\`json
{
  "relationships": {
    "Enables": ["CI/CD Pipeline", "Runbook Design"],
    "Enabled By": ["Ansible", "Terraform"]
  }
}
\`\`\`

No subheading names are hardcoded. Inconsistencies across notes surface as missing keys \u2014 useful for finding structural drift.

## Excluding folders

Notes inside excluded folders are skipped during ontology export. Configure in Settings \u2192 Export \u2192 Exclude Folders.

Exclusions apply at any depth \u2014 adding a top-level folder excludes everything under it. Exclusions are persisted in settings.

---

# The dashboard note

The dashboard note is a Dataview note generated once on the first Export Vault Overview run.

It contains blocks for:

- vault overview (total notes, private notes, generated timestamp)
- ontology index summary (one row per type with node counts)
- private note breakdown (when private notes is enabled)

Because it is never overwritten, you can customise the Dataview queries, add new blocks, or reorganise it freely.

---

# AI consumption

The JSON exports are designed for use in AI sessions. A typical workflow:

1. Run Export Vault Overview before starting a session.
2. Attach or paste the relevant JSON into your session context.
3. The AI has a structured view of your vault's content and relationships.

Notes flagged as private are excluded from \`vault-meta.json\`, keeping sensitive context out of AI sessions without changing note location or type.

---

# Recommended approach

Run Export Vault Overview periodically to keep your structural snapshot current.

Run Export Ontology Index when you want a current relationship graph for AI sessions or analysis.

The ontology export auto-triggers the overview if no inventory is found \u2014 you do not need to remember the order.

Continue with [[8.Troubleshooting|Troubleshooting]].
`
};

// forge-docs:forge:examples
var forge_examples_default = {
  "schema": `This is a small example schema. Copy the YAML block into your real schema note if you want a starter contract.

Configured schema location:

\`\`\`text
{{schemaFile}}
\`\`\`

# Schema

\`\`\`yaml
meta:
  author: vault
  schemaRef: "{{schemaFile}}"

required_fields:
  - name: type
    type: enum
    values:
      - reference
      - procedure
      - project
      - concept
    severity: error

  - name: status
    type: enum
    values: [draft, active, complete, archived]
    severity: error

  - name: tags
    type: list
    min_items: 1
    severity: error

  - name: created
    type: date
    format: "yyyy-MM-dd"
    severity: error

  - name: updated
    type: date
    format: "yyyy-MM-dd"
    severity: warning

  - name: ai_private
    type: boolean
    severity: warning

  - name: review_cycle
    type: enum
    values: [daily, weekly, monthly, quarterly, yearly, never]
    severity: error

optional_fields: []

inline_fields:
  - source
  - version
  - schema_version
  - errors
  - warnings

tag_rules:
  require_namespace: true
  unknown_tags: warning
  severity: warning
  allowed_namespaces:
    - meta
    - skill
    - tool
    - topic

exempt_paths: []
\`\`\`
`,
  "vault-patch": `This is an example patch note.

Copy this structure to:

\`\`\`text
{{patchFile}}
\`\`\`

# Patch

\`\`\`yaml
meta:
  description: Activate Home note

operations:
  - op: set_field
    target: "Home.md"
    field: status
    value: active

  - op: add_tag
    target: "Home.md"
    tag: topic/home

  - op: normalize_tags
    target_pattern: "Projects/**/*.md"

  - op: sort_frontmatter
    target_pattern: "Notes/**/*.md"
\`\`\`

# Notes

Forge reads only the fenced YAML block for operations. The rest of this note is for humans.
`
};

// src/docs.ts
function interpolate(template, ctx) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    var _a;
    return (_a = ctx[key]) != null ? _a : `{{${key}}}`;
  });
}
async function installVaultForgeDocumentation(app, settings) {
  const paths = getVaultPaths(settings);
  const today = todayString();
  const ctx = {
    today,
    forge: paths.forge,
    docsFolder: `${paths.forge}/Docs`,
    examplesFolder: `${paths.forge}/Examples`,
    patchesFolder: paths.patches,
    patchFile: paths.patchFile,
    schemaFile: paths.schemaMd,
    exportsFolder: paths.exports,
    inboxFolder: paths.inbox,
    shapesFolder: paths.shapes
  };
  await ensureFolder(app, ctx.docsFolder);
  await ensureFolder(app, ctx.examplesFolder);
  const docs = buildDocList(ctx);
  let written = 0;
  let skipped2 = 0;
  for (const doc of docs) {
    const path = (0, import_obsidian5.normalizePath)(doc.path);
    const existing = app.vault.getAbstractFileByPath(path);
    if (existing instanceof import_obsidian5.TFile) {
      skipped2++;
      continue;
    }
    const folder = path.includes("/") ? path.substring(0, path.lastIndexOf("/")) : "";
    if (folder)
      await ensureFolder(app, folder);
    await app.vault.create(path, doc.content);
    written++;
  }
  new import_obsidian5.Notice(
    `Forge docs installed: ${written} written, ${skipped2} already existed.`,
    6e3
  );
}
function buildDocList(ctx) {
  const docs = [
    ...Object.entries(forge_docs_default).map(([key, raw]) => ({
      relativePath: `Docs/${key}.md`,
      raw,
      type: "reference",
      tags: inferTags(key, "docs")
    })),
    ...Object.entries(forge_examples_default).map(([key, raw]) => ({
      relativePath: `Examples/${key}.md`,
      raw,
      type: inferType(key),
      tags: inferTags(key, "examples")
    }))
  ];
  return docs.map(({ relativePath, raw, type, tags }) => {
    const body = interpolate(raw, ctx);
    const frontmatter = [
      "---",
      `type: ${type}`,
      "status: active",
      "tags:",
      ...tags.map((t) => `  - ${t}`),
      `created: ${ctx.today}`,
      `updated: ${ctx.today}`,
      "ai_private: false",
      "review_cycle: never",
      "---",
      ""
    ].join("\n");
    return {
      path: `${ctx.forge}/${relativePath}`,
      content: frontmatter + body.trim() + "\n"
    };
  });
}
function inferTags(key, folder) {
  const base = ["tool/forge"];
  const lower = key.toLowerCase();
  if (lower.includes("install") || lower.includes("start")) {
    base.push("topic/onboarding");
  } else if (lower.includes("schema") || lower.includes("lint") || lower.includes("structure")) {
    base.push("topic/schema");
  } else if (lower.includes("patch") || lower.includes("trouble") || lower.includes("repair")) {
    base.push("topic/procedure");
  } else {
    base.push("topic/reference");
  }
  return base;
}
function inferType(key) {
  const lower = key.toLowerCase();
  if (lower.includes("patch") || lower.includes("example"))
    return "procedure";
  return "reference";
}

// src/utils/schema.ts
var import_obsidian6 = require("obsidian");
init_vault_paths();
async function loadSchema(app, settings) {
  const paths = getVaultPaths(settings);
  const file = app.vault.getAbstractFileByPath(paths.schemaMd);
  if (!(file instanceof import_obsidian6.TFile)) {
    console.warn(`[Forge] schema.md not found at: ${paths.schemaMd}`);
    return null;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[Forge] Could not read schema.md:`, e);
    return null;
  }
  return parseSchemaNote(raw);
}
function parseSchemaNote(raw) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const fmMatch = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!fmMatch) {
    console.warn("[Forge] schema.md is missing valid YAML frontmatter");
    return null;
  }
  const fmText = fmMatch[1];
  const bodyText = (_a = fmMatch[2]) != null ? _a : "";
  let fmUpdated = "";
  try {
    const fm = (0, import_obsidian6.parseYaml)(fmText);
    fmUpdated = (fm == null ? void 0 : fm.updated) ? String(fm.updated) : "";
  } catch (e) {
  }
  const versionMatch = bodyText.match(/^version::\s*"?([^"\s]+)"?\s*$/m);
  const version = (_b = versionMatch == null ? void 0 : versionMatch[1]) != null ? _b : "";
  const contractYaml = extractContractBlock(bodyText);
  if (!contractYaml) {
    console.warn("[Forge] Could not find schema contract YAML block in schema.md");
    return null;
  }
  let contract;
  try {
    contract = (0, import_obsidian6.parseYaml)(contractYaml);
  } catch (e) {
    console.warn("[Forge] Could not parse schema contract YAML:", e);
    return null;
  }
  if (!contract) {
    console.warn("[Forge] Schema contract block is empty");
    return null;
  }
  const contractMeta = (_c = contract.meta) != null ? _c : {};
  const meta = {
    version,
    updated: fmUpdated,
    author: contractMeta.author ? String(contractMeta.author) : void 0,
    schemaRef: contractMeta.schemaRef ? String(contractMeta.schemaRef) : void 0
  };
  const requiredFields = coerceFieldArray(contract.required_fields);
  const optionalFields = coerceFieldArray(contract.optional_fields);
  const rawInline = contract.inline_fields;
  const inlineFields = Array.isArray(rawInline) ? rawInline.map(String) : [];
  const rawTagRules = (_d = contract.tag_rules) != null ? _d : {};
  const tagRules = {
    require_namespace: Boolean((_e = rawTagRules.require_namespace) != null ? _e : true),
    unknown_tags: (_f = rawTagRules.unknown_tags) != null ? _f : "warning",
    severity: (_g = rawTagRules.severity) != null ? _g : "warning",
    allowed_namespaces: Array.isArray(rawTagRules.allowed_namespaces) ? rawTagRules.allowed_namespaces.map(String) : []
  };
  const rawExempt = contract.exempt_paths;
  const exemptPaths = Array.isArray(rawExempt) ? rawExempt.map(String) : [];
  return {
    meta,
    required_fields: requiredFields,
    optional_fields: optionalFields,
    inline_fields: inlineFields,
    tag_rules: tagRules,
    exempt_paths: exemptPaths,
    lint_output: (_h = contract.lint_output) != null ? _h : {},
    patch_engine: (_i = contract.patch_engine) != null ? _i : {}
  };
}
function validateSchemaNote(raw) {
  var _a;
  const issues = [];
  const fmMatch = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (!fmMatch) {
    issues.push({ severity: "error", message: "schema.md is missing YAML frontmatter block" });
    return issues;
  }
  const bodyText = (_a = fmMatch[2]) != null ? _a : "";
  if (!/^version::\s*"?[^"\s]+"?\s*$/m.test(bodyText)) {
    issues.push({
      severity: "error",
      message: "schema.md body is missing 'version:: ...' inline metadata"
    });
  }
  const contractYaml = extractContractBlock(bodyText);
  if (!contractYaml) {
    issues.push({
      severity: "error",
      message: "Could not find a fenced YAML block under # Contract in schema.md"
    });
    return issues;
  }
  try {
    const contract = (0, import_obsidian6.parseYaml)(contractYaml);
    if (!contract) {
      issues.push({ severity: "error", message: "Schema contract block is empty" });
      return issues;
    }
    if (!contract.required_fields) {
      issues.push({ severity: "error", message: "Schema contract is missing required_fields" });
    }
    if (!contract.tag_rules) {
      issues.push({ severity: "warning", message: "Schema contract is missing tag_rules" });
    }
    const contractMeta = contract.meta;
    if (contractMeta == null ? void 0 : contractMeta.version) {
      issues.push({
        severity: "error",
        message: "Do not define meta.version in the schema YAML block \u2014 use 'version:: ...' in the body instead"
      });
    }
  } catch (e) {
    issues.push({
      severity: "error",
      message: `Schema contract YAML is not parseable: ${e}`
    });
  }
  return issues;
}
function extractContractBlock(bodyText) {
  const underContract = bodyText.match(
    /^#\s+Contract\s*$[\s\S]*?^```+\s*yaml\s*\r?\n([\s\S]*?)^```+\s*$/m
  );
  if (underContract)
    return underContract[1].trim();
  const anywhere = bodyText.match(/^```+\s*yaml\s*\r?\n([\s\S]*?)^```+\s*$/m);
  if (anywhere)
    return anywhere[1].trim();
  return null;
}
function coerceFieldArray(raw) {
  if (!Array.isArray(raw))
    return [];
  return raw.filter((item) => item !== null && typeof item === "object").map((item) => {
    var _a, _b, _c;
    return {
      name: String((_a = item.name) != null ? _a : ""),
      type: (_b = item.type) != null ? _b : "string",
      values: Array.isArray(item.values) ? item.values.map(String) : void 0,
      severity: (_c = item.severity) != null ? _c : "warning",
      min_items: item.min_items !== void 0 ? Number(item.min_items) : void 0,
      strict_parse: item.strict_parse !== void 0 ? Boolean(item.strict_parse) : void 0,
      stale_after_days: item.stale_after_days !== void 0 ? Number(item.stale_after_days) : void 0,
      description: item.description ? String(item.description) : void 0,
      lint_rules: Array.isArray(item.lint_rules) ? item.lint_rules : void 0
    };
  }).filter((f) => f.name.length > 0);
}

// src/settings-tab.ts
var TABS = [
  { id: "general", label: "General" },
  { id: "lint", label: "Lint" },
  { id: "patch", label: "Patch" },
  { id: "maintenance", label: "Maintenance" },
  { id: "export", label: "Export" },
  { id: "shapes", label: "Shapes" }
];
var ForgeSettingsTab = class extends import_obsidian9.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.activeTab = "general";
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    this.injectStyles();
    const tabBar = containerEl.createDiv({ cls: "forge-tab-bar" });
    TABS.forEach(({ id, label }) => {
      const btn = tabBar.createEl("button", {
        text: label,
        cls: ["forge-tab-btn", id === this.activeTab ? "is-active" : ""]
      });
      btn.addEventListener("click", () => {
        this.activeTab = id;
        this.display();
      });
    });
    const content = containerEl.createDiv({ cls: "forge-tab-content" });
    switch (this.activeTab) {
      case "general":
        this.renderGeneral(content);
        break;
      case "lint":
        this.renderLint(content);
        break;
      case "patch":
        this.renderPatch(content);
        break;
      case "maintenance":
        this.renderMaintenance(content);
        break;
      case "export":
        this.renderExport(content);
        break;
      case "shapes":
        this.renderShapes(content);
        break;
    }
  }
  // ── General ──────────────────────────────────────────────────────────────
  renderGeneral(el) {
    new import_obsidian9.Setting(el).setName("Install Documentation").setDesc(
      "Writes vault-native docs into your Forge folder \u2014 command reference, schema guide, patch examples, and troubleshooting. Skips notes that already exist."
    ).addButton(
      (btn) => btn.setButtonText("Install Docs").setCta().onClick(async () => {
        await installVaultForgeDocumentation(this.plugin.app, this.plugin.settings);
      })
    );
    el.createEl("h3", { text: "System Paths" });
    el.createEl("p", {
      text: "All paths are relative to your vault root.",
      cls: "setting-item-description"
    });
    this.renderFolderPicker(
      el,
      "System folder",
      "Root folder for all vault system files.",
      "systemFolder",
      "System"
    );
    this.renderFolderPicker(
      el,
      "Forge folder",
      "Folder for Forge configuration and patch archives.",
      "forgeFolder",
      "System/Forge"
    );
    this.renderFrontmatterFieldOrder(el);
  }
  // ── Frontmatter field order ───────────────────────────────────────────────
  renderFrontmatterFieldOrder(el) {
    el.createEl("h3", { text: "Frontmatter Field Order" });
    el.createEl("p", {
      text: "Fields are written in this order when Forge modifies a note. Fields not listed here are appended alphabetically. Use 'Prefill from schema' to seed this list from your schema.md, or add fields manually. Drag to reorder, \xD7 to remove.",
      cls: "setting-item-description"
    });
    const listEl = el.createDiv({ cls: "forge-field-order-list" });
    const save = async () => {
      const items = Array.from(listEl.querySelectorAll(".forge-field-order-item"));
      this.plugin.settings.frontmatterFieldOrder = items.map(
        (item) => {
          var _a;
          return (_a = item.dataset.field) != null ? _a : "";
        }
      ).filter(Boolean);
      await this.plugin.saveSettings();
    };
    const renderItem = (field) => {
      const item = listEl.createDiv({ cls: "forge-field-order-item", attr: { draggable: "true", "data-field": field } });
      const handle = item.createSpan({ cls: "forge-field-order-handle", text: "\u283F" });
      handle.title = "Drag to reorder";
      item.createSpan({ cls: "forge-field-order-name", text: field });
      const rm = item.createSpan({ cls: "forge-field-order-rm", text: "\xD7" });
      rm.title = "Remove";
      rm.addEventListener("click", async () => {
        item.remove();
        await save();
      });
      item.addEventListener("dragstart", (e) => {
        var _a;
        item.classList.add("forge-field-order-dragging");
        (_a = e.dataTransfer) == null ? void 0 : _a.setData("text/plain", field);
      });
      item.addEventListener("dragend", async () => {
        item.classList.remove("forge-field-order-dragging");
        await save();
      });
      item.addEventListener("dragover", (e) => {
        e.preventDefault();
        const dragging = listEl.querySelector(".forge-field-order-dragging");
        if (!dragging || dragging === item)
          return;
        const rect = item.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;
        if (e.clientY < midY) {
          listEl.insertBefore(dragging, item);
        } else {
          listEl.insertBefore(dragging, item.nextSibling);
        }
      });
    };
    for (const field of this.plugin.settings.frontmatterFieldOrder) {
      renderItem(field);
    }
    const addRow = el.createDiv({ cls: "forge-field-order-add-row" });
    const input = addRow.createEl("input", {
      type: "text",
      cls: "forge-field-order-input",
      attr: { placeholder: "field_name" }
    });
    const addBtn = addRow.createEl("button", {
      text: "Add",
      cls: "forge-field-order-add-btn"
    });
    const doAdd = async () => {
      const val = input.value.trim().toLowerCase().replace(/\s+/g, "_");
      if (!val)
        return;
      const existing = this.plugin.settings.frontmatterFieldOrder;
      if (existing.includes(val)) {
        new import_obsidian9.Notice(`'${val}' is already in the list`);
        return;
      }
      this.plugin.settings.frontmatterFieldOrder = [...existing, val];
      await this.plugin.saveSettings();
      renderItem(val);
      input.value = "";
    };
    addBtn.addEventListener("click", doAdd);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter")
        doAdd();
    });
    new import_obsidian9.Setting(el).setName("Prefill from schema").setDesc(
      "Replace the field order with required + optional fields from schema.md, in the order they appear in the schema."
    ).addButton(
      (btn) => btn.setButtonText("Prefill").onClick(async () => {
        const schema = await loadSchema(this.plugin.app, this.plugin.settings);
        if (!schema) {
          new import_obsidian9.Notice("Forge: Could not load schema \u2014 is schema.md present?");
          return;
        }
        const schemaFields = [
          ...schema.required_fields.map((f) => f.name),
          ...schema.optional_fields.map((f) => f.name)
        ];
        const seen = /* @__PURE__ */ new Set();
        const deduped = schemaFields.filter((f) => {
          if (seen.has(f))
            return false;
          seen.add(f);
          return true;
        });
        this.plugin.settings.frontmatterFieldOrder = deduped;
        await this.plugin.saveSettings();
        this.display();
      })
    );
  }
  // ── Lint ─────────────────────────────────────────────────────────────────
  renderLint(el) {
    this.renderSchemaNotePicker(el);
    this.renderFolderPicker(
      el,
      "Lint reports folder",
      "Folder where lint run reports are written.",
      "lintRunsFolder",
      "System/Exports/LintReports"
    );
    new import_obsidian9.Setting(el).setName("Strict mode").setDesc("Treat warnings as errors.").addToggle(
      (t) => t.setValue(this.plugin.settings.lintStrictMode).onChange(async (v) => {
        this.plugin.settings.lintStrictMode = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Lint run retention").setDesc("Number of lint run notes to keep.").addSlider(
      (s) => s.setLimits(5, 100, 5).setValue(this.plugin.settings.lintRunRetentionCount).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.lintRunRetentionCount = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Lint file links").setDesc(
      "Wrap file paths in [[wikilinks]] in lint run notes so you can navigate directly to affected files."
    ).addToggle(
      (t) => t.setValue(this.plugin.settings.lintFileLinks).onChange(async (v) => {
        this.plugin.settings.lintFileLinks = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Lint inline metadata").setDesc(
      "Check inline metadata (key:: value patterns) against the schema. Disable to skip all inline metadata rules."
    ).addToggle(
      (t) => t.setValue(this.plugin.settings.lintInlineMetadata).onChange(async (v) => {
        this.plugin.settings.lintInlineMetadata = v;
        await this.plugin.saveSettings();
      })
    );
    el.createEl("h3", { text: "Stale Note Review" });
    new import_obsidian9.Setting(el).setName("Enable stale note review").setDesc(
      "Flag notes whose review cycle has elapsed, based on frontmatter field values."
    ).addToggle(
      (t) => t.setValue(this.plugin.settings.staleReviewEnabled).onChange(async (v) => {
        this.plugin.settings.staleReviewEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (!this.plugin.settings.staleReviewEnabled)
      return;
    const allFields = this.plugin.schemaCache.getFieldNames();
    this.renderSchemaFieldDropdown(
      el,
      "Review cycle field",
      "The frontmatter field that holds the review cadence. Must be an enum field in your schema with values: daily, weekly, monthly, quarterly, yearly, never.",
      allFields,
      this.plugin.settings.staleReviewCycleField,
      async (v) => {
        this.plugin.settings.staleReviewCycleField = v;
        await this.plugin.saveSettings();
      }
    );
    this.renderSchemaFieldDropdown(
      el,
      "Last updated field",
      "The frontmatter field that holds the last-updated date (e.g. updated).",
      allFields,
      this.plugin.settings.staleReviewUpdatedField,
      async (v) => {
        this.plugin.settings.staleReviewUpdatedField = v;
        await this.plugin.saveSettings();
      }
    );
    this.renderSchemaFieldDropdown(
      el,
      "In-scope field",
      "Schema field used to determine which notes are in scope for stale review (e.g. status).",
      allFields,
      this.plugin.settings.staleReviewFilterField,
      async (v) => {
        this.plugin.settings.staleReviewFilterField = v;
        this.plugin.settings.staleReviewStatuses = [];
        await this.plugin.saveSettings();
        this.display();
      }
    );
    if (this.plugin.settings.staleReviewFilterField) {
      const filterValues = this.plugin.schemaCache.getEnumValues(
        this.plugin.settings.staleReviewFilterField
      );
      if (filterValues && filterValues.length > 0) {
        new import_obsidian9.Setting(el).setName("In-scope values").setDesc(
          `Notes whose '${this.plugin.settings.staleReviewFilterField}' matches one of these values will be evaluated for staleness. Leave empty to skip stale review.`
        );
        this.renderCheckboxGroup(
          el,
          filterValues,
          this.plugin.settings.staleReviewStatuses,
          async (selected) => {
            this.plugin.settings.staleReviewStatuses = selected;
            await this.plugin.saveSettings();
          }
        );
      } else {
        el.createEl("p", {
          text: `'${this.plugin.settings.staleReviewFilterField}' has no defined enum values in schema \u2014 choose a different field or add values to your schema.`,
          cls: "setting-item-description"
        });
      }
    }
  }
  // ── Patch ─────────────────────────────────────────────────────────────────
  renderPatch(el) {
    this.renderFolderPicker(
      el,
      "Patches folder",
      "Folder where applied patch files are archived.",
      "patchesFolder",
      "System/Forge/Patches"
    );
    this.renderFolderPicker(
      el,
      "Inbox folder",
      "Folder for draft notes awaiting processing.",
      "inboxFolder",
      "System/Inbox"
    );
    this.renderPatchFilePicker(el);
    new import_obsidian9.Setting(el).setName("Backup before patch").setDesc("Create a backup of each modified file before applying a patch.").addToggle(
      (t) => t.setValue(this.plugin.settings.patchBackupEnabled).onChange(async (v) => {
        this.plugin.settings.patchBackupEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (this.plugin.settings.patchBackupEnabled) {
      const backupCurrent = this.plugin.settings.patchBackupFolder || "System/Forge/Patches/Backups";
      new import_obsidian9.Setting(el).setName("Backup folder").setDesc(
        `Folder where patch backups are stored. Current: ${backupCurrent}. Note: the restore script must be able to find this location \u2014 verify before changing.`
      ).addButton(
        (btn) => btn.setButtonText("Choose").onClick(() => {
          new FolderSuggestModal(this.app, async (folder) => {
            this.plugin.settings.patchBackupFolder = folder.path;
            await this.plugin.saveSettings();
            this.display();
          }).open();
        })
      );
      new import_obsidian9.Setting(el).setName("Generate restore manifest").setDesc(
        "Write a manifest file alongside each patch run so you can restore a full patch run in one step. Only active when backups are enabled."
      ).addToggle(
        (t) => t.setValue(this.plugin.settings.patchGenerateManifest).onChange(async (v) => {
          this.plugin.settings.patchGenerateManifest = v;
          await this.plugin.saveSettings();
        })
      );
    }
    new import_obsidian9.Setting(el).setName("Run lint after patch").setDesc("Automatically run Vault Lint after a patch is applied.").addToggle(
      (t) => t.setValue(this.plugin.settings.patchAutoLintAfterApply).onChange(async (v) => {
        this.plugin.settings.patchAutoLintAfterApply = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Run maintenance after patch").setDesc("Automatically run Vault Maintenance after a patch is applied.").addToggle(
      (t) => t.setValue(this.plugin.settings.patchAutoMaintenanceAfterApply).onChange(async (v) => {
        this.plugin.settings.patchAutoMaintenanceAfterApply = v;
        await this.plugin.saveSettings();
      })
    );
  }
  // ── Maintenance ───────────────────────────────────────────────────────────
  renderMaintenance(el) {
    new import_obsidian9.Setting(el).setName("Backup retention (days)").setDesc("Delete patch backup files older than this many days.").addSlider(
      (s) => s.setLimits(1, 90, 1).setValue(this.plugin.settings.backupRetentionDays).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.backupRetentionDays = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Inbox retention (days)").setDesc("Flag inbox files older than this many days as stale.").addSlider(
      (s) => s.setLimits(1, 90, 1).setValue(this.plugin.settings.inboxRetentionDays).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.inboxRetentionDays = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Lint history retention (days)").setDesc("Trim lint history entries older than this many days.").addSlider(
      (s) => s.setLimits(1, 365, 1).setValue(this.plugin.settings.lintHistoryRetentionDays).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.lintHistoryRetentionDays = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Lint history max entries").setDesc("Hard cap on the number of lint history entries to retain.").addSlider(
      (s) => s.setLimits(10, 500, 10).setValue(this.plugin.settings.lintHistoryMaxEntries).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.lintHistoryMaxEntries = v;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Patch report retention").setDesc("Number of patch report notes to keep.").addSlider(
      (s) => s.setLimits(5, 100, 5).setValue(this.plugin.settings.patchReportRetentionCount).setDynamicTooltip().onChange(async (v) => {
        this.plugin.settings.patchReportRetentionCount = v;
        await this.plugin.saveSettings();
      })
    );
  }
  // ── Export ────────────────────────────────────────────────────────────────
  renderExport(el) {
    new import_obsidian9.Setting(el).setName("Enable export").setDesc("Enables vault inventory, meta, and ontology export commands.").addToggle(
      (t) => t.setValue(this.plugin.settings.exportEnabled).onChange(async (v) => {
        this.plugin.settings.exportEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (!this.plugin.settings.exportEnabled)
      return;
    this.renderFolderPicker(
      el,
      "Exports folder",
      "Folder where inventory and index files are written.",
      "exportsFolder",
      "System/Exports"
    );
    el.createEl("h3", { text: "Run Exports" });
    new import_obsidian9.Setting(el).setName("Export Vault Overview").setDesc("Builds vault-inventory.json, vault-meta.json, and vault-overview.md in one pass. Inventory is schema-optional; meta requires schema and excludes ai_private notes.").addButton(
      (btn) => btn.setButtonText("Run").onClick(async () => {
        runExportOverview(this.plugin).catch((e) => {
          var _a;
          new import_obsidian9.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
        });
      })
    );
    new import_obsidian9.Setting(el).setName("Export Ontology Index").setDesc(
      "Builds per-type relationship indexes using the inventory and the filter settings below. Runs inventory export first if no inventory file is on disk."
    ).addButton(
      (btn) => btn.setButtonText("Run").onClick(async () => {
        runExportOntology(this.plugin).catch((e) => {
          var _a;
          new import_obsidian9.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
        });
      })
    );
    el.createEl("h3", { text: "Overview Options" });
    const allFieldsForDomain = this.plugin.schemaCache.getFieldNames();
    this.renderSchemaFieldDropdown(
      el,
      "Domain field",
      "Which frontmatter field represents a note's domain. Leave blank to use the parent folder.",
      allFieldsForDomain,
      this.plugin.settings.exportDomainField,
      async (v) => {
        this.plugin.settings.exportDomainField = v;
        await this.plugin.saveSettings();
      }
    );
    this.renderSchemaFieldDropdown(
      el,
      "Type field",
      "Which frontmatter field represents a note's type. Leave blank to use 'type'.",
      allFieldsForDomain,
      this.plugin.settings.exportTypeField,
      async (v) => {
        this.plugin.settings.exportTypeField = v;
        await this.plugin.saveSettings();
      }
    );
    this.renderSchemaFieldDropdown(
      el,
      "Status field",
      "Which frontmatter field represents a note's lifecycle status. Leave blank to use 'status'.",
      allFieldsForDomain,
      this.plugin.settings.exportStatusField,
      async (v) => {
        this.plugin.settings.exportStatusField = v;
        await this.plugin.saveSettings();
      }
    );
    new import_obsidian9.Setting(el).setName("Dashboard note name").setDesc("Filename for the Dataview dashboard note created on first export run. Leave blank to use 'vault-dashboard'.").addText(
      (t) => t.setPlaceholder("vault-dashboard").setValue(this.plugin.settings.exportDashboardName).onChange(async (v) => {
        this.plugin.settings.exportDashboardName = v.trim();
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian9.Setting(el).setName("Private notes").setDesc("When enabled, notes marked as private are counted separately in the overview and excluded from vault-meta.json.").addToggle(
      (t) => t.setValue(this.plugin.settings.exportPrivateEnabled).onChange(async (v) => {
        this.plugin.settings.exportPrivateEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (this.plugin.settings.exportPrivateEnabled) {
      const allFieldsForPrivate = this.plugin.schemaCache.getFieldNames();
      this.renderSchemaFieldDropdown(
        el,
        "Private note field",
        "The frontmatter field that signals a note as private (e.g. ai_private, private, draft). Any truthy value marks the note as private.",
        allFieldsForPrivate,
        this.plugin.settings.exportPrivateField,
        async (v) => {
          this.plugin.settings.exportPrivateField = v;
          await this.plugin.saveSettings();
        }
      );
    }
    el.createEl("h3", { text: "Ontology Filter" });
    el.createEl("p", {
      text: "Select which notes are included in the ontology export by choosing a schema field and the values to match.",
      cls: "setting-item-description"
    });
    new import_obsidian9.Setting(el).setName("Reload from schema").setDesc("Refresh field and value lists from the current schema.").addButton(
      (btn) => btn.setButtonText("Reload").onClick(async () => {
        await this.plugin.schemaCache.refresh();
        new import_obsidian9.Notice("Forge: schema reloaded.");
        this.display();
      })
    );
    const allFields = this.plugin.schemaCache.getFieldNames();
    this.renderSchemaFieldDropdown(
      el,
      "Filter field",
      "The schema field to filter notes by. Only notes matching the selected values will be indexed.",
      allFields,
      this.plugin.settings.exportFilterField,
      async (v) => {
        this.plugin.settings.exportFilterField = v;
        this.plugin.settings.exportFilterValues = [];
        await this.plugin.saveSettings();
        this.display();
      }
    );
    if (this.plugin.settings.exportFilterField) {
      const fieldValues = this.plugin.schemaCache.getEnumValues(
        this.plugin.settings.exportFilterField
      );
      if (fieldValues && fieldValues.length > 0) {
        new import_obsidian9.Setting(el).setName("Filter values").setDesc(
          `Select which values of '${this.plugin.settings.exportFilterField}' to include. Notes matching any selected value will be included in the ontology export.`
        );
        this.renderCheckboxGroup(
          el,
          fieldValues,
          this.plugin.settings.exportFilterValues,
          async (selected) => {
            this.plugin.settings.exportFilterValues = selected;
            await this.plugin.saveSettings();
          }
        );
      } else {
        el.createEl("p", {
          text: `'${this.plugin.settings.exportFilterField}' is not an enum field \u2014 no values to select. Choose a field with defined allowed values.`,
          cls: "setting-item-description"
        });
      }
    }
    el.createEl("h3", { text: "Relationship Extraction" });
    new import_obsidian9.Setting(el).setName("Relationship heading").setDesc(
      "The top-level heading under which relationship links are organised in your notes. Enter without the # \u2014 e.g. 'Related'. Subheadings under this heading become relationship keys."
    ).addText(
      (t) => t.setPlaceholder("Related").setValue(this.plugin.settings.exportRelationshipHeading).onChange(async (v) => {
        this.plugin.settings.exportRelationshipHeading = v.trim();
        await this.plugin.saveSettings();
      })
    );
    el.createEl("h3", { text: "Exclude Folders" });
    el.createEl("p", {
      text: "Notes inside these folders are skipped during ontology export. Applies at any depth \u2014 add a top-level folder to exclude everything under it.",
      cls: "setting-item-description"
    });
    new import_obsidian9.Setting(el).setName("Excluded folders").setDesc("Add folders to exclude from ontology indexing.");
    this.renderFolderMultiSelect(el);
  }
  /** Folder multi-select for ontology exclusions — uses the dropdown+chips pattern. */
  renderFolderMultiSelect(el) {
    const selected = this.plugin.settings.exportExcludeFolders;
    const wrap = el.createDiv({ cls: "forge-multiselect" });
    const chipStrip = wrap.createDiv({ cls: "forge-ms-chips" });
    const renderChips = () => {
      chipStrip.empty();
      selected.forEach((val) => {
        const chip = chipStrip.createDiv({ cls: "forge-ms-chip" });
        chip.createSpan({ text: val });
        const rm = chip.createSpan({ cls: "forge-ms-chip-rm", text: "\xD7" });
        rm.addEventListener("click", async (e) => {
          e.stopPropagation();
          const idx = selected.indexOf(val);
          if (idx > -1)
            selected.splice(idx, 1);
          renderChips();
          updateTrigger();
          await this.plugin.saveSettings();
        });
      });
    };
    const trigger = wrap.createDiv({ cls: "forge-ms-trigger" });
    const triggerLabel = trigger.createSpan({ cls: "forge-ms-trigger-label" });
    const triggerIcon = trigger.createSpan({ cls: "forge-ms-trigger-icon", text: "\u25BE" });
    const updateTrigger = () => {
      triggerLabel.setText(
        selected.length === 0 ? "Add folders to exclude\u2026" : `${selected.length} folder(s) excluded`
      );
    };
    const panel = wrap.createDiv({ cls: "forge-ms-panel forge-ms-hidden" });
    const folders = [];
    const walk = (node) => {
      if (node instanceof import_obsidian9.TFolder) {
        if (node.path && node.path !== "/")
          folders.push(node.path);
        node.children.forEach(walk);
      }
    };
    walk(this.app.vault.getRoot());
    folders.sort();
    folders.forEach((folderPath) => {
      const row = panel.createDiv({ cls: "forge-ms-row" });
      const box = row.createDiv({ cls: "forge-ms-box" });
      row.createSpan({ text: folderPath, cls: "forge-ms-row-label" });
      const setChecked = (checked) => {
        box.toggleClass("forge-ms-box-checked", checked);
        box.setText(checked ? "\u2713" : "");
      };
      setChecked(selected.includes(folderPath));
      row.addEventListener("click", async () => {
        const idx = selected.indexOf(folderPath);
        if (idx > -1) {
          selected.splice(idx, 1);
          setChecked(false);
        } else {
          selected.push(folderPath);
          setChecked(true);
        }
        renderChips();
        updateTrigger();
        await this.plugin.saveSettings();
      });
    });
    let open = false;
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      open = !open;
      panel.toggleClass("forge-ms-hidden", !open);
      triggerIcon.setText(open ? "\u25B4" : "\u25BE");
    });
    const onOutside = (e) => {
      if (!wrap.contains(e.target)) {
        open = false;
        panel.addClass("forge-ms-hidden");
        triggerIcon.setText("\u25BE");
      }
    };
    document.addEventListener("click", onOutside);
    const observer = new MutationObserver(() => {
      if (!document.contains(wrap)) {
        document.removeEventListener("click", onOutside);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    renderChips();
    updateTrigger();
  }
  // ── Shapes ──────────────────────────────────────────────────────────────
  renderShapes(el) {
    const s = this.plugin.settings;
    new import_obsidian9.Setting(el).setName("Enable Vault Shape Engine").setDesc("Enables shape note processing and template refinement.").addToggle(
      (t) => t.setValue(s.shapesEnabled).onChange(async (v) => {
        s.shapesEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (!s.shapesEnabled)
      return;
    el.createEl("h3", { text: "Folders" });
    this.renderFolderPicker(
      el,
      "Shapes folder",
      "Folder containing shape notes (type: shape, with a # Structure section).",
      "shapesFolder",
      "System/Shapes"
    );
    el.createEl("h3", { text: "Template Refinement" });
    el.createEl("p", {
      text: "When enabled, the 'Refine Shape Templates' command reads each shape note and writes or updates the corresponding template note.",
      cls: "setting-item-description"
    });
    new import_obsidian9.Setting(el).setName("Enable template refinement").setDesc("Allow the Refine Shape Templates command to create and update template notes.").addToggle(
      (t) => t.setValue(s.shapeRefinementEnabled).onChange(async (v) => {
        s.shapeRefinementEnabled = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (!s.shapeRefinementEnabled)
      return;
    this.renderFolderPicker(
      el,
      "Templates folder",
      "Folder where template notes are written.",
      "shapeTemplatesFolder",
      "System/Templates"
    );
    new import_obsidian9.Setting(el).setName("Run refinement").setDesc("Process all shape notes and write or update template notes now.").addButton(
      (btn) => btn.setButtonText("Refine Shape Templates").setCta().onClick(async () => {
        const { runRefineShapes: runRefineShapes2 } = await Promise.resolve().then(() => (init_refine_shapes(), refine_shapes_exports));
        await runRefineShapes2(this.plugin);
      })
    );
    el.createEl("h3", { text: "Template Field Configuration" });
    el.createEl("p", {
      text: "Configure which schema fields appear in generated templates and what value each gets. The type target field always receives the shape name. created and updated are set automatically at runtime.",
      cls: "setting-item-description"
    });
    this.renderShapeTypeTargetField(el);
    this.renderShapeFieldConfigurator(el);
  }
  renderShapeTypeTargetField(el) {
    const s = this.plugin.settings;
    new import_obsidian9.Setting(el).setName("Type target field").setDesc(
      "The schema field that receives the shape name when a template is generated. Load schema to populate this dropdown."
    ).addDropdown(async (dd) => {
      var _a;
      dd.addOption("", "\u2014 load schema to populate \u2014");
      const schema = await loadSchema(this.plugin.app, s);
      if (schema) {
        const allFields = [
          ...schema.required_fields.map((f) => f.name),
          ...schema.optional_fields.map((f) => f.name)
        ];
        for (const name of allFields) {
          dd.addOption(name, name);
        }
        const current = s.shapeTypeTargetField || "type";
        dd.setValue(allFields.includes(current) ? current : (_a = allFields[0]) != null ? _a : "");
      } else {
        dd.setValue(s.shapeTypeTargetField || "");
      }
      dd.onChange(async (v) => {
        s.shapeTypeTargetField = v;
        await this.plugin.saveSettings();
      });
    });
  }
  renderShapeFieldConfigurator(el) {
    const s = this.plugin.settings;
    const container = el.createDiv({ cls: "forge-shape-fields" });
    loadSchema(this.plugin.app, s).then((schema) => {
      if (!schema) {
        container.createEl("p", {
          text: "Could not load schema. Ensure schema.md exists and is valid.",
          cls: "setting-item-description"
        });
        return;
      }
      const allFields = [
        ...schema.required_fields,
        ...schema.optional_fields
      ];
      const order = s.frontmatterFieldOrder;
      const ordered = order.length > 0 ? [
        ...order.map((name) => allFields.find((f) => f.name === name)).filter((f) => f != null),
        ...allFields.filter((f) => !order.includes(f.name))
      ] : allFields;
      const runtimeFields = /* @__PURE__ */ new Set(["created", "updated"]);
      const configurable = ordered.filter((f) => !runtimeFields.has(f.name));
      if (configurable.length === 0) {
        container.createEl("p", {
          text: "No configurable fields found in schema.",
          cls: "setting-item-description"
        });
        return;
      }
      const header = container.createDiv({ cls: "forge-shape-field-header" });
      header.createSpan({ text: "Include", cls: "forge-shape-field-col-include" });
      header.createSpan({ text: "Field", cls: "forge-shape-field-col-name" });
      header.createSpan({ text: "Value", cls: "forge-shape-field-col-value" });
      for (const field of configurable) {
        this.renderShapeFieldRow(container, field, s);
      }
      container.createEl("p", {
        text: "created and updated are set automatically and are not configurable here.",
        cls: "setting-item-description forge-shape-runtime-note"
      });
    });
  }
  renderShapeFieldRow(container, field, s) {
    var _a;
    const fieldName = field.name;
    const existing = (_a = s.shapeTemplateFields[fieldName]) != null ? _a : { include: false, value: "" };
    const row = container.createDiv({ cls: "forge-shape-field-row" });
    const includeWrap = row.createDiv({ cls: "forge-shape-field-col-include" });
    const checkbox = includeWrap.createEl("input", { type: "checkbox" });
    checkbox.checked = existing.include;
    row.createSpan({ text: fieldName, cls: "forge-shape-field-col-name forge-field-name" });
    const valueWrap = row.createDiv({ cls: "forge-shape-field-col-value" });
    const valueControl = this.createShapeFieldValueControl(valueWrap, field, existing.value, existing.include);
    const save = async () => {
      s.shapeTemplateFields[fieldName] = {
        include: checkbox.checked,
        value: valueControl.getValue()
      };
      await this.plugin.saveSettings();
    };
    checkbox.addEventListener("change", async () => {
      valueControl.setEnabled(checkbox.checked);
      await save();
    });
    valueControl.setEnabled(existing.include);
    valueControl.onChanged(save);
  }
  createShapeFieldValueControl(container, field, currentValue, enabled) {
    let onChange = null;
    const notify = () => onChange == null ? void 0 : onChange();
    if (field.type === "enum" && field.values && field.values.length > 0) {
      const select = container.createEl("select", { cls: "forge-shape-field-select" });
      const emptyOpt = select.createEl("option", { value: "", text: "\u2014 none \u2014" });
      for (const val of field.values) {
        const opt = select.createEl("option", { value: val, text: val });
        if (val === String(currentValue != null ? currentValue : ""))
          opt.selected = true;
      }
      if (!currentValue)
        emptyOpt.selected = true;
      select.addEventListener("change", notify);
      return {
        getValue: () => select.value || "",
        setEnabled: (v) => {
          select.disabled = !v;
        },
        onChanged: (cb) => {
          onChange = cb;
        }
      };
    }
    if (field.type === "boolean") {
      const select = container.createEl("select", { cls: "forge-shape-field-select" });
      select.createEl("option", { value: "", text: "\u2014 none \u2014" });
      select.createEl("option", { value: "true", text: "true" });
      select.createEl("option", { value: "false", text: "false" });
      const strVal = currentValue === true ? "true" : currentValue === false ? "false" : "";
      select.value = strVal;
      select.addEventListener("change", notify);
      return {
        getValue: () => {
          if (select.value === "true")
            return true;
          if (select.value === "false")
            return false;
          return "";
        },
        setEnabled: (v) => {
          select.disabled = !v;
        },
        onChanged: (cb) => {
          onChange = cb;
        }
      };
    }
    if (field.type === "list") {
      const input2 = container.createEl("input", {
        type: "text",
        cls: "forge-shape-field-input",
        attr: { placeholder: "value1, value2" }
      });
      const arr = Array.isArray(currentValue) ? currentValue.join(", ") : String(currentValue != null ? currentValue : "");
      input2.value = arr;
      input2.addEventListener("input", notify);
      return {
        getValue: () => input2.value.split(",").map((v) => v.trim()).filter(Boolean),
        setEnabled: (v) => {
          input2.disabled = !v;
        },
        onChanged: (cb) => {
          onChange = cb;
        }
      };
    }
    const input = container.createEl("input", {
      type: "text",
      cls: "forge-shape-field-input",
      attr: { placeholder: field.type === "date" ? "yyyy-MM-dd" : "" }
    });
    input.value = String(currentValue != null ? currentValue : "");
    input.addEventListener("input", notify);
    return {
      getValue: () => input.value.trim(),
      setEnabled: (v) => {
        input.disabled = !v;
      },
      onChanged: (cb) => {
        onChange = cb;
      }
    };
  }
  // ── Shared helpers ────────────────────────────────────────────────────────
  /**
   * Renders a folder picker row. All folder pickers show only folders
   * via FolderSuggestModal — no files in the tree.
   */
  renderFolderPicker(el, name, desc, settingKey, fallback, _schemaNote = false) {
    var _a;
    const current = String((_a = this.plugin.settings[settingKey]) != null ? _a : fallback);
    new import_obsidian9.Setting(el).setName(name).setDesc(`${desc} Current: ${current}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new FolderSuggestModal(this.app, async (folder) => {
          this.plugin.settings[settingKey] = folder.path || fallback;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
  /** Schema note picker — selects a .md file, splits into folder + filename. */
  renderSchemaNotePicker(el) {
    const current = `${this.plugin.settings.schemaNoteFolder}/${this.plugin.settings.schemaNoteFile}`;
    new import_obsidian9.Setting(el).setName("Schema note").setDesc(`Path to schema.md relative to vault root. Current: ${current}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new MarkdownFileSuggestModal(this.app, async (file) => {
          const lastSlash = file.path.lastIndexOf("/");
          this.plugin.settings.schemaNoteFolder = lastSlash >= 0 ? file.path.substring(0, lastSlash) : "";
          this.plugin.settings.schemaNoteFile = lastSlash >= 0 ? file.path.substring(lastSlash + 1) : file.path;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
  /** Patch file picker — selects .md / .yaml / .yml files. */
  renderPatchFilePicker(el) {
    const fallback = "System/Forge/Patches/vault-patch.md";
    const current = this.plugin.settings.patchDefaultFile || fallback;
    new import_obsidian9.Setting(el).setName("Default patch file").setDesc(`Path to the patch note loaded by Apply Vault Patch. Current: ${current}`).addButton(
      (btn) => btn.setButtonText("Choose").onClick(() => {
        new PatchFileSuggestModal(this.app, async (file) => {
          this.plugin.settings.patchDefaultFile = file.path;
          await this.plugin.saveSettings();
          this.display();
        }).open();
      })
    );
  }
  /**
   * Single-select dropdown populated from a list of field names.
   * Emits the chosen value to the provided async handler.
   */
  renderSchemaFieldDropdown(el, name, desc, fields, currentValue, onChange) {
    const setting = new import_obsidian9.Setting(el).setName(name).setDesc(desc);
    if (fields.length === 0) {
      setting.setDesc(
        desc + " (No schema fields found \u2014 reload schema on the Export tab.)"
      );
      return;
    }
    setting.addDropdown((d) => {
      d.addOption("", "\u2014 select a field \u2014");
      fields.forEach((f) => d.addOption(f, f));
      d.setValue(currentValue).onChange(async (v) => {
        await onChange(v);
      });
    });
  }
  /**
   * Dropdown + chips multi-select.
   *
   * Renders a collapsed trigger showing how many values are selected.
   * Opens an inline checklist panel on click.
   * Selected values appear as removable chips above the trigger.
   * Scales cleanly from 2 to 50+ options.
   */
  renderCheckboxGroup(el, options, selected, onChange) {
    const wrap = el.createDiv({ cls: "forge-multiselect" });
    const chipStrip = wrap.createDiv({ cls: "forge-ms-chips" });
    const renderChips = () => {
      chipStrip.empty();
      selected.forEach((val) => {
        const chip = chipStrip.createDiv({ cls: "forge-ms-chip" });
        chip.createSpan({ text: val });
        const rm = chip.createSpan({ cls: "forge-ms-chip-rm", text: "\xD7" });
        rm.addEventListener("click", async (e) => {
          e.stopPropagation();
          const idx = selected.indexOf(val);
          if (idx > -1)
            selected.splice(idx, 1);
          renderChips();
          updateTrigger();
          await onChange([...selected]);
        });
      });
    };
    const trigger = wrap.createDiv({ cls: "forge-ms-trigger" });
    const triggerLabel = trigger.createSpan({ cls: "forge-ms-trigger-label" });
    const triggerIcon = trigger.createSpan({ cls: "forge-ms-trigger-icon", text: "\u25BE" });
    const updateTrigger = () => {
      triggerLabel.setText(
        selected.length === 0 ? "Select values\u2026" : `${selected.length} of ${options.length} selected`
      );
    };
    const panel = wrap.createDiv({ cls: "forge-ms-panel forge-ms-hidden" });
    options.forEach((val) => {
      const row = panel.createDiv({ cls: "forge-ms-row" });
      const box = row.createDiv({ cls: "forge-ms-box" });
      row.createSpan({ text: val, cls: "forge-ms-row-label" });
      const setChecked = (checked) => {
        box.toggleClass("forge-ms-box-checked", checked);
        box.setText(checked ? "\u2713" : "");
      };
      setChecked(selected.includes(val));
      row.addEventListener("click", async () => {
        const idx = selected.indexOf(val);
        if (idx > -1) {
          selected.splice(idx, 1);
          setChecked(false);
        } else {
          selected.push(val);
          setChecked(true);
        }
        renderChips();
        updateTrigger();
        await onChange([...selected]);
      });
    });
    let open = false;
    const togglePanel = (e) => {
      e.stopPropagation();
      open = !open;
      panel.toggleClass("forge-ms-hidden", !open);
      triggerIcon.setText(open ? "\u25B4" : "\u25BE");
    };
    trigger.addEventListener("click", togglePanel);
    const onOutside = (e) => {
      if (!wrap.contains(e.target)) {
        open = false;
        panel.addClass("forge-ms-hidden");
        triggerIcon.setText("\u25BE");
      }
    };
    document.addEventListener("click", onOutside);
    const observer = new MutationObserver(() => {
      if (!document.contains(wrap)) {
        document.removeEventListener("click", onOutside);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    renderChips();
    updateTrigger();
  }
  /** Inject tab bar and multiselect styles scoped to the settings container. */
  injectStyles() {
    if (this.containerEl.querySelector("#forge-tab-styles"))
      return;
    const style = document.createElement("style");
    style.id = "forge-tab-styles";
    style.textContent = `
      .forge-tab-bar {
        display: flex;
        gap: 4px;
        padding-bottom: 12px;
        border-bottom: 1px solid var(--background-modifier-border);
        margin-bottom: 16px;
        flex-wrap: wrap;
      }
      .forge-tab-btn {
        padding: 4px 12px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-secondary);
        color: var(--text-muted);
        cursor: pointer;
        font-size: var(--font-ui-small);
      }
      .forge-tab-btn:hover {
        background: var(--background-modifier-hover);
        color: var(--text-normal);
      }
      .forge-tab-btn.is-active {
        background: var(--interactive-accent);
        color: var(--text-on-accent);
        border-color: var(--interactive-accent);
      }
      .forge-multiselect {
        margin: 4px 0 8px 0;
        position: relative;
      }
      .forge-ms-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 6px;
        min-height: 0;
      }
      .forge-ms-chip {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: var(--font-ui-smaller);
        background: var(--interactive-accent);
        color: var(--text-on-accent);
      }
      .forge-ms-chip-rm {
        cursor: pointer;
        opacity: 0.7;
        font-size: 13px;
        line-height: 1;
      }
      .forge-ms-chip-rm:hover { opacity: 1; }
      .forge-ms-trigger {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 6px 10px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-secondary);
        cursor: pointer;
        user-select: none;
      }
      .forge-ms-trigger:hover { background: var(--background-modifier-hover); }
      .forge-ms-trigger-label {
        font-size: var(--font-ui-small);
        color: var(--text-muted);
      }
      .forge-ms-trigger-icon {
        font-size: 11px;
        color: var(--text-muted);
      }
      .forge-ms-panel {
        margin-top: 4px;
        border: 1px solid var(--background-modifier-border);
        border-radius: 4px;
        background: var(--background-primary);
        max-height: 240px;
        overflow-y: auto;
        z-index: 100;
      }
      .forge-ms-hidden { display: none; }
      .forge-ms-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 7px 12px;
        cursor: pointer;
        border-bottom: 1px solid var(--background-modifier-border-hover);
      }
      .forge-ms-row:last-child { border-bottom: none; }
      .forge-ms-row:hover { background: var(--background-modifier-hover); }
      .forge-ms-box {
        width: 16px;
        height: 16px;
        border-radius: 3px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        flex-shrink: 0;
        color: var(--text-on-accent);
      }
      .forge-ms-box-checked {
        background: var(--interactive-accent);
        border-color: var(--interactive-accent);
      }
      .forge-ms-row-label {
        font-size: var(--font-ui-small);
        color: var(--text-normal);
      }
      .forge-coming-soon {
        padding: 16px 0;
        opacity: 0.6;
      }
      .forge-field-order-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 8px 0 10px 0;
      }
      .forge-field-order-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 5px 10px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-secondary);
        cursor: default;
        user-select: none;
      }
      .forge-field-order-item.forge-field-order-dragging {
        opacity: 0.4;
      }
      .forge-field-order-handle {
        cursor: grab;
        color: var(--text-muted);
        font-size: 14px;
        line-height: 1;
        flex-shrink: 0;
      }
      .forge-field-order-handle:active { cursor: grabbing; }
      .forge-field-order-name {
        flex: 1;
        font-size: var(--font-ui-small);
        font-family: var(--font-monospace);
        color: var(--text-normal);
      }
      .forge-field-order-rm {
        cursor: pointer;
        color: var(--text-muted);
        font-size: 14px;
        line-height: 1;
        flex-shrink: 0;
      }
      .forge-field-order-rm:hover { color: var(--text-error); }
      .forge-field-order-add-row {
        display: flex;
        gap: 8px;
        margin-bottom: 12px;
      }
      .forge-field-order-input {
        flex: 1;
        padding: 5px 8px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-primary);
        color: var(--text-normal);
        font-size: var(--font-ui-small);
        font-family: var(--font-monospace);
      }
      .forge-field-order-add-btn {
        padding: 5px 14px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-secondary);
        color: var(--text-normal);
        cursor: pointer;
        font-size: var(--font-ui-small);
      }
      .forge-field-order-add-btn:hover {
        background: var(--background-modifier-hover);
      }
      .forge-shape-fields {
        margin: 8px 0 16px 0;
        border: 1px solid var(--background-modifier-border);
        border-radius: 4px;
        overflow: hidden;
      }
      .forge-shape-field-header {
        display: grid;
        grid-template-columns: 48px 180px 1fr;
        gap: 8px;
        padding: 6px 12px;
        background: var(--background-secondary);
        border-bottom: 1px solid var(--background-modifier-border);
        font-size: var(--font-ui-smaller);
        color: var(--text-muted);
        font-weight: 600;
      }
      .forge-shape-field-row {
        display: grid;
        grid-template-columns: 48px 180px 1fr;
        gap: 8px;
        padding: 6px 12px;
        align-items: center;
        border-bottom: 1px solid var(--background-modifier-border-hover);
      }
      .forge-shape-field-row:last-of-type {
        border-bottom: none;
      }
      .forge-shape-field-col-include {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .forge-shape-field-col-name {
        font-size: var(--font-ui-small);
      }
      .forge-shape-field-col-value {
        display: flex;
        align-items: center;
      }
      .forge-field-name {
        font-family: var(--font-monospace);
        color: var(--text-normal);
      }
      .forge-shape-field-select,
      .forge-shape-field-input {
        width: 100%;
        padding: 3px 6px;
        border-radius: 4px;
        border: 1px solid var(--background-modifier-border);
        background: var(--background-primary);
        color: var(--text-normal);
        font-size: var(--font-ui-small);
      }
      .forge-shape-field-select:disabled,
      .forge-shape-field-input:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .forge-shape-runtime-note {
        padding: 8px 12px;
        border-top: 1px solid var(--background-modifier-border);
        margin: 0;
      }
    `;
    this.containerEl.appendChild(style);
  }
};
var FolderSuggestModal = class extends import_obsidian9.FuzzySuggestModal {
  constructor(app, onChoose) {
    super(app);
    this.onChoose = onChoose;
    this.setPlaceholder("Choose a folder...");
  }
  getItems() {
    const folders = [];
    const walk = (node) => {
      if (node instanceof import_obsidian9.TFolder) {
        folders.push(node);
        node.children.forEach(walk);
      }
    };
    walk(this.app.vault.getRoot());
    return folders;
  }
  getItemText(folder) {
    return folder.path || "/";
  }
  onChooseItem(folder) {
    this.onChoose(folder);
  }
};
var MarkdownFileSuggestModal = class extends import_obsidian9.FuzzySuggestModal {
  constructor(app, onChoose) {
    super(app);
    this.onChoose = onChoose;
    this.setPlaceholder("Choose a markdown note...");
  }
  getItems() {
    return this.app.vault.getMarkdownFiles();
  }
  getItemText(file) {
    return file.path;
  }
  onChooseItem(file) {
    this.onChoose(file);
  }
};
var PatchFileSuggestModal = class extends import_obsidian9.FuzzySuggestModal {
  constructor(app, onChoose) {
    super(app);
    this.onChoose = onChoose;
    this.setPlaceholder("Choose a patch note or YAML file...");
  }
  getItems() {
    return this.app.vault.getFiles().filter((f) => {
      const p = f.path.toLowerCase();
      return p.endsWith(".md") || p.endsWith(".yaml") || p.endsWith(".yml");
    });
  }
  getItemText(file) {
    return file.path;
  }
  onChooseItem(file) {
    this.onChoose(file);
  }
};

// src/schema-cache.ts
init_files();
var SchemaCache = class {
  constructor(app, settings) {
    this.cache = null;
    this.app = app;
    this.settings = settings;
  }
  /**
   * Returns the cached schema, loading it first if not yet loaded.
   */
  async get() {
    if (!this.cache) {
      await this.refresh();
    }
    return this.cache;
  }
  /**
   * Forces a fresh load from schema.md.
   * Called after Validate Schema or settings changes.
   */
  async refresh() {
    this.cache = await loadSchema(this.app, this.settings);
    return this.cache;
  }
  /**
   * Returns the cached schema without loading — may be null.
   */
  peek() {
    return this.cache;
  }
  /**
   * Clears the cache — next get() will reload.
   */
  invalidate() {
    this.cache = null;
  }
  /**
   * Updates settings reference (called when settings change).
   * Only invalidates the cache if the schema path changed — non-path settings
   * (lint toggles, retention counts, etc.) don't affect the cached schema, so
   * there is no reason to clear a valid cache when they change.
   */
  updateSettings(settings) {
    const oldPath = `${this.settings.schemaNoteFolder}/${this.settings.schemaNoteFile}`;
    const newPath = `${settings.schemaNoteFolder}/${settings.schemaNoteFile}`;
    this.settings = settings;
    if (oldPath !== newPath) {
      this.invalidate();
    }
  }
  // ── Schema field helpers ────────────────────────────────────────────────────
  /**
   * Returns all field names from required + optional fields.
   */
  getFieldNames() {
    if (!this.cache)
      return [];
    return [
      ...this.cache.required_fields.map((f) => f.name),
      ...this.cache.optional_fields.map((f) => f.name)
    ];
  }
  /**
   * Returns all enum-type field names — these should have lowercased values.
   * Used by Normalize Frontmatter to replace the hardcoded field list.
   */
  getEnumFieldNames() {
    if (!this.cache)
      return [];
    return [
      ...this.cache.required_fields.filter((f) => f.type === "enum").map((f) => f.name),
      ...this.cache.optional_fields.filter((f) => f.type === "enum").map((f) => f.name)
    ];
  }
  /**
   * Returns allowed values for a specific field, or null if not an enum.
   */
  getEnumValues(fieldName) {
    if (!this.cache)
      return null;
    const all = [...this.cache.required_fields, ...this.cache.optional_fields];
    const field = all.find((f) => f.name === fieldName);
    if (!field || field.type !== "enum" || !field.values)
      return null;
    return field.values;
  }
  /**
   * Returns the field type for a given field name, or null if not found.
   */
  getFieldType(fieldName) {
    var _a;
    if (!this.cache)
      return null;
    const all = [...this.cache.required_fields, ...this.cache.optional_fields];
    const field = all.find((f) => f.name === fieldName);
    return (_a = field == null ? void 0 : field.type) != null ? _a : null;
  }
  /**
   * Returns a reasonable default value for a field based on its type and name.
   * Used by Vault Repair to pre-populate fields.
   */
  getDefaultValue(fieldName) {
    var _a, _b;
    const type = this.getFieldType(fieldName);
    const values = this.getEnumValues(fieldName);
    switch (fieldName) {
      case "created":
      case "updated":
      case "review_by":
        return todayString();
      case "ai_private":
        return false;
      case "review_cycle":
        return "never";
      case "status":
        return (values == null ? void 0 : values.includes("active")) ? "active" : (_a = values == null ? void 0 : values[0]) != null ? _a : "";
    }
    switch (type) {
      case "boolean":
        return false;
      case "enum":
        return (_b = values == null ? void 0 : values[0]) != null ? _b : "";
      case "date":
        return todayString();
      case "list":
        return [];
      default:
        return "";
    }
  }
};

// src/commands/apply-patch.ts
var import_obsidian15 = require("obsidian");
init_vault_paths();

// src/patch-engine.ts
var import_obsidian10 = require("obsidian");
init_vault_paths();
init_frontmatter();

// src/utils/tags.ts
function getTags(frontmatter) {
  const raw = frontmatter["tags"];
  if (raw === null || raw === void 0)
    return [];
  const list = Array.isArray(raw) ? raw : [raw];
  return list.filter((v) => v !== null && v !== void 0).map((v) => String(v).trim()).filter((v) => v.length > 0);
}
function setTags(frontmatter, tags) {
  frontmatter["tags"] = normalizeTags(tags);
}
function normalizeTags(tags) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const tag of tags) {
    const trimmed = tag.trim();
    if (!trimmed)
      continue;
    const lower = trimmed.toLowerCase();
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(trimmed);
    }
  }
  return result.sort(
    (a, b) => a.toLowerCase().localeCompare(b.toLowerCase())
  );
}
function addTag(tags, tag) {
  const trimmed = tag.trim();
  const lower = trimmed.toLowerCase();
  if (tags.some((t) => t.toLowerCase() === lower)) {
    return tags;
  }
  return [...tags, trimmed];
}
function removeTag(tags, tag) {
  const lower = tag.trim().toLowerCase();
  const filtered = tags.filter((t) => t.toLowerCase() !== lower);
  return filtered.length === tags.length ? tags : filtered;
}
function convertTagSeparator(tag) {
  const trimmed = tag.trim();
  if (/^[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+$/.test(trimmed)) {
    return trimmed.replace(":", "/");
  }
  return trimmed;
}
function isInvalidTag(tag) {
  const lower = tag.trim().toLowerCase();
  return /^(domain|status|type)(\/.*)?$/.test(lower);
}

// src/patch-engine.ts
init_files();
async function loadPatchFile(app, patchFilePath) {
  var _a;
  const file = app.vault.getAbstractFileByPath((0, import_obsidian10.normalizePath)(patchFilePath));
  if (!(file instanceof import_obsidian10.TFile)) {
    return null;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    console.warn(`[Forge] Could not read patch file: ${patchFilePath}`, e);
    return null;
  }
  try {
    const yamlText = extractPatchYaml(raw, patchFilePath);
    if (!yamlText.trim()) {
      console.warn(`[Forge] Patch file contains no YAML payload: ${patchFilePath}`);
      return null;
    }
    const parsed = (0, import_obsidian10.parseYaml)(yamlText);
    const meta = (_a = parsed == null ? void 0 : parsed.meta) != null ? _a : {};
    const operations = Array.isArray(parsed == null ? void 0 : parsed.operations) ? parsed.operations : [];
    return { meta, operations };
  } catch (e) {
    console.warn(`[Forge] Could not parse patch YAML:`, e);
    return null;
  }
}
async function applyPatch(app, settings, patchFile, patchFilePath, dryRun) {
  var _a, _b, _c, _d, _e;
  const paths = getVaultPaths(settings);
  const runId = safeTimestamp();
  const appliedAt = localTimestamp();
  const results = [];
  const manifest = [];
  const backedUp = /* @__PURE__ */ new Set();
  async function maybeBackup(file) {
    var _a2;
    if (!settings.patchBackupEnabled || dryRun)
      return null;
    if (backedUp.has(file.path)) {
      const existing = manifest.find((e) => e.file === file.path);
      return (_a2 = existing == null ? void 0 : existing.backup) != null ? _a2 : null;
    }
    const backupPath = await backupNote(app, file, paths.patchBackups);
    if (backupPath) {
      backedUp.add(file.path);
      manifest.push({ file: file.path, backup: backupPath });
    }
    return backupPath;
  }
  for (const op of patchFile.operations) {
    const opName = (_a = op.op) != null ? _a : "<unknown>";
    const targets = resolveTargets(app, op.target, op.target_pattern);
    if (targets.length === 0) {
      results.push({
        op: opName,
        file: (_c = (_b = op.target) != null ? _b : op.target_pattern) != null ? _c : "<no target>",
        status: "error",
        detail: "No matching files found"
      });
      continue;
    }
    for (const file of targets) {
      let result;
      switch (opName) {
        case "set_field":
          result = await applySetField(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "remove_field":
          result = await applyRemoveField(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "add_tag":
          result = await applyAddTag(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "remove_tag":
          result = await applyRemoveTag(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "replace_tag":
          result = await applyReplaceTagOp(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "normalize_tags":
          result = await applyNormalizeTags(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "compute_field":
          result = await applyComputeField(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "sort_frontmatter":
          result = await applySortFrontmatter(app, op, file, dryRun, settings.frontmatterFieldOrder);
          break;
        case "move_note":
          result = await applyMoveNote(app, op, file, settings, dryRun);
          break;
        default:
          result = {
            op: opName,
            file: file.path,
            status: "error",
            detail: `Unknown operation: '${opName}'`
          };
      }
      if (result.status === "changed") {
        await maybeBackup(file);
      }
      results.push(result);
    }
  }
  return {
    runId,
    patchFile: patchFilePath,
    description: (_d = patchFile.meta.description) != null ? _d : "",
    appliedAt,
    schemaVersion: (_e = patchFile.meta.schema_version) != null ? _e : "",
    dryRun,
    results,
    manifest
  };
}
async function applySetField(app, op, file, dryRun, fieldOrder) {
  var _a;
  const fieldName = op.field;
  if (!fieldName) {
    return opError("set_field", file, "Missing field name");
  }
  const note = await readNote(app, file);
  if (!note)
    return opError("set_field", file, "Could not read file");
  const fm = note.frontmatter;
  const currentValue = fm[fieldName];
  const onlyIfMissing = (_a = op.only_if_missing) != null ? _a : false;
  if (onlyIfMissing && isFieldPresent(fm, fieldName)) {
    return opSkipped("set_field", file, `Field '${fieldName}' already has a value`);
  }
  if (op.when) {
    const whenVal = fm[op.when.field];
    const whenCurrent = whenVal === void 0 ? "" : String(whenVal);
    if (whenCurrent !== op.when.equals) {
      return opSkipped("set_field", file, `Condition not met: '${op.when.field}' is '${whenCurrent}', expected '${op.when.equals}'`);
    }
  }
  let newValue;
  try {
    newValue = resolveFieldValue(op, file);
  } catch (e) {
    return opError("set_field", file, String(e));
  }
  const currentStr = currentValue === void 0 ? "<missing>" : JSON.stringify(currentValue);
  const newStr = JSON.stringify(newValue);
  if (currentStr === newStr) {
    return opSkipped("set_field", file, `Field '${fieldName}' already = ${newStr}`);
  }
  if (!dryRun) {
    fm[fieldName] = newValue;
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("set_field", file, `Set '${fieldName}': ${currentStr} \u2192 ${newStr}`);
}
async function applyRemoveField(app, op, file, dryRun, fieldOrder) {
  const fieldName = op.field;
  if (!fieldName)
    return opError("remove_field", file, "Missing field name");
  const note = await readNote(app, file);
  if (!note)
    return opError("remove_field", file, "Could not read file");
  if (!isFieldPresent(note.frontmatter, fieldName)) {
    return opSkipped("remove_field", file, `Field '${fieldName}' not present`);
  }
  if (!dryRun) {
    delete note.frontmatter[fieldName];
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("remove_field", file, `Removed field '${fieldName}'`);
}
async function applyAddTag(app, op, file, dryRun, fieldOrder) {
  const tag = op.tag;
  if (!tag)
    return opError("add_tag", file, "Missing tag");
  const note = await readNote(app, file);
  if (!note)
    return opError("add_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const updated = addTag(current, tag);
  if (updated === current) {
    return opSkipped("add_tag", file, `Tag '${tag}' already present`);
  }
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("add_tag", file, `Added tag '${tag}'`);
}
async function applyRemoveTag(app, op, file, dryRun, fieldOrder) {
  const tag = op.tag;
  if (!tag)
    return opError("remove_tag", file, "Missing tag");
  const note = await readNote(app, file);
  if (!note)
    return opError("remove_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const updated = removeTag(current, tag);
  if (updated === current) {
    return opSkipped("remove_tag", file, `Tag '${tag}' not present`);
  }
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("remove_tag", file, `Removed tag '${tag}'`);
}
async function applyReplaceTagOp(app, op, file, dryRun, fieldOrder) {
  const oldTag = op.old_tag;
  const newTagVal = op.new_tag;
  if (!oldTag || !newTagVal) {
    return opError("replace_tag", file, "Missing old_tag or new_tag");
  }
  const note = await readNote(app, file);
  if (!note)
    return opError("replace_tag", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const hasOld = current.some((t) => t.toLowerCase() === oldTag.toLowerCase());
  if (!hasOld) {
    return opSkipped("replace_tag", file, `Tag '${oldTag}' not present`);
  }
  const hasNew = current.some((t) => t.toLowerCase() === newTagVal.toLowerCase());
  if (hasNew) {
    return opSkipped("replace_tag", file, `Tag '${newTagVal}' already present`);
  }
  const updated = current.map(
    (t) => t.toLowerCase() === oldTag.toLowerCase() ? newTagVal : t
  );
  if (!dryRun) {
    setTags(note.frontmatter, updated);
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("replace_tag", file, `Replaced tag '${oldTag}' \u2192 '${newTagVal}'`);
}
async function applyNormalizeTags(app, op, file, dryRun, fieldOrder) {
  const note = await readNote(app, file);
  if (!note)
    return opError("normalize_tags", file, "Could not read file");
  const current = getTags(note.frontmatter);
  const normalized = normalizeTags(current);
  const currentStr = current.join("|");
  const normalizedStr = normalized.join("|");
  if (currentStr === normalizedStr) {
    return opSkipped("normalize_tags", file, "Tags already normalized");
  }
  if (!dryRun) {
    setTags(note.frontmatter, normalized);
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("normalize_tags", file, "Normalized tags");
}
async function applyComputeField(app, op, file, dryRun, fieldOrder) {
  var _a, _b, _c, _d;
  const fieldName = op.field;
  const strategy = op.strategy;
  if (!fieldName)
    return opError("compute_field", file, "Missing field name");
  if (!strategy)
    return opError("compute_field", file, "Missing strategy");
  const note = await readNote(app, file);
  if (!note)
    return opError("compute_field", file, "Could not read file");
  const fm = note.frontmatter;
  const whenMissing = (_a = op.when_missing) != null ? _a : false;
  if (whenMissing && isFieldPresent(fm, fieldName)) {
    return opSkipped("compute_field", file, `Field '${fieldName}' already has a value`);
  }
  const format = (_b = op.format) != null ? _b : "yyyy-MM-dd";
  let newValue;
  try {
    switch (strategy) {
      case "file_created_time": {
        newValue = formatDate(new Date(file.stat.ctime), format);
        break;
      }
      case "file_modified_time": {
        newValue = formatDate(new Date(file.stat.mtime), format);
        break;
      }
      case "recent_activity": {
        const days = (_c = op.days) != null ? _c : 30;
        const valueIfTrue = op.value_if_true;
        if (!valueIfTrue) {
          return opError("compute_field", file, "recent_activity requires value_if_true");
        }
        const skipIf = (_d = op.skip_if) != null ? _d : [];
        const currentVal2 = fm[fieldName] ? String(fm[fieldName]).trim() : "";
        if (skipIf.includes(currentVal2)) {
          return opSkipped("compute_field", file, `Field '${fieldName}' is '${currentVal2}' \u2014 excluded by skip_if`);
        }
        const cutoff = Date.now() - days * 24 * 60 * 60 * 1e3;
        if (file.stat.mtime >= cutoff) {
          newValue = valueIfTrue;
        } else {
          return opSkipped("compute_field", file, `File not modified in last ${days} days`);
        }
        break;
      }
      default:
        return opError("compute_field", file, `Unsupported strategy '${strategy}'`);
    }
  } catch (e) {
    return opError("compute_field", file, String(e));
  }
  const currentVal = fm[fieldName] !== void 0 ? String(fm[fieldName]) : "<missing>";
  if (currentVal === newValue) {
    return opSkipped("compute_field", file, `Field '${fieldName}' already = '${newValue}'`);
  }
  if (!dryRun) {
    fm[fieldName] = newValue;
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("compute_field", file, `Computed '${fieldName}': '${currentVal}' \u2192 '${newValue}'`);
}
async function applySortFrontmatter(app, op, file, dryRun, fieldOrder) {
  const note = await readNote(app, file);
  if (!note)
    return opError("sort_frontmatter", file, "Could not read file");
  if (!note.hasFrontmatter) {
    return opSkipped("sort_frontmatter", file, "No frontmatter found");
  }
  const sorted = sortFrontmatterFields(note.frontmatter, fieldOrder);
  const originalKeys = Object.keys(note.frontmatter).join(",");
  const sortedKeys = Object.keys(sorted).join(",");
  if (originalKeys === sortedKeys) {
    return opSkipped("sort_frontmatter", file, "Frontmatter already in correct order");
  }
  if (!dryRun) {
    note.frontmatter = sorted;
    await writeNote(app, note, fieldOrder);
  }
  return opChanged("sort_frontmatter", file, "Sorted frontmatter fields");
}
async function applyMoveNote(app, op, file, settings, dryRun) {
  const destinationFolder = op.destination_folder;
  const sourceRoot = op.source_root;
  if (!destinationFolder)
    return opError("move_note", file, "Missing destination_folder");
  if (!sourceRoot)
    return opError("move_note", file, "Missing source_root");
  if (op.strip_frontmatter && op.frontmatter) {
    return opError("move_note", file, "Cannot use both strip_frontmatter and frontmatter");
  }
  const normalizedSourceRoot = (0, import_obsidian10.normalizePath)(sourceRoot).toLowerCase();
  const filePath = (0, import_obsidian10.normalizePath)(file.path);
  if (!filePath.toLowerCase().startsWith(normalizedSourceRoot + "/")) {
    return opError("move_note", file, `File is not under source_root '${sourceRoot}'`);
  }
  const relativeUnderSource = file.path.substring(sourceRoot.length).replace(/^\//, "");
  const destPath = (0, import_obsidian10.normalizePath)(`${destinationFolder}/${relativeUnderSource}`);
  if (filePath === destPath.toLowerCase()) {
    return opSkipped("move_note", file, "Already in correct location");
  }
  const existing = app.vault.getAbstractFileByPath(destPath);
  if (existing) {
    return opError("move_note", file, `Destination already exists: ${destPath}`);
  }
  if (!dryRun) {
    await ensureFolder(app, (0, import_obsidian10.normalizePath)(destPath.substring(0, destPath.lastIndexOf("/"))));
    if (op.strip_frontmatter || op.frontmatter) {
      const note = await readNote(app, file);
      let content = await app.vault.read(file);
      if (op.strip_frontmatter) {
        const bodyMatch = content.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?([\s\S]*)$/);
        content = bodyMatch ? bodyMatch[1] : content;
      } else if (op.frontmatter && note) {
        const merged = { ...note.frontmatter, ...op.frontmatter };
        const sorted = sortFrontmatterFields(merged, settings.frontmatterFieldOrder);
        const yamlStr = (0, import_obsidian10.stringifyYaml)(sorted).trimEnd();
        const bodyMatch = content.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?([\s\S]*)$/);
        const body = bodyMatch ? bodyMatch[1] : content;
        content = `---
${yamlStr}
---
${body}`;
      }
      await app.vault.create(destPath, content);
      await app.vault.delete(file);
    } else {
      await app.vault.rename(file, destPath);
    }
  }
  return opChanged("move_note", file, `Moved \u2192 ${destPath}`);
}
function extractPatchYaml(raw, patchFilePath) {
  var _a, _b;
  const lowerPath = patchFilePath.toLowerCase();
  if (!lowerPath.endsWith(".md")) {
    return raw;
  }
  const match = raw.match(/```ya?ml\s*\r?\n([\s\S]*?)```/i);
  return (_b = (_a = match == null ? void 0 : match[1]) == null ? void 0 : _a.trim()) != null ? _b : "";
}
function resolveFieldValue(op, file) {
  const hasLiteralValue = "value" in op && op.value !== void 0;
  const valueFrom = op.value_from;
  if (hasLiteralValue && valueFrom) {
    throw new Error("Cannot specify both 'value' and 'value_from'");
  }
  if (!hasLiteralValue && !valueFrom) {
    throw new Error("set_field requires either 'value' or 'value_from'");
  }
  if (hasLiteralValue)
    return op.value;
  const parts = (0, import_obsidian10.normalizePath)(file.path).split("/");
  const fileName = parts[parts.length - 1];
  const baseName = fileName.replace(/\.md$/, "");
  const folderName = parts.length >= 2 ? parts[parts.length - 2] : "";
  const parentFolder = parts.length >= 3 ? parts[parts.length - 3] : "";
  let value;
  switch (valueFrom) {
    case "filename":
      value = fileName;
      break;
    case "basename":
      value = baseName;
      break;
    case "folder":
      value = folderName;
      break;
    case "parent_folder":
      value = parentFolder;
      break;
    case "path": {
      const idx = op.path_segment_index;
      if (idx === void 0)
        throw new Error("value_from: path requires path_segment_index");
      if (idx < 0 || idx >= parts.length)
        throw new Error(`path_segment_index ${idx} out of range`);
      value = parts[idx];
      break;
    }
    default:
      throw new Error(`Unsupported value_from '${valueFrom}'`);
  }
  const trimPrefix = op.trim_prefix;
  if (trimPrefix && value.startsWith(trimPrefix)) {
    value = value.substring(trimPrefix.length);
  }
  const trimSuffix = op.trim_suffix;
  if (trimSuffix && value.endsWith(trimSuffix)) {
    value = value.substring(0, value.length - trimSuffix.length);
  }
  if (op.lowercase && op.uppercase)
    throw new Error("Cannot specify both lowercase and uppercase");
  if (op.lowercase)
    value = value.toLowerCase();
  if (op.uppercase)
    value = value.toUpperCase();
  return value;
}
function formatDate(date, format) {
  if (format === "yyyy-MM-dd") {
    return todayString();
  }
  return todayString();
}
function opChanged(op, file, detail) {
  return { op, file: file.path, status: "changed", detail };
}
function opSkipped(op, file, detail) {
  return { op, file: file.path, status: "skipped", detail };
}
function opError(op, file, detail) {
  const filePath = typeof file === "string" ? file : file.path;
  return { op, file: filePath, status: "error", detail };
}

// src/patch-manifest.ts
var import_obsidian11 = require("obsidian");
init_vault_paths();
init_files();
async function writeRestoreManifest(app, settings, result) {
  if (!settings.patchBackupEnabled || !settings.patchGenerateManifest)
    return;
  if (result.manifest.length === 0)
    return;
  if (result.dryRun)
    return;
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.patchReports);
  const manifest = {
    run_id: result.runId,
    patch_file: result.patchFile,
    description: result.description,
    applied_at: result.appliedAt,
    schema_version: result.schemaVersion,
    changes: result.manifest
  };
  const manifestPath = (0, import_obsidian11.normalizePath)(
    `${paths.patchReports}/${result.runId}-patch-manifest.json`
  );
  await app.vault.create(manifestPath, JSON.stringify(manifest, null, 2));
}
async function archivePatchFile(app, settings, result) {
  if (result.dryRun)
    return;
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.patchApplied);
  const sourceFile = app.vault.getAbstractFileByPath(
    (0, import_obsidian11.normalizePath)(result.patchFile)
  );
  if (!(sourceFile instanceof import_obsidian11.TFile))
    return;
  const sourceExt = sourceFile.extension || "md";
  const archivePath = (0, import_obsidian11.normalizePath)(
    `${paths.patchApplied}/${result.runId}-vault-patch.${sourceExt}`
  );
  if (app.vault.getAbstractFileByPath(archivePath))
    return;
  await app.vault.rename(sourceFile, archivePath);
}
async function writePatchReport(app, settings, result) {
  const paths = getVaultPaths(settings);
  const folder = result.dryRun ? paths.exports : paths.patchReports;
  await ensureFolder(app, folder);
  const mode = result.dryRun ? "dry-run" : "apply";
  const reportPath = (0, import_obsidian11.normalizePath)(
    `${folder}/${result.runId}-patch-report-${mode}.md`
  );
  const changed = result.results.filter((r) => r.status === "changed");
  const skipped2 = result.results.filter((r) => r.status === "skipped");
  const errors = result.results.filter((r) => r.status === "error");
  const today = todayString();
  const content = buildReportNote(result, changed, skipped2, errors, today, mode);
  const existing = app.vault.getAbstractFileByPath(reportPath);
  if (existing instanceof import_obsidian11.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(reportPath, content);
  }
  return reportPath;
}
function buildReportNote(result, changed, skipped2, errors, today, mode) {
  const lines = [
    "---",
    "type: reference",
    "status: active",
    "tags:",
    "  - meta/patch-report",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    `source:: ${result.patchFile}`,
    `patch_mode:: ${mode}`,
    `changed_count:: ${changed.length}`,
    `skipped_count:: ${skipped2.length}`,
    `error_count:: ${errors.length}`,
    "",
    "# Patch Report",
    "",
    "## Summary",
    "",
    `- Mode: ${mode}`,
    `- Run ID: ${result.runId}`,
    `- Patch file: ${result.patchFile}`,
    `- Description: ${result.description}`,
    `- Applied at: ${result.appliedAt}`,
    `- Changed: ${changed.length}`,
    `- Skipped: ${skipped2.length}`,
    `- Errors: ${errors.length}`,
    ""
  ];
  if (errors.length > 0) {
    lines.push("## Errors", "");
    for (const r of errors) {
      lines.push(`- \`[${r.op}]\` \`${r.file}\` \u2014 ${r.detail}`);
    }
    lines.push("");
  }
  if (changed.length > 0) {
    lines.push("## Changed", "");
    const byOp = groupBy(changed, (r) => r.op);
    for (const [op, items] of Object.entries(byOp)) {
      lines.push(`### ${op}`, "");
      for (const r of items) {
        lines.push(`- \`${r.file}\` \u2014 ${r.detail}`);
      }
      lines.push("");
    }
  }
  if (skipped2.length > 0) {
    lines.push("## Skipped", "");
    for (const r of skipped2) {
      lines.push(`- \`[${r.op}]\` \`${r.file}\` \u2014 ${r.detail}`);
    }
    lines.push("");
  }
  return lines.join("\n");
}
function groupBy(arr, key) {
  return arr.reduce((acc, item) => {
    const k = key(item);
    if (!acc[k])
      acc[k] = [];
    acc[k].push(item);
    return acc;
  }, {});
}

// src/commands/run-lint.ts
var import_obsidian14 = require("obsidian");

// src/lint-engine.ts
init_vault_paths();
init_files();
init_frontmatter();
async function runLint(app, settings) {
  var _a;
  const schema = await loadSchema(app, settings);
  if (!schema)
    return null;
  const paths = getVaultPaths(settings);
  const exemptPaths = buildExemptList(schema.exempt_paths, paths.forge);
  const allFiles = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  const validShapes = getValidShapeNames(app, paths.shapes);
  const allResults = [];
  for (const file of allFiles) {
    const fileResults = await lintFile(app, file, schema, validShapes, settings);
    allResults.push(...fileResults);
  }
  if (settings.staleReviewEnabled && settings.staleReviewCycleField && settings.staleReviewUpdatedField) {
    const staleResults = await runStaleReview(app, allFiles, settings);
    allResults.push(...staleResults);
  }
  const envelope = {
    vault_path: (_a = app.vault.adapter.basePath) != null ? _a : "",
    timestamp: localTimestamp(),
    schema_version: schema.meta.version,
    notes_scanned: allFiles.length
  };
  return {
    envelope,
    results: allResults,
    errors: allResults.filter((r) => r.severity === "error"),
    warnings: allResults.filter((r) => r.severity === "warning"),
    infos: allResults.filter((r) => r.severity === "info")
  };
}
async function lintFile(app, file, schema, validShapes, settings) {
  const note = await readNote(app, file);
  const results = [];
  if (!note || !note.hasFrontmatter) {
    results.push(newResult(file.path, "error", "no_frontmatter", "No frontmatter block found"));
    return results;
  }
  const fm = note.frontmatter;
  const content = await app.vault.read(file);
  results.push(...testRequiredFields(file.path, fm, schema.required_fields));
  results.push(...testBasicTypeFields(file.path, fm, schema.required_fields));
  results.push(...testEnumFields(file.path, fm, schema.required_fields));
  results.push(...testDateFields(file.path, fm, schema.required_fields));
  results.push(...testConditionalRules(file.path, fm, schema.required_fields));
  results.push(...testFieldTagConsistency(file.path, fm, schema.required_fields));
  const optFields = schema.optional_fields.filter((f) => isFieldPresent(fm, f.name));
  results.push(...testBasicTypeFields(file.path, fm, optFields));
  results.push(...testEnumFields(file.path, fm, optFields));
  results.push(...testDateFields(file.path, fm, optFields));
  results.push(...testConditionalRules(file.path, fm, optFields));
  results.push(...testPatternFieldValues(file.path, fm, optFields, validShapes));
  results.push(...testTagNamespaces(file.path, fm, schema));
  if (settings.lintInlineMetadata) {
    results.push(...testInlineMetadata(file.path, content, schema));
  }
  return results;
}
function testRequiredFields(path, fm, fields) {
  return fields.filter((f) => !isFieldPresent(fm, f.name)).map(
    (f) => newResult(path, f.severity, "required_field", `Missing required field: '${f.name}'`)
  );
}
function testBasicTypeFields(path, fm, fields) {
  const results = [];
  for (const field of fields) {
    if (!isFieldPresent(fm, field.name))
      continue;
    const val = fm[field.name];
    switch (field.type) {
      case "string":
        if (typeof val !== "string") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a string`
          ));
        }
        break;
      case "boolean":
        if (typeof val !== "boolean") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a boolean`
          ));
        }
        break;
      case "list":
        if (!Array.isArray(val)) {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a list`
          ));
        }
        break;
      case "version":
        if (typeof val !== "string" && typeof val !== "number") {
          results.push(newResult(
            path,
            field.severity,
            "type_mismatch",
            `Field '${field.name}' must be a version string or number`
          ));
        }
        break;
    }
  }
  return results;
}
function testEnumFields(path, fm, fields) {
  const results = [];
  for (const field of fields) {
    if (field.type !== "enum")
      continue;
    if (!isFieldPresent(fm, field.name))
      continue;
    if (!field.values)
      continue;
    const val = String(fm[field.name]);
    if (!field.values.includes(val)) {
      results.push(newResult(
        path,
        field.severity,
        "enum_value",
        `Field '${field.name}' value '${val}' not allowed. Valid: ${field.values.join(", ")}`
      ));
    }
  }
  return results;
}
function testDateFields(path, fm, fields) {
  const results = [];
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  for (const field of fields) {
    if (field.type !== "date")
      continue;
    if (!isFieldPresent(fm, field.name))
      continue;
    const val = String(fm[field.name]);
    if (!dateRegex.test(val) || isNaN(Date.parse(val))) {
      results.push(newResult(
        path,
        field.severity,
        "date_format",
        `Field '${field.name}' value '${val}' does not match format yyyy-MM-dd`
      ));
      continue;
    }
    if (field.stale_after_days) {
      const parsed = new Date(val);
      const ageDays = (Date.now() - parsed.getTime()) / (1e3 * 60 * 60 * 24);
      if (ageDays > field.stale_after_days) {
        results.push(newResult(
          path,
          "warning",
          "stale_date",
          `Field '${field.name}' is ${Math.floor(ageDays)} days old (threshold: ${field.stale_after_days} days)`
        ));
      }
    }
  }
  return results;
}
function testConditionalRules(path, fm, fields) {
  var _a, _b, _c, _d, _e, _f;
  const results = [];
  for (const field of fields) {
    if (!((_a = field.lint_rules) == null ? void 0 : _a.length))
      continue;
    const fieldPresent = isFieldPresent(fm, field.name);
    for (const rule of field.lint_rules) {
      if (!rule.field)
        continue;
      if (!isFieldPresent(fm, rule.field))
        continue;
      const driverVal = String(fm[rule.field]);
      const severity = (_b = rule.severity) != null ? _b : "warning";
      if (rule.rule === "required_when") {
        const matchEquals = (_d = (_c = rule.equals) == null ? void 0 : _c.includes(driverVal)) != null ? _d : false;
        if (matchEquals && !fieldPresent) {
          results.push(newResult(
            path,
            severity,
            "required_when",
            `Field '${field.name}' is required when '${rule.field}' = '${driverVal}'`
          ));
        }
      }
      if (rule.rule === "forbidden_when") {
        const matchNotEquals = rule.not_equals ? !rule.not_equals.includes(driverVal) : false;
        const matchEquals = (_f = (_e = rule.equals) == null ? void 0 : _e.includes(driverVal)) != null ? _f : false;
        if ((matchNotEquals || matchEquals) && fieldPresent) {
          const label = rule.not_equals ? `not one of: ${rule.not_equals.join(", ")}` : `= '${driverVal}'`;
          results.push(newResult(
            path,
            severity,
            "forbidden_when",
            `Field '${field.name}' should not be present when '${rule.field}' is ${label}`
          ));
        }
      }
    }
  }
  return results;
}
function testFieldTagConsistency(path, fm, fields) {
  var _a, _b, _c;
  const results = [];
  const tags = getTags(fm);
  for (const field of fields) {
    if (!((_a = field.lint_rules) == null ? void 0 : _a.length))
      continue;
    for (const rule of field.lint_rules) {
      if (rule.rule !== "tag_consistency")
        continue;
      if (!rule.tag_namespace)
        continue;
      if (!isFieldPresent(fm, field.name))
        continue;
      const fieldVal = String(fm[field.name]).toLowerCase();
      const ns = rule.tag_namespace;
      const expected = `${ns}/${fieldVal}`;
      const nsTags = tags.filter((t) => t.startsWith(`${ns}/`));
      if (nsTags.length === 0) {
        results.push(newResult(
          path,
          (_b = rule.severity) != null ? _b : "warning",
          "tag_consistency",
          `Field '${field.name}' = '${fieldVal}' but no '${ns}/*' tag found. Expected: ${expected}`
        ));
      } else if (!tags.includes(expected)) {
        results.push(newResult(
          path,
          (_c = rule.severity) != null ? _c : "warning",
          "tag_consistency",
          `Field '${field.name}' = '${fieldVal}' but tag '${expected}' missing. Found: ${nsTags.join(", ")}`
        ));
      }
    }
  }
  return results;
}
function testPatternFieldValues(path, fm, fields, validShapes) {
  const results = [];
  const patternField = fields.find((f) => f.name === "shapes");
  if (!patternField)
    return results;
  if (!isFieldPresent(fm, "shapes"))
    return results;
  const raw = fm["shapes"];
  const list = Array.isArray(raw) ? raw : [raw];
  const validSet = new Set(validShapes.map((p) => p.toLowerCase()));
  for (const item of list) {
    if (item === null || item === void 0)
      continue;
    const val = String(item).trim();
    if (!val)
      continue;
    if (!validSet.has(val.toLowerCase())) {
      results.push(newResult(
        path,
        patternField.severity,
        "invalid_shape_ref",
        `Field 'shapes' contains '${val}', which is not a valid pattern in System/Shapes/`
      ));
    }
  }
  return results;
}
function testTagNamespaces(path, fm, schema) {
  const results = [];
  const tags = getTags(fm);
  const { tag_rules } = schema;
  const allowedNs = new Set(tag_rules.allowed_namespaces);
  for (const tag of tags) {
    const slashIdx = tag.indexOf("/");
    if (slashIdx < 0) {
      results.push(newResult(
        path,
        tag_rules.severity,
        "tag_namespace",
        `Tag '${tag}' is not namespaced. Expected format: namespace/tag`
      ));
      continue;
    }
    const ns = tag.substring(0, slashIdx);
    if (tag_rules.unknown_tags !== "off" && !allowedNs.has(ns)) {
      results.push(newResult(
        path,
        "warning",
        "unknown_tag_namespace",
        `Tag namespace '${ns}' is not in allowed_namespaces`
      ));
    }
  }
  return results;
}
function testInlineMetadata(path, content, schema) {
  const results = [];
  const entries = extractInlineMetadataKeys(content);
  const schemaFieldNames = /* @__PURE__ */ new Set([
    ...schema.required_fields.map((f) => f.name.toLowerCase()),
    ...schema.optional_fields.map((f) => f.name.toLowerCase())
  ]);
  const inlineFieldNames = new Set(
    schema.inline_fields.map((f) => f.toLowerCase())
  );
  const allSchemaNames = [...schemaFieldNames];
  const allInlineNames = [...inlineFieldNames];
  const seen = /* @__PURE__ */ new Set();
  for (const entry of entries) {
    const dedupeKey = `${path}|${entry.key}`;
    if (seen.has(dedupeKey))
      continue;
    seen.add(dedupeKey);
    const keyLower = entry.key.toLowerCase();
    if (schemaFieldNames.has(keyLower)) {
      results.push(newResult(
        path,
        "error",
        "inline_is_schema_field",
        `Inline key '${entry.key}' is a schema frontmatter field \u2014 move to frontmatter (line ${entry.line})`
      ));
      continue;
    }
    if (inlineFieldNames.has(keyLower))
      continue;
    const [schemaDist, schemaMatch] = closestMatch(entry.key, allSchemaNames, 2);
    if (schemaDist <= 2 && schemaDist > 0) {
      results.push(newResult(
        path,
        "warning",
        "inline_fuzzy_schema",
        `Inline key '${entry.key}' looks like a typo of schema field '${schemaMatch}' (distance ${schemaDist}, line ${entry.line})`
      ));
      continue;
    }
    const [inlineDist, inlineMatch] = closestMatch(entry.key, allInlineNames, 2);
    if (inlineDist <= 2 && inlineDist > 0) {
      results.push(newResult(
        path,
        "warning",
        "inline_fuzzy_inline",
        `Inline key '${entry.key}' looks like a typo of inline field '${inlineMatch}' (distance ${inlineDist}, line ${entry.line})`
      ));
      continue;
    }
    results.push(newResult(
      path,
      "info",
      "inline_undocumented",
      `Inline key '${entry.key}' is undocumented \u2014 consider adding to inline_fields in schema.md (line ${entry.line})`
    ));
  }
  return results;
}
function extractInlineMetadataKeys(content) {
  const results = [];
  const lines = content.split(/\r?\n/);
  const inlinePattern = /^>?\s*([A-Za-z_][A-Za-z0-9_-]*)::\s*\S/;
  let inFrontmatter = false;
  let inFence = false;
  let lineNum = 0;
  for (const line of lines) {
    lineNum++;
    if (lineNum === 1 && /^---\s*$/.test(line)) {
      inFrontmatter = true;
      continue;
    }
    if (inFrontmatter && /^---\s*$/.test(line)) {
      inFrontmatter = false;
      continue;
    }
    if (inFrontmatter)
      continue;
    if (/^(```|~~~)/.test(line)) {
      inFence = !inFence;
      continue;
    }
    if (inFence)
      continue;
    const match = line.match(inlinePattern);
    if (match) {
      results.push({ key: match[1], line: lineNum });
    }
  }
  return results;
}
function newResult(file, severity, rule, message) {
  return { file, severity, rule, message };
}
var CYCLE_DAYS = {
  daily: 1,
  weekly: 7,
  monthly: 30,
  quarterly: 90,
  yearly: 365
};
async function runStaleReview(app, files, settings) {
  const results = [];
  const {
    staleReviewCycleField,
    staleReviewUpdatedField,
    staleReviewFilterField,
    staleReviewStatuses
  } = settings;
  const now = Date.now();
  for (const file of files) {
    const note = await readNote(app, file);
    if (!(note == null ? void 0 : note.hasFrontmatter))
      continue;
    const fm = note.frontmatter;
    if (staleReviewFilterField && staleReviewStatuses.length > 0) {
      const fieldVal = getFmString(fm, staleReviewFilterField);
      if (!fieldVal || !staleReviewStatuses.includes(fieldVal))
        continue;
    }
    const cycleRaw = getFmString(fm, staleReviewCycleField).toLowerCase().trim();
    if (!cycleRaw || cycleRaw === "never")
      continue;
    const cycleDays = CYCLE_DAYS[cycleRaw];
    if (!cycleDays)
      continue;
    const updatedRaw = getFmString(fm, staleReviewUpdatedField);
    if (!updatedRaw)
      continue;
    const updated = new Date(updatedRaw);
    if (isNaN(updated.getTime()))
      continue;
    const ageDays = (now - updated.getTime()) / (1e3 * 60 * 60 * 24);
    if (ageDays > cycleDays) {
      results.push(newResult(
        file.path,
        "warning",
        "stale_note",
        `Note is overdue for review \u2014 cycle: ${cycleRaw} (${cycleDays}d), last updated: ${updatedRaw} (${Math.floor(ageDays)} days ago)`
      ));
    }
  }
  return results;
}
function getValidShapeNames(app, patternsPath) {
  const folder = app.vault.getAbstractFileByPath(patternsPath);
  if (!folder)
    return [];
  const files = getMarkdownFiles(app, patternsPath);
  return files.map((f) => f.basename);
}
function closestMatch(input, candidates, maxDist) {
  let bestDist = maxDist + 1;
  let bestMatch = "";
  const inputLower = input.toLowerCase();
  for (const candidate of candidates) {
    if (Math.abs(inputLower.length - candidate.length) > maxDist)
      continue;
    const dist = levenshtein(inputLower, candidate, maxDist);
    if (dist < bestDist) {
      bestDist = dist;
      bestMatch = candidate;
    }
  }
  return [bestDist, bestMatch];
}
function levenshtein(a, b, maxDist) {
  if (a === b)
    return 0;
  if (a.length === 0)
    return b.length;
  if (b.length === 0)
    return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const curr = new Array(b.length + 1).fill(0);
    curr[0] = i;
    let rowMin = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
      if (curr[j] < rowMin)
        rowMin = curr[j];
    }
    if (rowMin > maxDist)
      return maxDist + 1;
    prev = curr;
  }
  return prev[b.length];
}

// src/lint-writers.ts
var import_obsidian12 = require("obsidian");
init_vault_paths();
init_files();
async function writeLintReportJson(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.exports);
  const report = {
    run: run.envelope,
    summary: {
      errors: run.errors.length,
      warnings: run.warnings.length,
      info: run.infos.length,
      notes_scanned: run.envelope.notes_scanned
    },
    results: run.results
  };
  const path = (0, import_obsidian12.normalizePath)(paths.lintReportJson);
  const existing = app.vault.getAbstractFileByPath(path);
  const content = JSON.stringify(report, null, 2);
  if (existing instanceof import_obsidian12.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(path, content);
  }
}
async function appendLintHistory(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.exports);
  const entry = {
    timestamp: run.envelope.timestamp,
    schema_version: run.envelope.schema_version,
    notes_scanned: run.envelope.notes_scanned,
    errors: run.errors.length,
    warnings: run.warnings.length,
    info: run.infos.length
  };
  let history = [];
  const histPath = (0, import_obsidian12.normalizePath)(paths.lintHistoryJson);
  const histFile = app.vault.getAbstractFileByPath(histPath);
  if (histFile instanceof import_obsidian12.TFile) {
    try {
      const raw = await app.vault.read(histFile);
      history = JSON.parse(raw);
      if (!Array.isArray(history))
        history = [];
    } catch (e) {
      history = [];
    }
  }
  history.push(entry);
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - settings.lintHistoryRetentionDays);
  history = history.filter((e) => new Date(e.timestamp) >= cutoff);
  if (history.length > settings.lintHistoryMaxEntries) {
    history = history.slice(history.length - settings.lintHistoryMaxEntries);
  }
  const content = JSON.stringify(history, null, 2);
  if (histFile instanceof import_obsidian12.TFile) {
    await app.vault.modify(histFile, content);
  } else {
    await app.vault.create(histPath, content);
  }
}
async function writeLintRunNote(app, settings, run) {
  const paths = getVaultPaths(settings);
  await ensureFolder(app, paths.lintRuns);
  const safeTs = run.envelope.timestamp.replace(/[:.]/g, "-").replace("T", "_");
  const notePath = (0, import_obsidian12.normalizePath)(`${paths.lintRuns}/lint-run-${safeTs}.md`);
  const today = todayString();
  const content = buildLintRunNote(run, today, settings.lintFileLinks);
  const existing = app.vault.getAbstractFileByPath(notePath);
  if (existing instanceof import_obsidian12.TFile) {
    await app.vault.modify(existing, content);
  } else {
    await app.vault.create(notePath, content);
  }
  return notePath;
}
function summarizeLintMessage(rule, message) {
  if (rule === "inline_undocumented") {
    return "Inline keys are undocumented \u2014 consider adding to inline_fields in schema.md";
  }
  if (rule === "tag_namespace") {
    return "Tags are not namespaced. Expected format: namespace/tag";
  }
  return message;
}
function extractLintReason(rule, message) {
  if (rule === "inline_undocumented") {
    const match = message.match(/Inline key '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  if (rule === "tag_namespace") {
    const match = message.match(/Tag '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  return message;
}
function groupLintItems(items) {
  const groups = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  const seenReasonFiles = /* @__PURE__ */ new Set();
  for (const item of items) {
    const summary = summarizeLintMessage(item.rule, item.message);
    const reasonLabel = extractLintReason(item.rule, item.message);
    const groupKey = `${item.rule}::${summary}`;
    const reasonKey = `${groupKey}::${reasonLabel}`;
    const reasonFileKey = `${reasonKey}::${item.file}`;
    let group = groups.get(groupKey);
    if (!group) {
      group = {
        rule: item.rule,
        summary,
        reasons: []
      };
      groups.set(groupKey, group);
    }
    let reason = reasons.get(reasonKey);
    if (!reason) {
      reason = {
        label: reasonLabel,
        files: []
      };
      reasons.set(reasonKey, reason);
      group.reasons.push(reason);
    }
    if (!seenReasonFiles.has(reasonFileKey)) {
      seenReasonFiles.add(reasonFileKey);
      reason.files.push(item.file);
    }
  }
  return [...groups.values()];
}
function buildLintRunNote(run, today, fileLinks) {
  const lines = [
    "---",
    "type: reference",
    "status: complete",
    "tags:",
    "  - meta/vault-lint",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    `schema_version:: "${run.envelope.schema_version}"`,
    `runtime:: ${run.envelope.timestamp}`,
    `notes_scanned:: ${run.envelope.notes_scanned}`,
    `errors:: ${run.errors.length}`,
    `warnings:: ${run.warnings.length}`,
    `infos:: ${run.infos.length}`,
    "",
    "# Lint Run",
    "",
    "## Summary",
    "",
    "| Severity | Count |",
    "|----------|-------|",
    `| \u{1F534} Error   | ${run.errors.length}   |`,
    `| \u{1F7E1} Warning | ${run.warnings.length} |`,
    `| \u{1F535} Info    | ${run.infos.length}    |`,
    ""
  ];
  for (const { label, items } of [
    { label: "\u{1F534} Errors", items: run.errors },
    { label: "\u{1F7E1} Warnings", items: run.warnings },
    { label: "\u{1F535} Info", items: run.infos }
  ]) {
    if (items.length === 0)
      continue;
    lines.push(`## ${label}`, "");
    for (const group of groupLintItems(items)) {
      lines.push(`### \`[${group.rule}]\``);
      lines.push("");
      lines.push(group.summary);
      lines.push("");
      for (const reason of group.reasons) {
        lines.push(`#### ${reason.label}`);
        lines.push("");
        for (const file of reason.files) {
          const fileRef = fileLinks ? `[[${file}]]` : `\`${file}\``;
          lines.push(`- ${fileRef}`);
        }
        lines.push("");
      }
    }
  }
  return lines.join("\n");
}

// src/commands/repair.ts
var import_obsidian13 = require("obsidian");
init_vault_paths();
init_files();
async function runVaultRepair(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const reportFile = app.vault.getAbstractFileByPath(paths.lintReportJson);
  if (!(reportFile instanceof import_obsidian13.TFile)) {
    new import_obsidian13.Notice("Forge: No lint report found. Run Vault Lint first.", 5e3);
    return;
  }
  let report;
  try {
    const raw = await app.vault.read(reportFile);
    report = JSON.parse(raw);
  } catch (e) {
    new import_obsidian13.Notice("Forge: Could not parse lint-report.json.", 5e3);
    return;
  }
  const errors = ((_a = report.results) != null ? _a : []).filter(
    (r) => r.severity === "error" || r.severity === "warning" && (r.rule === "required_field" || r.rule === "type_mismatch" || r.rule === "enum_value")
  );
  if (errors.length === 0) {
    new import_obsidian13.Notice("Forge: No errors in lint report \u2014 nothing to repair.", 4e3);
    return;
  }
  const schema = await loadSchema(app, settings);
  if (!schema) {
    new import_obsidian13.Notice("Forge: Could not load schema.md \u2014 repair aborted.", 5e3);
    return;
  }
  const byFile = /* @__PURE__ */ new Map();
  for (const error2 of errors) {
    if (!byFile.has(error2.file))
      byFile.set(error2.file, []);
    byFile.get(error2.file).push(error2);
  }
  new VaultRepairModal(app, plugin, schema, byFile).open();
}
var VaultRepairModal = class extends import_obsidian13.Modal {
  constructor(app, plugin, schema, byFile) {
    super(app);
    this.currentIndex = 0;
    this.ops = [];
    this.skippedCount = 0;
    this.plugin = plugin;
    this.schema = schema;
    this.byFile = byFile;
    this.fileList = [...byFile.keys()];
  }
  onOpen() {
    this.renderCurrentFile();
  }
  renderCurrentFile() {
    var _a, _b;
    const { contentEl } = this;
    contentEl.empty();
    if (this.currentIndex >= this.fileList.length) {
      this.renderFinish();
      return;
    }
    const filePath = this.fileList[this.currentIndex];
    const fileErrors = (_a = this.byFile.get(filePath)) != null ? _a : [];
    const total = this.fileList.length;
    const current = this.currentIndex + 1;
    contentEl.createEl("h2", { text: `Vault Repair (${current} of ${total})` });
    contentEl.createEl("p", {
      text: filePath,
      cls: "forge-schema-path"
    });
    contentEl.createEl("h3", { text: "Issues" });
    const errorList = contentEl.createEl("ul", { cls: "forge-error-list" });
    for (const e of fileErrors) {
      const prefix = e.severity === "warning" ? "\u26A0\uFE0F" : "\u{1F534}";
      errorList.createEl("li", { text: `${prefix} [${e.rule}] ${e.message}` });
    }
    const fieldsToFix = this.getFieldsToFix(fileErrors);
    const fieldValues = /* @__PURE__ */ new Map();
    if (fieldsToFix.length > 0) {
      contentEl.createEl("h3", { text: "Fix" });
      for (const fieldName of fieldsToFix) {
        const field = (_b = this.schema.required_fields.find((f) => f.name === fieldName)) != null ? _b : this.schema.optional_fields.find((f) => f.name === fieldName);
        if (!field)
          continue;
        if (field.type === "enum" && field.values) {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion ? String(suggestion) : field.values[0];
          fieldValues.set(fieldName, initialVal);
          new import_obsidian13.Setting(contentEl).setName(fieldName).setDesc(`Valid: ${field.values.join(", ")}`).addDropdown((dd) => {
            for (const v of field.values) {
              dd.addOption(v, v);
            }
            dd.setValue(initialVal);
            dd.onChange((val) => fieldValues.set(fieldName, val));
          });
        } else if (field.type === "boolean") {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion !== null ? String(suggestion) : "false";
          fieldValues.set(fieldName, initialVal === "true");
          new import_obsidian13.Setting(contentEl).setName(fieldName).addDropdown((dd) => {
            dd.addOption("false", "false");
            dd.addOption("true", "true");
            dd.setValue(initialVal);
            dd.onChange((val) => fieldValues.set(fieldName, val === "true"));
          });
        } else if (field.type === "date") {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          const initialVal = suggestion ? String(suggestion) : todayString();
          fieldValues.set(fieldName, initialVal);
          new import_obsidian13.Setting(contentEl).setName(fieldName).setDesc("Format: yyyy-MM-dd").addText((t) => {
            t.setPlaceholder("yyyy-MM-dd");
            t.setValue(initialVal);
            t.onChange((val) => fieldValues.set(fieldName, val));
          });
        } else if (field.type === "list" && fieldName === "tags") {
          new import_obsidian13.Setting(contentEl).setName("tags").setDesc(`Comma-separated. Namespaces: ${this.schema.tag_rules.allowed_namespaces.join(", ")}`).addText((t) => {
            t.setPlaceholder("topic/identity, skill/governance");
            t.onChange((val) => {
              fieldValues.set("tags", val.split(",").map((s) => s.trim()).filter(Boolean));
            });
          });
        } else {
          const suggestion = this.getSuggestion(fieldName, fileErrors);
          if (suggestion)
            fieldValues.set(fieldName, suggestion);
          new import_obsidian13.Setting(contentEl).setName(fieldName).addText((t) => {
            if (suggestion)
              t.setValue(String(suggestion));
            t.onChange((val) => fieldValues.set(fieldName, val));
          });
        }
      }
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const fixBtn = buttonRow.createEl("button", {
      text: fieldsToFix.length > 0 ? "Fix & Continue" : "Skip",
      cls: fieldsToFix.length > 0 ? "mod-cta" : ""
    });
    fixBtn.addEventListener("click", () => {
      for (const [fieldName, value] of fieldValues) {
        if (fieldName === "tags" && Array.isArray(value)) {
          for (const tag of value) {
            this.ops.push({ op: "add_tag", target: filePath, tag });
          }
        } else if (value !== "" && value !== void 0) {
          this.ops.push({ op: "set_field", target: filePath, field: fieldName, value });
        }
      }
      this.currentIndex++;
      this.renderCurrentFile();
    });
    if (fieldsToFix.length > 0) {
      const skipBtn = buttonRow.createEl("button", { text: "Skip File" });
      skipBtn.addEventListener("click", () => {
        this.skippedCount++;
        this.currentIndex++;
        this.renderCurrentFile();
      });
    }
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel All" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  renderFinish() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Repair Summary" });
    if (this.ops.length === 0) {
      contentEl.createEl("p", { text: "No operations collected \u2014 nothing to patch." });
      const closeBtn = contentEl.createEl("button", { text: "Close" });
      closeBtn.addEventListener("click", () => this.close());
      return;
    }
    contentEl.createEl("p", {
      text: `${this.ops.length} operation(s) collected across ${this.fileList.length - this.skippedCount} file(s).`
    });
    if (this.skippedCount > 0) {
      contentEl.createEl("p", { text: `${this.skippedCount} file(s) skipped.`, cls: "forge-error-note" });
    }
    contentEl.createEl("p", {
      text: `The repair patch will be written to ${getVaultPaths(this.plugin.settings).patchFile}.`,
      cls: "forge-backup-notice"
    });
    const buttonRow = contentEl.createDiv("forge-button-row");
    const writeAndApplyBtn = buttonRow.createEl("button", {
      text: "Write Patch & Apply",
      cls: "mod-cta"
    });
    writeAndApplyBtn.addEventListener("click", async () => {
      this.close();
      await this.writePatch();
      await runApplyPatch(this.plugin);
    });
    const writeBtn = buttonRow.createEl("button", { text: "Write Patch Only" });
    writeBtn.addEventListener("click", async () => {
      this.close();
      await this.writePatch();
      new import_obsidian13.Notice("Forge: Repair patch written. Run Apply Vault Patch when ready.", 5e3);
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async writePatch() {
    const paths = getVaultPaths(this.plugin.settings);
    const today = todayString();
    const existingPatch = this.app.vault.getAbstractFileByPath(paths.patchFile);
    if (existingPatch instanceof import_obsidian13.TFile) {
      const existing2 = await this.app.vault.read(existingPatch);
      const hasOps = existing2.includes("op:") || existing2.includes("operations:");
      if (hasOps) {
        new import_obsidian13.Notice(
          "Forge: Overwriting existing patch file \u2014 previous operations will be replaced.",
          5e3
        );
      }
    }
    const patch = {
      meta: {
        generated_at: localTimestamp(),
        description: "Repair pass \u2014 interactive fix of lint errors",
        schema_version: this.schema.meta.version,
        source: "Forge \u2014 Vault Repair",
        contains_schema_changes: false
      },
      operations: this.ops
    };
    const lines = [
      "meta:",
      `  generated_at: ${patch.meta.generated_at}`,
      `  description: "${patch.meta.description}"`,
      `  schema_version: "${patch.meta.schema_version}"`,
      `  source: "${patch.meta.source}"`,
      `  contains_schema_changes: false`,
      "",
      "operations:"
    ];
    for (const op of this.ops) {
      lines.push(`  - op: ${op.op}`);
      lines.push(`    target: "${op.target}"`);
      if (op.field)
        lines.push(`    field: ${op.field}`);
      if (op.tag)
        lines.push(`    tag: ${op.tag}`);
      if (op.value !== void 0) {
        if (typeof op.value === "string") {
          lines.push(`    value: "${op.value}"`);
        } else if (typeof op.value === "boolean") {
          lines.push(`    value: ${op.value}`);
        } else {
          lines.push(`    value: ${op.value}`);
        }
      }
    }
    const content = [
      "---",
      "type: procedure",
      "status: draft",
      "tags:",
      "  - tool/forge",
      `created: ${today}`,
      `updated: ${today}`,
      "ai_private: false",
      "review_cycle: never",
      "---",
      "",
      "# Vault Patch",
      "",
      "Patch generated by Forge Repair.",
      "",
      "## Patch",
      "",
      "```yaml",
      ...lines,
      "```",
      ""
    ].join("\n");
    const patchPath = paths.patchFile;
    const patchFolder = patchPath.includes("/") ? patchPath.substring(0, patchPath.lastIndexOf("/")) : "";
    if (patchFolder)
      await ensureFolder(this.app, patchFolder);
    const existing = this.app.vault.getAbstractFileByPath(patchPath);
    if (existing instanceof import_obsidian13.TFile) {
      await this.app.vault.modify(existing, content);
    } else {
      await this.app.vault.create(patchPath, content);
    }
  }
  getFieldsToFix(errors) {
    const fields = /* @__PURE__ */ new Set();
    const hasNoFrontmatter = errors.some((e) => e.rule === "no_frontmatter");
    if (hasNoFrontmatter) {
      for (const field of this.schema.required_fields) {
        fields.add(field.name);
      }
      return [...fields];
    }
    for (const e of errors) {
      if (e.rule === "required_field") {
        const m = e.message.match(/Missing required field: '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      } else if (e.rule === "enum_value") {
        const m = e.message.match(/Field '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      } else if (e.rule === "required_when") {
        const m = e.message.match(/Field '([\w_]+)'/);
        if (m)
          fields.add(m[1]);
      }
    }
    return [...fields];
  }
  getSuggestion(fieldName, errors) {
    var _a, _b, _c;
    const cacheDefault = (_a = this.plugin.schemaCache) == null ? void 0 : _a.getDefaultValue(fieldName);
    if (fieldName === "status") {
      const statusErr = errors.find((e) => e.rule === "enum_value" && e.message.includes("'status'"));
      if (statusErr) {
        const values = (_b = this.plugin.schemaCache) == null ? void 0 : _b.getEnumValues("status");
        return (values == null ? void 0 : values.includes("active")) ? "active" : (_c = values == null ? void 0 : values[0]) != null ? _c : cacheDefault;
      }
    }
    return cacheDefault != null ? cacheDefault : null;
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/run-lint.ts
async function runVaultLint(plugin) {
  const { app, settings } = plugin;
  const noteCount = app.vault.getMarkdownFiles().length;
  const estimatedSeconds = Math.max(3, Math.ceil(noteCount / 200));
  new import_obsidian14.Notice(
    `Forge: Running lint on ${noteCount} notes\u2026 (may take ~${estimatedSeconds}s on large vaults)`,
    estimatedSeconds * 1e3
  );
  const result = await runLint(app, settings);
  if (!result) {
    new import_obsidian14.Notice(
      "Forge: Could not load schema.md \u2014 lint aborted. Run Validate Schema to diagnose.",
      6e3
    );
    return null;
  }
  await writeLintReportJson(app, settings, result);
  await appendLintHistory(app, settings, result);
  const runNotePath = await writeLintRunNote(app, settings, result);
  new LintResultsModal(app, plugin, result, runNotePath).open();
  return result;
}
function summarizeLintMessage2(rule, message) {
  if (rule === "inline_undocumented") {
    return "Inline keys are undocumented \u2014 consider adding to inline_fields in schema.md";
  }
  if (rule === "tag_namespace") {
    return "Tags are not namespaced. Expected format: namespace/tag";
  }
  return message;
}
function extractLintReason2(rule, message) {
  if (rule === "inline_undocumented") {
    const match = message.match(/Inline key '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  if (rule === "tag_namespace") {
    const match = message.match(/Tag '([^']+)'/);
    return match ? `'${match[1]}'` : message;
  }
  return message;
}
function groupLintItems2(items) {
  const groups = /* @__PURE__ */ new Map();
  const reasons = /* @__PURE__ */ new Map();
  const seenReasonFiles = /* @__PURE__ */ new Set();
  for (const item of items) {
    const summary = summarizeLintMessage2(item.rule, item.message);
    const reasonLabel = extractLintReason2(item.rule, item.message);
    const groupKey = `${item.rule}::${summary}`;
    const reasonKey = `${groupKey}::${reasonLabel}`;
    const reasonFileKey = `${reasonKey}::${item.file}`;
    let group = groups.get(groupKey);
    if (!group) {
      group = {
        rule: item.rule,
        summary,
        reasons: []
      };
      groups.set(groupKey, group);
    }
    let reason = reasons.get(reasonKey);
    if (!reason) {
      reason = {
        label: reasonLabel,
        files: []
      };
      reasons.set(reasonKey, reason);
      group.reasons.push(reason);
    }
    if (!seenReasonFiles.has(reasonFileKey)) {
      seenReasonFiles.add(reasonFileKey);
      reason.files.push(item.file);
    }
  }
  return [...groups.values()];
}
var LintResultsModal = class extends import_obsidian14.Modal {
  constructor(app, plugin, result, runNotePath) {
    super(app);
    this.plugin = plugin;
    this.result = result;
    this.runNotePath = runNotePath;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const r = this.result;
    const failed = r.errors.length > 0 || this.plugin.settings.lintStrictMode && r.warnings.length > 0;
    contentEl.createEl("h2", {
      text: failed ? "\u274C Vault Lint \u2014 Failed" : "\u2705 Vault Lint \u2014 Passed"
    });
    const summaryEl = contentEl.createDiv("forge-lint-summary");
    summaryEl.createEl("div", {
      text: `${r.errors.length} errors`
    });
    summaryEl.createEl("div", {
      text: `${r.warnings.length} warnings`
    });
    summaryEl.createEl("div", {
      text: `${r.infos.length} info`
    });
    summaryEl.createEl("br");
    summaryEl.createEl("div", {
      text: `${r.envelope.notes_scanned} notes scanned`
    });
    if (r.errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      for (const group of groupLintItems2(r.errors)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    if (r.warnings.length > 0) {
      contentEl.createEl("h3", { text: "Warnings" });
      for (const group of groupLintItems2(r.warnings)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    if (r.infos.length > 0) {
      contentEl.createEl("h3", { text: "Info" });
      for (const group of groupLintItems2(r.infos)) {
        contentEl.createEl("div", {
          text: `[${group.rule}]`,
          cls: "forge-lint-rule"
        });
        contentEl.createEl("div", {
          text: group.summary,
          cls: "forge-lint-message"
        });
        for (const reason of group.reasons) {
          contentEl.createEl("h4", {
            text: reason.label,
            cls: "forge-lint-reason"
          });
          const list = contentEl.createEl("ul", {
            cls: "forge-lint-list"
          });
          for (const file of reason.files) {
            list.createEl("li", {
              text: file
            });
          }
        }
      }
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const viewBtn = buttonRow.createEl("button", {
      text: "View Lint Run Note",
      cls: "mod-cta"
    });
    viewBtn.addEventListener("click", () => {
      this.close();
      this.app.workspace.openLinkText(this.runNotePath, "", false);
    });
    if (r.errors.length > 0) {
      const repairBtn = buttonRow.createEl("button", { text: "Open Vault Repair" });
      repairBtn.addEventListener("click", () => {
        this.close();
        runVaultRepair(this.plugin);
      });
    }
    const closeBtn = buttonRow.createEl("button", { text: "Close" });
    closeBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/apply-patch.ts
init_files();
async function runApplyPatch(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  let patchFile = await loadPatchFile(app, paths.patchFile);
  if (!patchFile) {
    const created = await createPatchTemplateIfMissing(app, paths.patchFile);
    if (created) {
      new import_obsidian15.Notice(
        `Forge: Created patch note at ${paths.patchFile}. Add operations, then run Apply Vault Patch again.`,
        7e3
      );
      return;
    }
    new import_obsidian15.Notice(
      `Forge: Patch file not found or has no YAML block at ${paths.patchFile}`,
      7e3
    );
    return;
  }
  if (patchFile.operations.length === 0) {
    new import_obsidian15.Notice("Forge: Patch file has no operations.", 4e3);
    return;
  }
  new import_obsidian15.Notice("Forge: Running dry pass\u2026", 2e3);
  const dryResult = await applyPatch(
    app,
    settings,
    patchFile,
    paths.patchFile,
    true
  );
  new PatchConfirmModal(app, plugin, (_a = patchFile.meta.description) != null ? _a : "", dryResult, async () => {
    new import_obsidian15.Notice("Forge: Applying patch\u2026", 2e3);
    const applyResult = await applyPatch(
      app,
      settings,
      patchFile,
      paths.patchFile,
      false
    );
    await writeRestoreManifest(app, settings, applyResult);
    await archivePatchFile(app, settings, applyResult);
    const reportPath = await writePatchReport(app, settings, applyResult);
    const changed = applyResult.results.filter((r) => r.status === "changed").length;
    const errors = applyResult.results.filter((r) => r.status === "error").length;
    if (errors > 0) {
      new import_obsidian15.Notice(
        `Forge: Patch applied with ${errors} error(s). Changed: ${changed}. See report.`,
        7e3
      );
    } else {
      new import_obsidian15.Notice(
        `Forge: Patch applied. ${changed} file(s) changed.`,
        5e3
      );
    }
    const reportFile = app.vault.getAbstractFileByPath((0, import_obsidian15.normalizePath)(reportPath));
    if (reportFile) {
      app.workspace.openLinkText(reportPath, "", false);
    }
    if (settings.patchAutoLintAfterApply) {
      await runVaultLint(plugin);
    }
  }).open();
}
async function createPatchTemplateIfMissing(app, patchPath) {
  const normalizedPath = (0, import_obsidian15.normalizePath)(patchPath);
  const existing = app.vault.getAbstractFileByPath(normalizedPath);
  if (existing instanceof import_obsidian15.TFile)
    return false;
  const folder = normalizedPath.includes("/") ? normalizedPath.substring(0, normalizedPath.lastIndexOf("/")) : "";
  if (folder)
    await ensureFolder(app, folder);
  const today = todayString();
  const content = [
    "---",
    "type: procedure",
    "status: draft",
    "tags:",
    "  - tool/forge",
    `created: ${today}`,
    `updated: ${today}`,
    "ai_private: false",
    "review_cycle: never",
    "---",
    "",
    "# Vault Patch",
    "",
    "Patch file for Forge.",
    "",
    "## Patch",
    "",
    "```yaml",
    "meta:",
    "  description: Manual vault patch",
    "",
    "operations: []",
    "```",
    ""
  ].join("\n");
  await app.vault.create(normalizedPath, content);
  return true;
}
var PatchConfirmModal = class extends import_obsidian15.Modal {
  constructor(app, plugin, description, dryResult, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.description = description;
    this.dryResult = dryResult;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const changed = this.dryResult.results.filter((r) => r.status === "changed");
    const skipped2 = this.dryResult.results.filter((r) => r.status === "skipped");
    const errors = this.dryResult.results.filter((r) => r.status === "error");
    contentEl.createEl("h2", { text: "Apply Vault Patch" });
    if (this.description) {
      contentEl.createEl("p", {
        text: this.description,
        cls: "forge-patch-description"
      });
    }
    const summary = contentEl.createDiv("forge-patch-summary");
    const countEl = summary.createDiv("forge-patch-counts");
    countEl.createSpan({
      text: `${changed.length} changes`,
      cls: changed.length > 0 ? "forge-count-changed" : "forge-count-zero"
    });
    countEl.createSpan({ text: "  |  " });
    countEl.createSpan({
      text: `${skipped2.length} skipped`,
      cls: "forge-count-skipped"
    });
    countEl.createSpan({ text: "  |  " });
    countEl.createSpan({
      text: `${errors.length} errors`,
      cls: errors.length > 0 ? "forge-count-error" : "forge-count-zero"
    });
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const errorList = contentEl.createEl("ul", { cls: "forge-error-list" });
      for (const r of errors.slice(0, 10)) {
        errorList.createEl("li", { text: `[${r.op}] ${r.file} \u2014 ${r.detail}` });
      }
      if (errors.length > 10) {
        errorList.createEl("li", { text: `\u2026and ${errors.length - 10} more` });
      }
      contentEl.createEl("p", {
        text: "Errors will not be applied. You can still proceed with the successful operations.",
        cls: "forge-error-note"
      });
    }
    if (changed.length > 0) {
      contentEl.createEl("h3", { text: "Changes" });
      const changeList = contentEl.createEl("ul", { cls: "forge-change-list" });
      for (const r of changed.slice(0, 20)) {
        changeList.createEl("li", { text: `${r.file} \u2014 ${r.detail}` });
      }
      if (changed.length > 20) {
        changeList.createEl("li", {
          text: `\u2026and ${changed.length - 20} more`,
          cls: "forge-more"
        });
      }
    }
    if (changed.length === 0 && errors.length === 0) {
      contentEl.createEl("p", {
        text: "No changes needed \u2014 vault already matches the patch.",
        cls: "forge-no-changes"
      });
    }
    if (this.plugin.settings.patchBackupEnabled && changed.length > 0) {
      contentEl.createEl("p", {
        text: `Backups will be written to ${this.plugin.settings.patchBackupFolder || this.plugin.settings.patchesFolder + "/Backups"}/`,
        cls: "forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    if (changed.length > 0) {
      const applyBtn = buttonRow.createEl("button", {
        text: "Apply",
        cls: "mod-cta"
      });
      applyBtn.addEventListener("click", async () => {
        this.close();
        await this.onConfirm();
      });
    }
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/validate-schema.ts
var import_obsidian16 = require("obsidian");
init_vault_paths();
async function runValidateSchema(plugin) {
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const file = app.vault.getAbstractFileByPath(paths.schemaMd);
  if (!(file instanceof import_obsidian16.TFile)) {
    new import_obsidian16.Notice(
      `Forge: schema.md not found at ${paths.schemaMd}`,
      6e3
    );
    return;
  }
  let raw;
  try {
    raw = await app.vault.read(file);
  } catch (e) {
    new import_obsidian16.Notice("Forge: Could not read schema.md.", 5e3);
    return;
  }
  const issues = validateSchemaNote(raw);
  if (!issues.some((i) => i.severity === "error")) {
    await plugin.schemaCache.refresh();
  }
  new ValidateSchemaModal(app, plugin, issues, paths.schemaMd).open();
}
var ValidateSchemaModal = class extends import_obsidian16.Modal {
  constructor(app, plugin, issues, schemaPath) {
    super(app);
    this.plugin = plugin;
    this.issues = issues;
    this.schemaPath = schemaPath;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const errors = this.issues.filter((i) => i.severity === "error");
    const warnings = this.issues.filter((i) => i.severity === "warning");
    const passed = errors.length === 0;
    contentEl.createEl("h2", {
      text: passed ? "\u2705 Schema Valid" : "\u{1F534} Schema Errors Found"
    });
    contentEl.createEl("p", {
      text: `Schema: ${this.schemaPath}`,
      cls: "forge-schema-path"
    });
    if (passed && warnings.length === 0) {
      contentEl.createEl("p", {
        text: "schema.md is well-formed. All required sections are present and parseable.",
        cls: "forge-success-msg"
      });
    }
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const list = contentEl.createEl("ul", { cls: "forge-lint-list" });
      for (const issue of errors) {
        list.createEl("li", { text: issue.message });
      }
    }
    if (warnings.length > 0) {
      contentEl.createEl("h3", { text: "Warnings" });
      const list = contentEl.createEl("ul", { cls: "forge-lint-list" });
      for (const issue of warnings) {
        list.createEl("li", { text: issue.message });
      }
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const openBtn = buttonRow.createEl("button", {
      text: "Open schema.md",
      cls: passed ? "mod-cta" : ""
    });
    openBtn.addEventListener("click", () => {
      this.close();
      this.app.workspace.openLinkText(this.schemaPath, "", false);
    });
    const closeBtn = buttonRow.createEl("button", { text: "Close" });
    closeBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/normalize.ts
var import_obsidian17 = require("obsidian");
init_vault_paths();
init_frontmatter();
init_files();
async function runNormalizeTags(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const schema = await loadSchema(app, settings);
  const exemptPaths = buildExemptList((_a = schema == null ? void 0 : schema.exempt_paths) != null ? _a : [], paths.forge);
  const files = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  new import_obsidian17.Notice("Forge: Scanning tags\u2026", 2e3);
  const dryResults = await normalizeTagsPass(app, settings, files, true);
  const candidates = dryResults.filter((r) => r.changed);
  if (candidates.length === 0) {
    new import_obsidian17.Notice("Forge: All tags already normalized \u2014 no changes needed.", 4e3);
    return;
  }
  new NormalizeConfirmModal(
    app,
    plugin,
    "Normalize Tags",
    `${candidates.length} file(s) have tags to normalize.`,
    candidates,
    async () => {
      const applyResults = await normalizeTagsPass(app, settings, files, false);
      const changed = applyResults.filter((r) => r.changed).length;
      new import_obsidian17.Notice(`Forge: Normalized tags in ${changed} file(s).`, 4e3);
    }
  ).open();
}
async function normalizeTagsPass(app, settings, files, dryRun) {
  const paths = getVaultPaths(settings);
  const results = [];
  for (const file of files) {
    const note = await readNote(app, file);
    if (!note || !note.hasFrontmatter)
      continue;
    const originalTags = getTags(note.frontmatter);
    const converted = originalTags.map(convertTagSeparator).filter((t) => !isInvalidTag(t));
    const normalized = normalizeTags(converted);
    const originalStr = originalTags.join("|");
    const normalizedStr = normalized.join("|");
    if (originalStr === normalizedStr)
      continue;
    const removedCount = originalTags.length - converted.length;
    const convertedCount = originalTags.filter(
      (t, i) => convertTagSeparator(t) !== t
    ).length;
    const details = [];
    if (convertedCount > 0)
      details.push(`${convertedCount} separator(s) fixed`);
    if (removedCount > 0)
      details.push(`${removedCount} invalid tag(s) removed`);
    if (originalStr !== normalizedStr)
      details.push("sorted/deduped");
    if (!dryRun) {
      await backupNote(app, file, paths.patchBackups);
      setTags(note.frontmatter, normalized);
      await writeNote(app, note, settings.frontmatterFieldOrder);
    }
    results.push({
      file: file.path,
      changed: true,
      detail: details.join(", ")
    });
  }
  return results;
}
async function runNormalizeFrontmatter(plugin) {
  var _a;
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const schema = await loadSchema(app, settings);
  const exemptPaths = [
    ...(_a = schema == null ? void 0 : schema.exempt_paths) != null ? _a : [],
    paths.forge
  ];
  const files = getMarkdownFiles(app).filter(
    (f) => !isExempt(f.path, exemptPaths)
  );
  new import_obsidian17.Notice("Forge: Scanning frontmatter\u2026", 2e3);
  const dryResults = await normalizeFrontmatterPass(app, settings, files, true, plugin);
  const candidates = dryResults.filter((r) => r.changed);
  if (candidates.length === 0) {
    new import_obsidian17.Notice("Forge: All frontmatter already normalized \u2014 no changes needed.", 4e3);
    return;
  }
  new NormalizeConfirmModal(
    app,
    plugin,
    "Normalize Frontmatter",
    `${candidates.length} file(s) have frontmatter to normalize.`,
    candidates,
    async () => {
      const applyResults = await normalizeFrontmatterPass(app, settings, files, false, plugin);
      const changed = applyResults.filter((r) => r.changed).length;
      new import_obsidian17.Notice(`Forge: Normalized frontmatter in ${changed} file(s).`, 4e3);
    }
  ).open();
}
var DEFAULT_LOWERCASE_FIELDS = [];
async function normalizeFrontmatterPass(app, settings, files, dryRun, plugin) {
  const paths = getVaultPaths(settings);
  const results = [];
  const enumFields = plugin.schemaCache ? plugin.schemaCache.getEnumFieldNames() : DEFAULT_LOWERCASE_FIELDS;
  const lowercaseFields = new Set(enumFields);
  for (const file of files) {
    const note = await readNote(app, file);
    if (!note || !note.hasFrontmatter)
      continue;
    const fm = note.frontmatter;
    let changed = false;
    const details = [];
    const upperKeys = Object.keys(fm).filter((k) => k !== k.toLowerCase());
    if (upperKeys.length > 0) {
      for (const key of upperKeys) {
        const lower = key.toLowerCase();
        if (lower !== key) {
          fm[lower] = fm[key];
          delete fm[key];
        }
      }
      changed = true;
      details.push(`${upperKeys.length} field name(s) lowercased`);
    }
    for (const field of lowercaseFields) {
      if (field in fm && typeof fm[field] === "string") {
        const original = fm[field];
        const lower = original.toLowerCase();
        if (original !== lower) {
          fm[field] = lower;
          changed = true;
          details.push(`${field} value lowercased`);
        }
      }
    }
    const tags = getTags(fm);
    const loweredTags = tags.map((t) => t.toLowerCase());
    const tagStr = tags.join("|");
    const loweredStr = loweredTags.join("|");
    if (tagStr !== loweredStr) {
      setTags(fm, loweredTags);
      changed = true;
      details.push("tags lowercased");
    }
    if (!changed)
      continue;
    if (!dryRun) {
      await backupNote(app, file, paths.patchBackups);
      await writeNote(app, note, settings.frontmatterFieldOrder);
    }
    results.push({
      file: file.path,
      changed: true,
      detail: details.join(", ")
    });
  }
  return results;
}
var NormalizeConfirmModal = class extends import_obsidian17.Modal {
  constructor(app, plugin, title, summary, candidates, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.title = title;
    this.summary = summary;
    this.candidates = candidates;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: this.title });
    contentEl.createEl("p", { text: this.summary });
    const list = contentEl.createEl("ul", { cls: "forge-change-list" });
    for (const r of this.candidates.slice(0, 20)) {
      list.createEl("li", { text: `${r.file} \u2014 ${r.detail}` });
    }
    if (this.candidates.length > 20) {
      list.createEl("li", {
        text: `\u2026and ${this.candidates.length - 20} more`,
        cls: "forge-more"
      });
    }
    if (this.plugin.settings.patchBackupEnabled) {
      contentEl.createEl("p", {
        text: "Backups will be written to System/Forge/Patches/Backups/",
        cls: "forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const applyBtn = buttonRow.createEl("button", {
      text: "Apply",
      cls: "mod-cta"
    });
    applyBtn.addEventListener("click", async () => {
      this.close();
      await this.onConfirm();
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/maintenance.ts
var import_obsidian18 = require("obsidian");
init_vault_paths();
init_files();
async function runVaultMaintenance(plugin) {
  const { app, settings } = plugin;
  new import_obsidian18.Notice("Forge: Running maintenance dry pass\u2026", 2e3);
  const dryResults = await runAllTasks(app, settings, true);
  const actions = dryResults.filter((r) => r.status === "removed" || r.status === "trimmed");
  if (actions.length === 0) {
    new import_obsidian18.Notice("Forge: Nothing to clean up \u2014 vault is within retention policy.", 5e3);
    return;
  }
  new MaintenanceConfirmModal(app, plugin, dryResults, async () => {
    const applyResults = await runAllTasks(app, settings, false);
    const applied = applyResults.filter((r) => r.status === "removed" || r.status === "trimmed").length;
    const errors = applyResults.filter((r) => r.status === "error").length;
    if (errors > 0) {
      new import_obsidian18.Notice(`Forge: Maintenance complete. ${applied} action(s), ${errors} error(s).`, 6e3);
    } else {
      new import_obsidian18.Notice(`Forge: Maintenance complete. ${applied} item(s) cleaned up.`, 5e3);
    }
  }).open();
}
async function runAllTasks(app, settings, dryRun) {
  const results = [];
  results.push(...await trimLintHistory(app, settings, dryRun));
  results.push(...await trimLintRunNotes(app, settings, dryRun));
  results.push(...await trimPatchReportNotes(app, settings, dryRun));
  results.push(...await cleanPatchBackups(app, settings, dryRun));
  results.push(...await cleanInbox(app, settings, dryRun));
  return results;
}
async function trimLintHistory(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const histFile = app.vault.getAbstractFileByPath(paths.lintHistoryJson);
  if (!(histFile instanceof import_obsidian18.TFile)) {
    return [{ task: "lint_history", target: paths.lintHistoryJson, status: "skipped", detail: "lint-history.json does not exist yet" }];
  }
  let history = [];
  try {
    const raw = await app.vault.read(histFile);
    history = JSON.parse(raw);
    if (!Array.isArray(history))
      history = [];
  } catch (e) {
    return [{ task: "lint_history", target: paths.lintHistoryJson, status: "error", detail: "Could not parse lint-history.json" }];
  }
  const before = history.length;
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - settings.lintHistoryRetentionDays);
  history = history.filter((e) => {
    try {
      return new Date(e.timestamp) >= cutoff;
    } catch (e2) {
      return false;
    }
  });
  if (history.length > settings.lintHistoryMaxEntries) {
    history = history.slice(history.length - settings.lintHistoryMaxEntries);
  }
  const removed = before - history.length;
  if (removed === 0) {
    return [{
      task: "lint_history",
      target: paths.lintHistoryJson,
      status: "skipped",
      detail: `${before} entries, none exceed retention (${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} max)`
    }];
  }
  if (!dryRun) {
    await app.vault.modify(histFile, JSON.stringify(history, null, 2));
  }
  return [{
    task: "lint_history",
    target: paths.lintHistoryJson,
    status: "trimmed",
    detail: `Removed ${removed} entries (${before} \u2192 ${history.length}). Policy: ${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} max`
  }];
}
async function trimLintRunNotes(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const files = getMarkdownFiles(app, paths.lintRuns).sort((a, b) => a.name.localeCompare(b.name));
  if (files.length <= settings.lintRunRetentionCount) {
    return [{
      task: "lint_runs",
      target: paths.lintRuns,
      status: "skipped",
      detail: `${files.length} lint report notes, within retention limit of ${settings.lintRunRetentionCount}`
    }];
  }
  const toRemove = files.slice(0, files.length - settings.lintRunRetentionCount);
  const results = [];
  for (const file of toRemove) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    results.push({
      task: "lint_runs",
      target: file.path,
      status: "removed",
      detail: `Lint report note over retention limit of ${settings.lintRunRetentionCount}`
    });
  }
  return results;
}
async function trimPatchReportNotes(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const files = getMarkdownFiles(app, paths.patchReports).filter((f) => f.name.includes("-patch-report-")).sort((a, b) => a.name.localeCompare(b.name));
  if (files.length <= settings.patchReportRetentionCount) {
    return [{
      task: "patch_reports",
      target: paths.patchReports,
      status: "skipped",
      detail: `${files.length} patch report notes, within retention limit of ${settings.patchReportRetentionCount}`
    }];
  }
  const toRemove = files.slice(0, files.length - settings.patchReportRetentionCount);
  const results = [];
  for (const file of toRemove) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    results.push({
      task: "patch_reports",
      target: file.path,
      status: "removed",
      detail: `Patch report over retention limit of ${settings.patchReportRetentionCount}`
    });
  }
  return results;
}
async function cleanPatchBackups(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const cutoff = Date.now() - settings.backupRetentionDays * 24 * 60 * 60 * 1e3;
  const results = [];
  const backupFolder = app.vault.getAbstractFileByPath(paths.patchBackups);
  if (!(backupFolder instanceof import_obsidian18.TFolder)) {
    return [{ task: "patch_backups", target: paths.patchBackups, status: "skipped", detail: "Backup folder does not exist yet" }];
  }
  const allFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.patchBackups) && f.name.endsWith(".bak")
  );
  const stale = allFiles.filter((f) => f.stat.mtime < cutoff);
  if (stale.length === 0) {
    return [{
      task: "patch_backups",
      target: paths.patchBackups,
      status: "skipped",
      detail: `No backup files older than ${settings.backupRetentionDays} days`
    }];
  }
  for (const file of stale) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    const age = Math.floor((Date.now() - file.stat.mtime) / (1e3 * 60 * 60 * 24));
    results.push({
      task: "patch_backups",
      target: file.path,
      status: "removed",
      detail: `Backup ${age} days old (threshold: ${settings.backupRetentionDays} days)`
    });
  }
  return results;
}
async function cleanInbox(app, settings, dryRun) {
  const paths = getVaultPaths(settings);
  const cutoff = Date.now() - settings.inboxRetentionDays * 24 * 60 * 60 * 1e3;
  const results = [];
  const inboxFolder = app.vault.getAbstractFileByPath(paths.inbox);
  if (!(inboxFolder instanceof import_obsidian18.TFolder)) {
    return [{ task: "inbox", target: paths.inbox, status: "skipped", detail: "Inbox folder does not exist" }];
  }
  const staleFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.inbox + "/") && f.stat.mtime < cutoff
  );
  if (staleFiles.length === 0) {
    return [{
      task: "inbox",
      target: paths.inbox,
      status: "skipped",
      detail: `No inbox files older than ${settings.inboxRetentionDays} days`
    }];
  }
  for (const file of staleFiles) {
    if (!dryRun) {
      await app.vault.delete(file);
    }
    const age = Math.floor((Date.now() - file.stat.mtime) / (1e3 * 60 * 60 * 24));
    results.push({
      task: "inbox",
      target: file.path,
      status: "removed",
      detail: `Inbox file ${age} days old (threshold: ${settings.inboxRetentionDays} days)`
    });
  }
  return results;
}
var MaintenanceConfirmModal = class extends import_obsidian18.Modal {
  constructor(app, plugin, results, onConfirm) {
    super(app);
    this.plugin = plugin;
    this.results = results;
    this.onConfirm = onConfirm;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    const actions = this.results.filter((r) => r.status === "removed" || r.status === "trimmed");
    const errors = this.results.filter((r) => r.status === "error");
    const { settings } = this.plugin;
    contentEl.createEl("h2", { text: "Vault Maintenance" });
    const policy = contentEl.createDiv("forge-maintenance-policy");
    policy.createEl("p", { text: `Retention policy:`, cls: "forge-policy-label" });
    const policyList = policy.createEl("ul");
    policyList.createEl("li", { text: `Lint history: ${settings.lintHistoryRetentionDays} days / ${settings.lintHistoryMaxEntries} entries max` });
    policyList.createEl("li", { text: `Lint run notes: ${settings.lintRunRetentionCount} notes max` });
    policyList.createEl("li", { text: `Patch reports: ${settings.patchReportRetentionCount} notes max` });
    policyList.createEl("li", { text: `Patch backups: ${settings.backupRetentionDays} days` });
    policyList.createEl("li", { text: `Inbox files: ${settings.inboxRetentionDays} days` });
    if (errors.length > 0) {
      contentEl.createEl("h3", { text: "Errors" });
      const list2 = contentEl.createEl("ul", { cls: "forge-error-list" });
      for (const r of errors) {
        list2.createEl("li", { text: `[${r.task}] ${r.target} \u2014 ${r.detail}` });
      }
    }
    contentEl.createEl("h3", { text: `${actions.length} item(s) to clean up` });
    const list = contentEl.createEl("ul", { cls: "forge-change-list" });
    for (const r of actions.slice(0, 20)) {
      list.createEl("li", { text: `[${r.task}] ${r.target} \u2014 ${r.detail}` });
    }
    if (actions.length > 20) {
      list.createEl("li", { text: `\u2026and ${actions.length - 20} more`, cls: "forge-more" });
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const applyBtn = buttonRow.createEl("button", { text: "Apply", cls: "mod-cta" });
    applyBtn.addEventListener("click", async () => {
      this.close();
      await this.onConfirm();
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/restore-patch.ts
var import_obsidian19 = require("obsidian");
init_vault_paths();
async function runRestorePatch(plugin) {
  const { app, settings } = plugin;
  const paths = getVaultPaths(settings);
  const manifestFiles = app.vault.getFiles().filter(
    (f) => f.path.startsWith(paths.patchReports) && f.name.endsWith("-patch-manifest.json")
  ).sort((a, b) => b.name.localeCompare(a.name));
  if (manifestFiles.length === 0) {
    new import_obsidian19.Notice("Forge: No patch manifests found. Apply a patch with backups enabled first.", 6e3);
    return;
  }
  const manifests = [];
  for (const file of manifestFiles) {
    try {
      const raw = await app.vault.read(file);
      manifests.push(JSON.parse(raw));
    } catch (e) {
    }
  }
  if (manifests.length === 0) {
    new import_obsidian19.Notice("Forge: Could not read any patch manifests.", 5e3);
    return;
  }
  new RestorePatchModal(app, plugin, manifests).open();
}
var RestorePatchModal = class extends import_obsidian19.Modal {
  constructor(app, plugin, manifests) {
    super(app);
    this.selected = null;
    this.plugin = plugin;
    this.manifests = manifests;
  }
  onOpen() {
    this.renderList();
  }
  renderList() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Restore Patch Run" });
    contentEl.createEl("p", {
      text: "Select a patch run to restore. All files changed by that patch will be replaced with their backups.",
      cls: "setting-item-description"
    });
    const list = contentEl.createDiv("forge-restore-list");
    for (const manifest of this.manifests) {
      const item = list.createDiv("forge-restore-item");
      item.addEventListener("click", () => {
        this.selected = manifest;
        this.renderConfirm();
      });
      const date = new Date(manifest.applied_at).toLocaleString();
      item.createEl("div", { text: manifest.description || manifest.run_id, cls: "forge-restore-title" });
      item.createEl("div", { text: `${date} \u2014 ${manifest.changes.length} file(s)`, cls: "forge-restore-meta" });
    }
    const closeBtn = contentEl.createEl("button", { text: "Cancel" });
    closeBtn.addEventListener("click", () => this.close());
  }
  renderConfirm() {
    const { contentEl } = this;
    const manifest = this.selected;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Confirm Restore" });
    contentEl.createEl("p", {
      text: manifest.description || manifest.run_id,
      cls: "forge-patch-description"
    });
    contentEl.createEl("p", {
      text: `Applied: ${new Date(manifest.applied_at).toLocaleString()}`,
      cls: "setting-item-description"
    });
    contentEl.createEl("h3", { text: `${manifest.changes.length} file(s) will be restored` });
    const list = contentEl.createEl("ul", { cls: "forge-change-list" });
    for (const change of manifest.changes.slice(0, 20)) {
      list.createEl("li", { text: change.file });
    }
    if (manifest.changes.length > 20) {
      list.createEl("li", { text: `\u2026and ${manifest.changes.length - 20} more`, cls: "forge-more" });
    }
    contentEl.createEl("p", {
      text: "This will overwrite the current versions of these files with their pre-patch backups. This cannot be undone.",
      cls: "forge-error-note"
    });
    const buttonRow = contentEl.createDiv("forge-button-row");
    const restoreBtn = buttonRow.createEl("button", { text: "Restore", cls: "mod-cta mod-warning" });
    restoreBtn.addEventListener("click", async () => {
      this.close();
      await this.applyRestore(manifest);
    });
    const backBtn = buttonRow.createEl("button", { text: "Back" });
    backBtn.addEventListener("click", () => this.renderList());
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async applyRestore(manifest) {
    const { app } = this;
    let restored = 0;
    let failed = 0;
    for (const change of manifest.changes) {
      const backupFile = app.vault.getAbstractFileByPath(change.backup);
      if (!(backupFile instanceof import_obsidian19.TFile)) {
        console.warn(`[Forge] Backup not found: ${change.backup}`);
        failed++;
        continue;
      }
      try {
        const backupContent = await app.vault.read(backupFile);
        const targetFile = app.vault.getAbstractFileByPath(change.file);
        if (targetFile instanceof import_obsidian19.TFile) {
          await app.vault.modify(targetFile, backupContent);
        } else {
          await app.vault.create(change.file, backupContent);
        }
        restored++;
      } catch (e) {
        console.warn(`[Forge] Could not restore ${change.file}:`, e);
        failed++;
      }
    }
    if (failed > 0) {
      new import_obsidian19.Notice(`Forge: Restored ${restored} file(s). ${failed} backup(s) not found.`, 7e3);
    } else {
      new import_obsidian19.Notice(`Forge: Restored ${restored} file(s) from patch run.`, 5e3);
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/commands/utilities.ts
var import_obsidian20 = require("obsidian");
init_vault_paths();
init_files();
async function runRenameDataviewFolder(plugin) {
  new RenameDataviewModal(plugin.app, plugin).open();
}
var RenameDataviewModal = class extends import_obsidian20.Modal {
  constructor(app, plugin) {
    super(app);
    this.currentFolder = "";
    this.newFolder = "";
    this.scanScope = "";
    this.plugin = plugin;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Rename Dataview Folder" });
    contentEl.createEl("p", {
      text: "Updates folder path references inside dataview blocks only. Lines outside dataview blocks are never touched.",
      cls: "setting-item-description"
    });
    new import_obsidian20.Setting(contentEl).setName("Current folder path").setDesc("The folder path currently referenced in dataview queries.").addText((t) => {
      t.setPlaceholder("Work/Skills");
      t.onChange((val) => {
        this.currentFolder = val.trim().replace(/^["']+|["']+$/g, "").replace(/\/+$/, "");
      });
    });
    new import_obsidian20.Setting(contentEl).setName("New folder path").setDesc("The replacement folder path.").addText((t) => {
      t.setPlaceholder("Work/Disciplines");
      t.onChange((val) => {
        this.newFolder = val.trim().replace(/^["']+|["']+$/g, "").replace(/\/+$/, "");
      });
    });
    new import_obsidian20.Setting(contentEl).setName("Scope (optional)").setDesc("Limit scanning to a subfolder. Leave empty to scan the entire vault.").addText((t) => {
      t.setPlaceholder("Work");
      t.onChange((val) => {
        this.scanScope = val.trim();
      });
    });
    const buttonRow = contentEl.createDiv("forge-button-row");
    const previewBtn = buttonRow.createEl("button", { text: "Preview", cls: "mod-cta" });
    previewBtn.addEventListener("click", async () => {
      if (!this.currentFolder || !this.newFolder) {
        new import_obsidian20.Notice("Forge: Both folder paths are required.", 3e3);
        return;
      }
      if (this.currentFolder === this.newFolder) {
        new import_obsidian20.Notice("Forge: Current and new folder paths are the same.", 3e3);
        return;
      }
      this.close();
      await this.runRename(true);
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  async runRename(dryRun) {
    const { app, plugin } = this;
    const paths = getVaultPaths(plugin.settings);
    const files = getMarkdownFiles(
      app,
      this.scanScope || void 0
    ).filter((f) => !f.path.startsWith(paths.forge));
    const candidates = [];
    for (const file of files) {
      const content = await app.vault.read(file);
      if (!/(?:```|~~~)dataview/.test(content))
        continue;
      const updated = updateDataviewFolderRefs(content, this.currentFolder, this.newFolder);
      if (updated !== content) {
        candidates.push({ file, updated });
      }
    }
    if (candidates.length === 0) {
      new import_obsidian20.Notice(
        `Forge: No dataview references to "${this.currentFolder}" found.`,
        4e3
      );
      return;
    }
    new DataviewRenameConfirmModal(
      app,
      plugin,
      this.currentFolder,
      this.newFolder,
      candidates
    ).open();
  }
  onClose() {
    this.contentEl.empty();
  }
};
function updateDataviewFolderRefs(content, current, newFolder) {
  const lines = content.split("\n");
  const result = [];
  let inDataview = false;
  for (const line of lines) {
    const trimmed = line.trimEnd();
    if (/^(?:```|~~~)dataview\s*$/.test(trimmed)) {
      inDataview = true;
      result.push(line);
      continue;
    }
    if (inDataview && /^(?:```|~~~)\s*$/.test(trimmed)) {
      inDataview = false;
      result.push(line);
      continue;
    }
    if (inDataview) {
      result.push(line.split(current).join(newFolder));
    } else {
      result.push(line);
    }
  }
  return result.join("\n");
}
var DataviewRenameConfirmModal = class extends import_obsidian20.Modal {
  constructor(app, plugin, currentFolder, newFolder, candidates) {
    super(app);
    this.plugin = plugin;
    this.currentFolder = currentFolder;
    this.newFolder = newFolder;
    this.candidates = candidates;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Rename Dataview Folder \u2014 Confirm" });
    contentEl.createEl("p", {
      text: `"${this.currentFolder}" \u2192 "${this.newFolder}"`,
      cls: "forge-patch-description"
    });
    contentEl.createEl("p", {
      text: `${this.candidates.length} file(s) will be updated.`
    });
    const list = contentEl.createEl("ul", { cls: "forge-change-list" });
    for (const { file } of this.candidates.slice(0, 20)) {
      list.createEl("li", { text: file.path });
    }
    if (this.candidates.length > 20) {
      list.createEl("li", {
        text: `\u2026and ${this.candidates.length - 20} more`,
        cls: "forge-more"
      });
    }
    if (this.plugin.settings.patchBackupEnabled) {
      contentEl.createEl("p", {
        text: "Backups will be written to System/Forge/Patches/Backups/",
        cls: "forge-backup-notice"
      });
    }
    const buttonRow = contentEl.createDiv("forge-button-row");
    const applyBtn = buttonRow.createEl("button", { text: "Apply", cls: "mod-cta" });
    applyBtn.addEventListener("click", async () => {
      this.close();
      const paths = getVaultPaths(this.plugin.settings);
      let changed = 0;
      for (const { file, updated } of this.candidates) {
        if (this.plugin.settings.patchBackupEnabled) {
          const { backupNote: backupNote2 } = await Promise.resolve().then(() => (init_frontmatter(), frontmatter_exports));
          await backupNote2(this.app, file, paths.patchBackups);
        }
        await this.app.vault.modify(file, updated);
        changed++;
      }
      new import_obsidian20.Notice(
        `Forge: Updated dataview references in ${changed} file(s).`,
        4e3
      );
    });
    const cancelBtn = buttonRow.createEl("button", { text: "Cancel" });
    cancelBtn.addEventListener("click", () => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/main.ts
init_refine_shapes();
var ForgePlugin = class extends import_obsidian21.Plugin {
  async onload() {
    await this.loadSettings();
    this.schemaCache = new SchemaCache(this.app, this.settings);
    this.addCommand({
      id: "apply-vault-patch",
      name: "Apply Vault Patch",
      callback: () => {
        runApplyPatch(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] apply-vault-patch error:", e);
        });
      }
    });
    this.addCommand({
      id: "run-vault-lint",
      name: "Run Vault Lint",
      callback: () => {
        runVaultLint(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] run-vault-lint error:", e);
        });
      }
    });
    this.addCommand({
      id: "validate-schema",
      name: "Validate Schema",
      callback: () => {
        runValidateSchema(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] validate-schema error:", e);
        });
      }
    });
    this.addCommand({
      id: "normalize-tags",
      name: "Normalize Tags",
      callback: () => {
        runNormalizeTags(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] normalize-tags error:", e);
        });
      }
    });
    this.addCommand({
      id: "normalize-frontmatter",
      name: "Normalize Frontmatter",
      callback: () => {
        runNormalizeFrontmatter(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] normalize-frontmatter error:", e);
        });
      }
    });
    this.addCommand({
      id: "vault-maintenance",
      name: "Vault Maintenance",
      callback: () => {
        runVaultMaintenance(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] vault-maintenance error:", e);
        });
      }
    });
    this.addCommand({
      id: "vault-repair",
      name: "Vault Repair",
      callback: () => {
        runVaultRepair(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] vault-repair error:", e);
        });
      }
    });
    this.addCommand({
      id: "restore-patch-run",
      name: "Restore Patch Run",
      callback: () => {
        runRestorePatch(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] restore-patch-run error:", e);
        });
      }
    });
    this.addCommand({
      id: "rename-dataview-folder",
      name: "Rename Dataview Folder",
      callback: () => {
        runRenameDataviewFolder(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] rename-dataview-folder error:", e);
        });
      }
    });
    this.addCommand({
      id: "install-documentation",
      name: "Install Documentation",
      callback: () => {
        installVaultForgeDocumentation(this.app, this.settings).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] install-documentation error:", e);
        });
      }
    });
    this.addCommand({
      id: "export-vault-overview",
      name: "Export Vault Overview",
      callback: () => {
        runExportOverview(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] export-vault-overview error:", e);
        });
      }
    });
    this.addCommand({
      id: "export-ontology-index",
      name: "Export Ontology Index",
      callback: () => {
        runExportOntology(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] export-ontology-index error:", e);
        });
      }
    });
    this.addCommand({
      id: "refine-shapes",
      name: "Refine Shape Templates",
      callback: () => {
        runRefineShapes(this).catch((e) => {
          var _a;
          new import_obsidian21.Notice(`Forge: ${(_a = e == null ? void 0 : e.message) != null ? _a : "Unexpected error"}`, 6e3);
          console.error("[Forge] refine-shapes error:", e);
        });
      }
    });
    this.addSettingTab(new ForgeSettingsTab(this.app, this));
    this.app.workspace.onLayoutReady(() => {
      this.schemaCache.refresh().catch(() => {
        setTimeout(() => this.schemaCache.refresh().catch((e) => {
          console.warn("[Forge] Schema cache retry failed:", e);
        }), 3e3);
      });
    });
    console.log("Forge loaded");
  }
  onunload() {
    console.log("Forge unloaded");
  }
  async loadSettings() {
    var _a;
    const loaded = (_a = await this.loadData()) != null ? _a : {};
    this.settings = Object.assign({}, DEFAULT_SETTINGS, loaded);
    if (!loaded.patchDefaultFile || loaded.patchDefaultFile === "System/Exports/vault-patch.yaml") {
      this.settings.patchDefaultFile = DEFAULT_SETTINGS.patchDefaultFile;
    }
  }
  async saveSettings() {
    await this.saveData(this.settings);
    if (this.schemaCache) {
      this.schemaCache.updateSettings(this.settings);
    }
  }
};
